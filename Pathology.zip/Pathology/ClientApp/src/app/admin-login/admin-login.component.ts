import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { loginbody } from 'src/model/userbody';
import { AppserviceService } from '../appservice.service';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.scss']
})
export class AdminLoginComponent implements OnInit {
  loginForm=this.fb.group({
    username:[null],
    password:[null]});
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) { }

  ngOnInit(): void {
  }
  ongetsignin()
  {
this._spinner.show();
    if(this.loginForm.get('username')?.value==null || this.loginForm.get('password')?.value==null ){
      this._spinner.hide();
      alert("Please Enter Fields Manually !!");
    }
    else{
      const createuser=new loginbody();
      createuser.EmailId=this.loginForm.get('username')?.value;
      createuser.Password=this.loginForm.get('password')?.value;
      this.service.signin(createuser).subscribe((res:any)=>{
        this._spinner.hide();
        console.log("hello",res);
        if(res.status=='success'){
          localStorage.setItem('LoggedInUser', JSON.stringify(res.data));
          // let userData=JSON.stringify(res.data)

          console.log("hello hi",res.data.role);
          console.log("hello hi",res.data['role']);
          if(res.data.role==2){
            this.router.navigateByUrl('admin/home-page');
            this._spinner.hide();
           
          }
        }
      })
    }
  }
}
