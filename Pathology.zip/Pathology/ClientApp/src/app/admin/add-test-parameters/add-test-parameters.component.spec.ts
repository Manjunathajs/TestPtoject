import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddTestParametersComponent } from './add-test-parameters.component';

describe('AddTestParametersComponent', () => {
  let component: AddTestParametersComponent;
  let fixture: ComponentFixture<AddTestParametersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddTestParametersComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddTestParametersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
