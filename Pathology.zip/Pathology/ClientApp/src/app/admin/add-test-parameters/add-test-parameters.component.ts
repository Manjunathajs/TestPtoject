import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { Addtestparameter } from 'src/model/userbody';

@Component({
  selector: 'app-add-test-parameters',
  templateUrl: './add-test-parameters.component.html',
  styleUrls: ['./add-test-parameters.component.scss']
})
export class AddTestParametersComponent implements OnInit {
  Addtest = this.fb.group({
    TestName: new FormControl('',Validators.required),
    Name: new FormControl('',Validators.required),
    Range: new FormControl('',Validators.required),
    TestId: new FormControl('',Validators.required),
    testcode: new FormControl('',Validators.required),
    TestParamName: new FormControl('',Validators.required),
    
  })
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) { }

  ngOnInit(): void {
  }
  getsubmit(){
    console.log(this.Addtest.getRawValue(),this.Addtest.valid,this.Addtest);
    if(this.Addtest.valid){
this._spinner.show();
      let addnewtest = new Addtestparameter();
      {
        addnewtest.TestName = this.Addtest.get('TestName')?.value;
        addnewtest.Name = this.Addtest.get('Name')?.value;
        addnewtest.Range = this.Addtest.get('Range')?.value;
        addnewtest.TestId = Number(this.Addtest.get('TestId')?.value);
        addnewtest.testcode = this.Addtest.get('testcode')?.value;
        addnewtest.TestParamName = this.Addtest.get('TestParamName')?.value;
        this.service.AddtestParameter(addnewtest).subscribe((res:any)=>{
          console.log(res.data);
          alert("Test Parameters Added Successfully");
          this.Addtest.reset();
          this._spinner.hide();
        })
      }
    }
   
  }
  
  
    clickhome(){
      this._spinner.show()
      console.log("hi")
      this.router.navigateByUrl('admin/home-page');
      this._spinner.hide();
    }
}
