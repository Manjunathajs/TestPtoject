import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddingtestmanualComponent } from './addingtestmanual.component';

describe('AddingtestmanualComponent', () => {
  let component: AddingtestmanualComponent;
  let fixture: ComponentFixture<AddingtestmanualComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddingtestmanualComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddingtestmanualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
