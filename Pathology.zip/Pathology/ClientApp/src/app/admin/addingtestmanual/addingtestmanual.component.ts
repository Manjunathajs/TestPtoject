import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { addtestmanually } from 'src/model/userbody';

@Component({
  selector: 'app-addingtestmanual',
  templateUrl: './addingtestmanual.component.html',
  styleUrls: ['./addingtestmanual.component.scss']
})
export class AddingtestmanualComponent implements OnInit {
  Addtest = this.fb.group({
    testdiscription: new FormControl('',Validators.required),
    subtest: new FormControl('',Validators.required),
    Range: new FormControl('',Validators.required),
    Amount: new FormControl('',Validators.required),
    units: new FormControl('',Validators.required),
    testcode: new FormControl('',Validators.required),
    
  })
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) { }

  ngOnInit(): void {
  }

getsubmit(){
  console.log(this.Addtest.getRawValue(),this.Addtest.valid,this.Addtest);
    if(this.Addtest.valid){
      this._spinner.show();

      let addnewtest = new addtestmanually();
      {
        addnewtest.testdiscription = this.Addtest.get('testdiscription')?.value;
        addnewtest.subtest = this.Addtest.get('subtest')?.value;
        addnewtest.Range = this.Addtest.get('Range')?.value;
        addnewtest.Units = this.Addtest.get('units')?.value;
        addnewtest.testcode = this.Addtest.get('testcode')?.value;
        addnewtest.amount = this.Addtest.get('Amount')?.value;
        this.service.Addtestmanully(addnewtest).subscribe((res:any)=>{
          console.log(res.data);
          alert("Test Added Successfully");
          this.Addtest.reset();
          this._spinner.hide();
        })
      }
    }
  
}


  clickhome(){
    this._spinner.show();
    console.log("hi")
    this.router.navigateByUrl('admin/home-page');
    this._spinner.hide();
  }
}
