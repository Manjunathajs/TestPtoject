import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';

@Component({
  selector: 'app-addtemplate',
  templateUrl: './addtemplate.component.html',
  styleUrls: ['./addtemplate.component.scss']
})
export class AddtemplateComponent implements OnInit {
  Emailregex: RegExp =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  register = this.fb.group({
    TestName: new FormControl('',Validators.required),
    Access:new FormControl(''),
    TestCode:new FormControl(''),
    Template:new FormControl('',[Validators.required])
  })
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  uploadFile: any;
  regName:any;
  regEmail: any;
  regGSTnumber: any;
  regPhoneNumber: any;
  regAddress: any;
  regPassword: any;
  constructor(private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService,private fb:FormBuilder) { }

  ngOnInit(): void {
  }
  uploadFileEvt(event: any):void {
    let file = event.target.files[0];
    this.uploadFile=file;
    this.register.get('Template')?.setValue(file);
    let fileReader: FileReader = new FileReader();
  //  let data= fileReader.readAsText( this.addproduct.get('fileupload')?.value)
  }

  ongetsignup(){
this._spinner.show();
  this.regName=this.register.get('TestName')?.value;
  this.regEmail=this.register.get('Access')?.value;
  this.regPhoneNumber =this.register.get('TestCode')?.value;
    let formData: FormData = new FormData();
      formData.append('TestName',this.regName);
      formData.append('Access',this.regEmail)
      formData.append('TestCode',this.regPhoneNumber)
      formData.append('Template',this.uploadFile)
      this.service.posttamplate(formData).subscribe((res:any)=>{
        console.log("hello",res);
        this._spinner.hide();
        window.location.reload();
        if(res.status=='success'){
         console.log("hi");
         alert('template added successfully')
         this.register.reset();
         
        }
        else{
          this._spinner.hide();
          console.log("hi")
          alert(res.message)
        }
        })
    
  }

  clickhome(){
    this._spinner.show()
    this.router.navigateByUrl('admin/home-page');
    this._spinner.hide();
  }
}
