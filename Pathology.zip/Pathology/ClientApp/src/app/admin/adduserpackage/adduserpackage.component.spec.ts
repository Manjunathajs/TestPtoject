import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdduserpackageComponent } from './adduserpackage.component';

describe('AdduserpackageComponent', () => {
  let component: AdduserpackageComponent;
  let fixture: ComponentFixture<AdduserpackageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdduserpackageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdduserpackageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
