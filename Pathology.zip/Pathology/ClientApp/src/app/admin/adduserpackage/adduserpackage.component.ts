import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormBuilder } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { addnewpackage } from 'src/model/userbody';

@Component({
  selector: 'app-adduserpackage',
  templateUrl: './adduserpackage.component.html',
  styleUrls: ['./adduserpackage.component.scss']
})
export class AdduserpackageComponent implements OnInit {
  Emailregex: RegExp =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  register = this.fb.group({
    UserEmail: new FormControl('',Validators.required),
  })
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService,sanitizer: DomSanitizer) { }

  ngOnInit(): void {
  }

  clickhome(){
    this._spinner.show();
    this.router.navigateByUrl('admin/home-page');
    this._spinner.hide();
  }
  ongetsignup(){
let adpackages = new addnewpackage()
adpackages.UserEmail = this.register.get('UserEmail')?.value;
adpackages.purchaseDate = new Date().toLocaleString();
adpackages.status = "Active";
this.service.addpacakgenew(adpackages).subscribe((res:any)=>{
  alert('Package added successfully')
  this.register.reset();
})
  }
}
