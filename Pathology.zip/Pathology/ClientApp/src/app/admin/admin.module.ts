import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoginComponent } from './login/login.component';
import { HomePageComponent } from './home-page/home-page.component';
import { RouterModule, Routes } from '@angular/router';
import { UserdetailsComponent } from './userdetails/userdetails.component';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { TestDetailsComponent } from './test-details/test-details.component';
import { PatientBillComponent } from '../user/patient-bill/patient-bill.component';
import { PatientDetailsComponent } from '../user/patient-details/patient-details.component';
import { UserhomepageComponent } from '../user/userhomepage/userhomepage.component';
import { PacientReportComponent } from '../user/pacient-report/pacient-report.component';
import { GetPatientReportComponent } from '../user/get-patient-report/get-patient-report.component';
import { TestExcelComponent } from './test-excel/test-excel.component';
import { GetPatientBillRecordsComponent } from '../user/get-patient-bill-records/get-patient-bill-records.component';
import { BillReportPDFComponent } from '../user/bill-report-pdf/bill-report-pdf.component';
import { PdfViewerModule }  from  'ng2-pdf-viewer';
import { AddDocDetailsComponent } from '../user/add-doc-details/add-doc-details.component';
import { GetpatientreportpdfComponent } from '../user/getpatientreportpdf/getpatientreportpdf.component';
import { DashBoardComponent } from '../user/dash-board/dash-board.component';
import { ViewpackagedetailsComponent } from '../user/viewpackagedetails/viewpackagedetails.component';
import { BillWithoutHeaderComponent } from '../user/bill-without-header/bill-without-header.component';
import { GetpdfwithheaderComponent } from '../user/getpdfwithheader/getpdfwithheader.component';
import { AddemployeesComponent } from '../user/addemployees/addemployees.component';
import { SpecialistEmpComponent } from '../user/specialist-emp/specialist-emp.component';
import { TesterEmpComponent } from '../user/tester-emp/tester-emp.component';
import { EditpatientreportComponent } from '../user/editpatientreport/editpatientreport.component';
import { EditedBySpecialistComponent } from '../user/edited-by-specialist/edited-by-specialist.component';
import { RegisterUserComponent } from './register-user/register-user.component';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatIconModule } from '@angular/material/icon';
import { PasswordresetComponent } from '../user/passwordreset/passwordreset.component';
import { AdminLoginComponent } from '../admin-login/admin-login.component';
import { PdfmakerComponent } from '../user/pdfmaker/pdfmaker.component';
import { AddingtestmanualComponent } from './addingtestmanual/addingtestmanual.component';
import { AddTestParametersComponent } from './add-test-parameters/add-test-parameters.component';
import { SharedComponent } from './shared/shared.component';
import { MainloginComponent } from './mainlogin/mainlogin.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MDBBootstrapModule } from "angular-bootstrap-md";
import { AddtemplateComponent } from './addtemplate/addtemplate.component';
import { BrowserModule } from '@angular/platform-browser';
import { DemoRequestListComponent } from './demo-request-list/demo-request-list.component';
import { AdduserpackageComponent } from './adduserpackage/adduserpackage.component';
import { FeatureComponent } from './feature/feature.component';
import { UpdateTemplateComponent } from './update-template/update-template.component';
import { IndirectBillingComponent } from '../user/indirect-billing/indirect-billing.component';

const routes: Routes = [
  {
    path:'',
    redirectTo: 'LABLIFE/home',
    pathMatch: 'prefix',

  },
  {
    path:'LABLIFE',
    children:[
      {
        path:'home',
        component:LoginComponent
      },
      {
        path:'adminLogin',
        component:AdminLoginComponent
      }
    ]
  },
  {
    path:'admin',
    children:[
      {
        path:'home-page',
        component:HomePageComponent
      },
      {
        path:'userdetails',
        component:UserdetailsComponent
      },
      {
        path:'test-details',
        component:TestDetailsComponent
      },
      {
        path:'test-excel',
        component:TestExcelComponent
      },
      {
        path:'register-user',
        component:RegisterUserComponent
      },
      {
        path:'addingtestmanual',
        component:AddingtestmanualComponent
      },
      {
        path:'add-test-parameters',
        component:AddTestParametersComponent
      },
      {
        path:'shared',
        component:SharedComponent
      },
      {
        path:'login',
        component:MainloginComponent
    },
    {
      path:'addtemplate',
      component:AddtemplateComponent
    },
    {
      path:'demo-request-list',
      component:DemoRequestListComponent
    },
    {
      path:'adduserpackage',
      component:AdduserpackageComponent
    },
    {
      path:'feature',
      component:FeatureComponent
    },
    {
      path:'update-template',
      component:UpdateTemplateComponent
    }
      
    ]},
    {
      path:'user',
      children:[
        {
          path:'dash-board',
          component:DashBoardComponent
        },
        {
          path:'userhomepage',
          component:UserhomepageComponent
        },
        {
          path:'patient-details',
          component:PatientDetailsComponent
        },
        {
          path:'patient-bill',
          component:PatientBillComponent
        },
        {
          path:'pacient-report',
          component:PacientReportComponent
        },
        {
          path:'get-patient-report',
          component:GetPatientReportComponent
        },
        {
          path:'get-patient-bill-records',
          component:GetPatientBillRecordsComponent
        },
        {
          path:'bill-report-pdf',
          component:BillReportPDFComponent
        },
        {
          path:'add-doc-details',
         component:AddDocDetailsComponent
        },
        {
          path:'getpatientreportpdf',
          component:GetpatientreportpdfComponent
        },
        {
          path:'viewpackagedetails',
          component:ViewpackagedetailsComponent
        },
        {
          path:'bill-without-header',
          component:BillWithoutHeaderComponent
        },
        {
          path:'getpdfwithheader',
          component:GetpdfwithheaderComponent
        },
        {
          path:'addemployees',
          component:AddemployeesComponent
        },
        {
          path:'specialist-emp',
          component:SpecialistEmpComponent
        },
        {
          path:'tester-emp',
          component:TesterEmpComponent
        },
        {
          path:'editpatientreport',
          component:EditpatientreportComponent
        },
        {
          path:'edited-by-specialist',
          component:EditedBySpecialistComponent
        },
        {
          path:'passwordreset',
          component:PasswordresetComponent
        },
        {
          path:'pdfmaker',
          component:PdfmakerComponent
        },
        {
          path:'shared',
          component:SharedComponent
        },
        {
          path:'login',
          component:MainloginComponent
      },
      {
        path:'indirect-billing',
        component:IndirectBillingComponent
      }
      
      
        
      ]}
]
@NgModule({
  declarations: [
    LoginComponent,
    HomePageComponent,
    UserdetailsComponent,
    TestDetailsComponent,
    TestExcelComponent,
    RegisterUserComponent,
    AddingtestmanualComponent,
    AddTestParametersComponent,
    SharedComponent,
    MainloginComponent,
    AddtemplateComponent,
    DemoRequestListComponent,
    AdduserpackageComponent,
    FeatureComponent,
    UpdateTemplateComponent

  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes),
    MatCardModule,
    MatFormFieldModule ,
    FormsModule,
    ReactiveFormsModule,
    MatToolbarModule,
        MatInputModule,
        MatTableModule,
        PdfViewerModule,
        NgxSpinnerModule,
        MatIconModule,
        NgbModule,
        
        MDBBootstrapModule.forRoot()

        
        
  ]
})
export class AdminModule { }
