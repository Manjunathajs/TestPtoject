import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DemoRequestListComponent } from './demo-request-list.component';

describe('DemoRequestListComponent', () => {
  let component: DemoRequestListComponent;
  let fixture: ComponentFixture<DemoRequestListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DemoRequestListComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DemoRequestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
