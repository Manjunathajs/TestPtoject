import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';

@Component({
  selector: 'app-demo-request-list',
  templateUrl: './demo-request-list.component.html',
  styleUrls: ['./demo-request-list.component.scss']
})
export class DemoRequestListComponent implements OnInit {
  displayedColumns: any[] = ['name','emailaddress','contactnumber','organisation','yourmessage'];
  dataSource = new MatTableDataSource<any>([]);
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.getemplist();
  }
  clickhome(){
    console.log("hi")
    this.router.navigateByUrl('admin/home-page');
  }

  getemplist(){
    this._spinner.show();
    this.service.getcontactlist(this.userdetails.email).subscribe((res:any)=>{
      this._spinner.hide();
    this.dataSource.data=res.data;
    console.log(this.dataSource.data)
    })
  }
}
