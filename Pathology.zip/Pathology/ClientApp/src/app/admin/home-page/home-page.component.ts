import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {
  loggedInuser: any| null;
  userdetails: any;
  
  
   
  constructor(private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) {
    
    console.log("hi")
   }
  ngOnInit(): void {
    console.log("hi");
  }
  CheckData(){
    this._spinner.show();
    this.router.navigateByUrl('admin/demo-request-list');
    this._spinner.hide();
  }
  Addtest(){
    this._spinner.show();
    this.router.navigateByUrl('admin/test-details');
    this._spinner.hide();
  }
  AddPackageExcel(){
    this._spinner.show();
    this.router.navigateByUrl('admin/test-excel');
    this._spinner.hide();
  }
  registeruser(){
    this._spinner.show();
    this.router.navigateByUrl('admin/register-user');
    this._spinner.hide();
  }
  Addtestmanually(){
    this._spinner.show();
    this.router.navigateByUrl('admin/addingtestmanual');
    this._spinner.hide();
  }
  Logout(){
    this._spinner.show();
    localStorage.removeItem('LoggedInUser')
    this.router.navigateByUrl('admin/login');
    this._spinner.hide();
  }
  AddTestParameters(){
    this._spinner.show();
    this.router.navigateByUrl('admin/add-test-parameters')
    this._spinner.hide();
  }
  AddTestTemplate(){
    this._spinner.show();
    this.router.navigateByUrl('admin/addtemplate');
    this._spinner.hide();
  }
  AdduserPackage(){
    this._spinner.show();
    this.router.navigateByUrl('admin/adduserpackage');
    this._spinner.hide();
  }
  Updatetesttemplate(){
    this._spinner.show();
    this.router.navigateByUrl('admin/update-template');
    this._spinner.hide(); 
  }
}
