import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subscriber } from 'rxjs';
import { AppserviceService } from 'src/app/appservice.service';
import { contactus, loginbody, sendmessage1, temppassword } from 'src/model/userbody';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  // loginForm=this.fb.group({
  //   username:[null],
  //   password:[null]});
  // empdata: any;
  images = ['/assets/Growth_Partner.png', '/assets/handshake_image.png', '/assets/HomeCollection.png', '/assets/MachineInterfacingWhite.png'].map((n) => n);
  Emailregex: RegExp =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  AddDataForm=this.fb.group({
    yourname :new FormControl('',[Validators.required]),
    youremailaddress:new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
    yourcontactnumber:new FormControl('',[Validators.required]),
    labname:new FormControl(''),
    yourmessage:new FormControl('')
  })
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner :NgxSpinnerService) { }

  ngOnInit(): void {
  }
  sendform(){
    if(this.AddDataForm.valid){
      console.log(this.AddDataForm)
      let posttester = new contactus()
      posttester.name=this.AddDataForm.get('yourname')?.value;
      posttester.emailaddress=this.AddDataForm.get('youremailaddress')?.value;
      posttester.contactnumber=this.AddDataForm.get('yourcontactnumber')?.value;
      posttester.organisation =this.AddDataForm.get('labname')?.value;
      posttester.yourmessage=this.AddDataForm.get('yourmessage')?.value;
      console.log(posttester)
      this.service.addcontactusdata(posttester).subscribe((res:any)=>{
      alert(res.message);
      this.AddDataForm.reset();
      });
    }
    else{
      alert('please enter valid input fields')
    }
    


  }
 
loginpage(){
  this._spinner.show();
  this.router.navigateByUrl('mian-home-page');
  this._spinner.hide();
}
scroll(el: HTMLElement) {
  el.scrollIntoView();
}

}
