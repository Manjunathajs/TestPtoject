import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { loginbody, temppassword } from 'src/model/userbody';

@Component({
  selector: 'app-mainlogin',
  templateUrl: './mainlogin.component.html',
  styleUrls: ['./mainlogin.component.scss']
})
export class MainloginComponent implements OnInit {
  Emailregex: RegExp =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    loginForm=this.fb.group({
      username:new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
      password:('')
    });
      empdata:any;
      showSignin=false;
      showSignup=false;
      style: any;
      isLoading=true;
      constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner :NgxSpinnerService) { }

  ngOnInit(): void {
  }
  getsignin(){
    this.showSignup=false;
    this.showSignin=true;
}

  getsignup(){
    this.showSignin=false;
    this.showSignup=true;
  }
  ongetsignin()
  {
    // this.loginForm.get('userEmail')?.setValue(this.userdetails.email);
    console.log(this.loginForm.getRawValue(),this.loginForm.valid,this.loginForm);
    // console.log(this.loginForm.getRawValue())
    if(this.loginForm.valid){
      if(this.loginForm.get('username')?.value==null || this.loginForm.get('password')?.value==null ){
        alert("Please Enter Fields Manually !!");
      }
      
      else{
        this._spinner.show();
        const createuser=new loginbody();
        createuser.EmailId=this.loginForm.get('username')?.value;
        createuser.Password=this.loginForm.get('password')?.value;
        
        this.service.signin(createuser).subscribe((res:any)=>{
          console.log("hello",res);
          if(res.status=='success'){
            this._spinner.hide();
            this.empdata = res.data;
            localStorage.setItem('LoggedInUser', JSON.stringify(res.data));
            // let userData=JSON.stringify(res.data)
  
            console.log("hello hi",res.data.role);
            console.log("hello hi",res.data['role']);
            // this.router.navigateByUrl('user/userhomePage');
            if (res.data.role == 2) {
              alert('Please login in admin dashboard');
            }
            if (res.data.role == 1) {
              this.router.navigateByUrl('user/dash-board');
            }
            else if (res.data.role == 5) {
              this.router.navigateByUrl('user/passwordreset');
            }
            else if (this.empdata.role == 3) {
              this.router.navigateByUrl('user/specialist-emp');
            }
            else if (this.empdata.role == 4) {
              this.router.navigateByUrl('user/tester-emp');
            }
                
            this._spinner.hide();
          }
          else{
            alert(res.message);
            this._spinner.hide();
            }
        })
      }
    }
   else{
     alert('Please Check The Input Fields')
   }
    
  }


  forgetpassword(){
    if(this.loginForm.get('username')?.value!=""){
      this._spinner.show();
      const passwordreset = new temppassword();
      passwordreset.userEmail=this.loginForm.get('username')?.value;
      this.service.resetpassword(passwordreset).subscribe((res:any)=>{
  console.log(res)
  this._spinner.hide();
  alert(res.message);
      })
  
    }else{
      alert("please enter your email and click forgot password");
    }

  }
  clickhome(){
    this.router.navigateByUrl('admin/home')
  }
}
