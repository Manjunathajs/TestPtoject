import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { Adminregister } from 'src/model/userbody';

@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.scss']
})
export class RegisterUserComponent implements OnInit {
  Emailregex: RegExp =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  register = this.fb.group({
    Name: new FormControl('',Validators.required),
    Email:new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
    AdminEmail:new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
    PhoneNumber:new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10) ]),
    Password:new FormControl(''),
    GSTNumber:new FormControl(''),
    Address:new FormControl(''),
    fileupload:new FormControl('')
  })
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  uploadFile: any;
  regName:any;
  regEmail: any;
  regGSTnumber: any;
  regPhoneNumber: any;
  regAddress: any;
  regPassword: any;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService,sanitizer: DomSanitizer) { }

  ngOnInit(): void {
    
  }

  uploadFileEvt(event: any):void {
    let file = event.target.files[0];
    this.uploadFile=file;
    this.register.get('fileupload')?.setValue(file);
    let fileReader: FileReader = new FileReader();
  //  let data= fileReader.readAsText( this.addproduct.get('fileupload')?.value)
  }

  ongetsignup(){
this._spinner.show()
    if(this.register.get('fileupload')?.value == ""){
      alert('Please Select logo')
      this._spinner.hide();
    }
    else{
      this.register.get('AdminEmail')?.setValue(this.userdetails.email);
      console.log(this.register.getRawValue(),this.register.valid,this.register);
      if(this.register.valid){
        this.regName=this.register.get('Name')?.value;
        this.regEmail=this.register.get('Email')?.value;
        this.regPhoneNumber =this.register.get('PhoneNumber')?.value;
        this.regGSTnumber =this.register.get('GSTNumber')?.value;
        this.regAddress=this.register.get('Address')?.value;
        this.regPassword=this.register.get('Password')?.value;
          let formData: FormData = new FormData();
            formData.append('Name',this.regName);
            formData.append('Email',this.regEmail)
            formData.append('PhoneNumber',this.regPhoneNumber)
            formData.append('GSTNumber',this.regGSTnumber)
            formData.append('Address',this.regAddress)
            formData.append('AdminEmail',this.userdetails.email)
            formData.append('Password',this.regPassword)
            formData.append('DataFiles',this.uploadFile)
            this.service.postuser(formData).subscribe((res:any)=>{
              console.log("hello",res);
              window.location.reload();
              if(res.status=='success'){
               console.log("hi");
               alert('User added successfully')
               this.register.reset();
                this._spinner.hide();
               
              }
              else{
                console.log("hi")
                alert(res.message)
                this._spinner.hide();
              }
              })
      }
      else{
        alert('Please Check Input Fields')
        this._spinner.hide();
      }
    }
    
  
    
  }
  clickhome(){
    this._spinner.show();
    this.router.navigateByUrl('admin/home-page');
    this._spinner.hide();
  }
}
