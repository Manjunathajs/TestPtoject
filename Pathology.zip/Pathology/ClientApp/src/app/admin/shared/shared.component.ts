import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';

@Component({
  selector: 'app-shared',
  templateUrl: './shared.component.html',
  styleUrls: ['./shared.component.scss']
})
export class SharedComponent implements OnInit {
  editProfileForm: any;
  applicationService: any;
  modalReference: any;
  modalService: any;
  closeResult: string | undefined;
  isCollapsed = false;
  showLogin=false;

  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner :NgxSpinnerService) { }
  toggleNavbar() {
    console.log(this.isCollapsed)
    this.isCollapsed = !this.isCollapsed;
  }

  ngOnInit(): void { }

  scroll() {
    // el: HTMLElement
    window.scrollTo(0,document.body.scrollHeight);
  }
  getfeature(){
    this.router.navigateByUrl('admin/feature')
  }
}
