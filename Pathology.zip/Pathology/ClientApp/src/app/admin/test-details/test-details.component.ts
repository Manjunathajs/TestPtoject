import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { usertestDetails } from 'src/model/userbody';

@Component({
  selector: 'app-test-details',
  templateUrl: './test-details.component.html',
  styleUrls: ['./test-details.component.scss']
})
export class TestDetailsComponent implements OnInit {
  Emailregex: RegExp =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  AddDataForm = this.fb.group({
    Email:new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
    Amount:new FormControl(''),
    testdiscription: new FormControl(''),
    Range:new FormControl('')
  })
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner :NgxSpinnerService) { }

  ngOnInit(): void {
  }
  onAddtest(){
this._spinner.show();
    let createuser = new usertestDetails()
    {
      createuser.Email =this.AddDataForm.get('Email')?.value;
      createuser.testdiscription =this.AddDataForm.get('testdiscription')?.value;
      createuser.Amount =Number(this.AddDataForm.get('Amount')?.value);
      createuser.Range =this.AddDataForm.get('Range')?.value;
      this.service.Addtestbilldetails(createuser).subscribe((res:any)=>{
        console.log("hello",res);
        this._spinner.hide();
        if(res.status=='success'){
         alert('test details added successfully')
         this.AddDataForm.reset();
          
        }
        else{
          console.log("hi")
          alert(res.message)
        }
        })
    }
  }
}
