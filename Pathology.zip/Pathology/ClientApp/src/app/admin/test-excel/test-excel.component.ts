import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import * as XLSX from 'xlsx';
type AOA = any[][];
@Component({
  selector: 'app-test-excel',
  templateUrl: './test-excel.component.html',
  styleUrls: ['./test-excel.component.scss']
})
export class TestExcelComponent implements OnInit {
  displayedColumns: string[] = ['SNo', 'ExcelSheet'];
  dataSource: MatTableDataSource<any> = new MatTableDataSource<any>([]);
  data: AOA = [[1, 2], [3, 4]];
  wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
  fileName: string = 'SheetJS.xlsx';
  addproduct = this.fb.group({
   fileupload:new FormControl('',[Validators.required]),
});
uploadFile:any;
  constructor(private fb:FormBuilder,private service:AppserviceService, private _spinner: NgxSpinnerService,private sanitizer: DomSanitizer) { }

  ngOnInit(): void {
       
  }
  uploadFileEvt(event: any):void {
    let file = event.target.files[0];
    this.uploadFile=file;
    this.addproduct.get('fileupload')?.setValue(file);
    let fileReader: FileReader = new FileReader();
  //  let data= fileReader.readAsText( this.addproduct.get('fileupload')?.value)
  }

  AddPackageExcel(){
    this._spinner.show();
    let formData: FormData = new FormData();
    formData.append('DataFiles',this.uploadFile)
    this.service.AddPackage(formData).subscribe((res:any)=>{
      console.log("hello",res);
      this._spinner.hide();
      if(res.status=='success'){
  alert("Package Details updated successfully"); 
  this.addproduct.reset();
      }
      else{
        alert(res.message);
      }
    })
    
  }
  AddTestExcel(){
    this._spinner.show();
    let formData: FormData = new FormData();
    formData.append('DataFiles',this.uploadFile)
    this.service.AddTest(formData).subscribe((res:any)=>{
      console.log("hello",res);
      this._spinner.hide();
      if(res.status=='success'){
  alert('test details added successfully')
  this.addproduct.reset();
      }
      else{
        alert(res.message);
      }
    })
  }

}



















  