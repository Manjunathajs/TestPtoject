
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';

@Component({
  selector: 'app-update-template',
  templateUrl: './update-template.component.html',
  styleUrls: ['./update-template.component.scss']
})
export class UpdateTemplateComponent implements OnInit {
  Emailregex: RegExp =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  Upadtetemplate = this.fb.group({
    Id:new FormControl(''),
    Template:new FormControl('',[Validators.required])
  })
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  uploadFile: any;
  testName:any;
  testAccess: any;
  testCode: any;
  regPhoneNumber: any;
  regAddress: any;
  regPassword: any;
  constructor(private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService,private fb:FormBuilder) { }

  ngOnInit(): void {
  }

  clickhome(){
    this._spinner.show()
    this.router.navigateByUrl('admin/home-page');
    this._spinner.hide();
  }
  uploadFileEvt(event: any):void {
    let file = event.target.files[0];
    this.uploadFile=file;
    this.Upadtetemplate.get('Template')?.setValue(file);
    let fileReader: FileReader = new FileReader();
  //  let data= fileReader.readAsText( this.addproduct.get('fileupload')?.value)
  }
  ongetsignup(){
    this._spinner.show();
      this.testCode =this.Upadtetemplate.get('Id')?.value;
        let formData: FormData = new FormData();
          formData.append('Id',this.testCode)
          formData.append('Template',this.uploadFile)
          console.log(formData)
          this.service.updatetamplate(formData).subscribe((res:any)=>{
            console.log("hello",res);
            this._spinner.hide();
            window.location.reload();
            if(res.status=='success'){
             console.log("hi");
             alert('template added successfully')
             this.Upadtetemplate.reset();
             
            }
            else{
              this._spinner.hide();
              console.log("hi")
              alert(res.message)
            }
            })
        
      }
}