import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { MatTableDataSource } from '@angular/material/table';
import { userNumber } from 'src/model/userbody';

export interface UserData {
 Name:string;
 Email:string;
 PhoneNumber:string;

}
@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrls: ['./userdetails.component.scss']
})
export class UserdetailsComponent implements OnInit {
  displayedColumns: any[] = ['Name','Email','Phonenumber'];
  dataSource = new MatTableDataSource<any>([]);
  PhoneNumberForm = this.fb.group({
    Phonenumber: ['', Validators.required,Validators.min(10)],

  })
  constructor(private fb: FormBuilder, private service: AppserviceService, private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
  }
  GetUserDetails(){
    if (this.PhoneNumberForm.get("Phonenumber")?.value) {
      const PhoneNumber = new userNumber();
      PhoneNumber.Phonenumber = this.PhoneNumberForm.get("Phonenumber")?.value;
      // this.spinner.show();
      this.service.getUserList(PhoneNumber).subscribe((res:any) => {

        if (res.status == 'success') {
          console.log("hello hi the output is",res.data);
          this.dataSource.data = res.data;
          this.spinner.hide();
         }
        else {
          this.spinner.hide();
        }
        console.log("hello hi the output is",res.data);
      })
    }
    else {
      alert("Please enter the phone number to check their details");
    }
  }
}


