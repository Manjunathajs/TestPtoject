import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AddTestParametersComponent } from './admin/add-test-parameters/add-test-parameters.component';
import { AddingtestmanualComponent } from './admin/addingtestmanual/addingtestmanual.component';
import { AddtemplateComponent } from './admin/addtemplate/addtemplate.component';
import { AdminModule } from './admin/admin.module';
import { HomePageComponent } from './admin/home-page/home-page.component';
import { MainloginComponent } from './admin/mainlogin/mainlogin.component';
import { SharedComponent } from './admin/shared/shared.component';
import { TestDetailsComponent } from './admin/test-details/test-details.component';
import { TestExcelComponent } from './admin/test-excel/test-excel.component';
import { UpdateTemplateComponent } from './admin/update-template/update-template.component';
import { UserdetailsComponent } from './admin/userdetails/userdetails.component';
import { LoginComponent } from './login/login.component';
import { MianHomePageComponent } from './mian-home-page/mian-home-page.component';
import { AddDocDetailsComponent } from './user/add-doc-details/add-doc-details.component';
import { AddemployeesComponent } from './user/addemployees/addemployees.component';
import { BillReportPDFComponent } from './user/bill-report-pdf/bill-report-pdf.component';
import { BillWithoutHeaderComponent } from './user/bill-without-header/bill-without-header.component';
import { DashBoardComponent } from './user/dash-board/dash-board.component';
import { EditedBySpecialistComponent } from './user/edited-by-specialist/edited-by-specialist.component';
import { EditpatientreportComponent } from './user/editpatientreport/editpatientreport.component';
import { GetPatientBillRecordsComponent } from './user/get-patient-bill-records/get-patient-bill-records.component';
import { GetPatientReportComponent } from './user/get-patient-report/get-patient-report.component';
import { GetpatientreportpdfComponent } from './user/getpatientreportpdf/getpatientreportpdf.component';
import { GetpdfwithheaderComponent } from './user/getpdfwithheader/getpdfwithheader.component';
import { IndirectBillingComponent } from './user/indirect-billing/indirect-billing.component';
import { PacientReportComponent } from './user/pacient-report/pacient-report.component';
import { PasswordresetComponent } from './user/passwordreset/passwordreset.component';
import { PatientBillComponent } from './user/patient-bill/patient-bill.component';
import { PatientDetailsComponent } from './user/patient-details/patient-details.component';
import { PdfmakerComponent } from './user/pdfmaker/pdfmaker.component';
import { SpecialistEmpComponent } from './user/specialist-emp/specialist-emp.component';
import { TesterEmpComponent } from './user/tester-emp/tester-emp.component';
import { UserModule } from './user/user.module';
import { UserhomepageComponent } from './user/userhomepage/userhomepage.component';
import { ViewpackagedetailsComponent } from './user/viewpackagedetails/viewpackagedetails.component';

const routes: Routes = [
  {
    path: "**",
    redirectTo: 'LABLIFE/home',
    pathMatch: 'prefix',
  },
  {
    path:'LABLIFE',
    children:[
      {
        path:'home',
        component:LoginComponent
      },
      {
        path:'adminLogin',
        component:AdminLoginComponent
      }
    ]
  },
  {
    path:'',
    loadChildren:()=>import('./admin/admin.module').then(m=>m.AdminModule)
  },
  {
    path: '',
    loadChildren: () => import('./user/user.module').then(m => m.UserModule)
  },
  {
    path:'admin',
    children:[
      {
        path:'home-page',
        component:HomePageComponent
      },
      {
        path:'userdetails',
        component:UserdetailsComponent
      },
      {
        path:'test-details',
        component:TestDetailsComponent
      },
      {
        path:'test-excel',
        component:TestExcelComponent
      },
      {
        path:'addingtestmanual',
        component:AddingtestmanualComponent
      },
      {
        path:'add-test-parameters',
        component:AddTestParametersComponent
      },
      {
        path:'shared',
        component:SharedComponent
      },
      {
          path:'login',
          component:MainloginComponent
      },
      {
        path:'addtemplate',
        component:AddtemplateComponent
      },
      {
        path:'update-template',
        component:UpdateTemplateComponent
      }

     
    ]},
    {
      path:'user',
      children:[
        {
          path:'dash-board',
          component:DashBoardComponent
        },
        {
          path:'userhomepage',
          component:UserhomepageComponent
        },
        {
          path:'patient-details',
          component:PatientDetailsComponent
        },
        {
          path:'patient-bill',
          component:PatientBillComponent
        },
        {
          path:'pacient-report',
          component:PacientReportComponent
        },
        {
          path:'get-patient-report',
          component:GetPatientReportComponent
        },
        {
          path:'get-patient-bill-records',
          component:GetPatientBillRecordsComponent
        },
        {
          path:'bill-report-pdf',
          component:BillReportPDFComponent
        },
        {
          path:'add-doc-details',
         component:AddDocDetailsComponent
        },
        {
          path:'getpatientreportpdf',
          component:GetpatientreportpdfComponent
        },
        {
          path:'viewpackagedetails',
          component:ViewpackagedetailsComponent
        },
        {
          path:'bill-without-header',
          component:BillWithoutHeaderComponent
        },
        {
          path:'getpdfwithheader',
          component:GetpdfwithheaderComponent
        },
        {
          path:'addemployees',
          component:AddemployeesComponent
        },
        {
          path:'specialist-emp',
          component:SpecialistEmpComponent
        },
        {
          path:'tester-emp',
          component:TesterEmpComponent
        },
        {
          path:'editpatientreport',
          component:EditpatientreportComponent
        },
        {
          path:'edited-by-specialist',
          component:EditedBySpecialistComponent
        },
        {
          path:'passwordreset',
          component:PasswordresetComponent
        },
        {
          path:'pdfmaker',
          component:PdfmakerComponent
        },
        {
          path:'login',
          component:MainloginComponent
      },
      {
        path:'indirect-billing',
        component:IndirectBillingComponent
      }

      ]}

];

@NgModule({
  imports: [RouterModule.forRoot(routes), AdminModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
