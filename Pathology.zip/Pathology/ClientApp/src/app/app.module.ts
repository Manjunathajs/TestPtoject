import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import {BrowserAnimationsModule} from'@angular/platform-browser/animations';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { MatSliderModule } from '@angular/material/slider'; 
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
// import { MatFormFieldModule } from '@angular/material/form-field';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { PdfViewerModule  }  from  'ng2-pdf-viewer';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MDBBootstrapModule } from "angular-bootstrap-md";
import { IgxDatePickerModule } from "igniteui-angular";
import { NgxSpinnerModule } from 'ngx-spinner';
import { MatSelectFilterModule } from 'mat-select-filter';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { MianHomePageComponent } from './mian-home-page/mian-home-page.component';
import {MatPaginatorModule} from '@angular/material/paginator';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AdminLoginComponent,
    MianHomePageComponent
  ],
  imports: [
    BrowserModule,
    MatIconModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatSliderModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    RouterModule,
    MatCardModule,
    // MatFormFieldModule,
    MatCardModule,
    // MatFormFieldModule,
    MatToolbarModule,
    MatSelectModule,
    PdfViewerModule,
    MatDatepickerModule,
    MDBBootstrapModule.forRoot(),
    IgxDatePickerModule,
    NgxSpinnerModule,
    MatSelectFilterModule,
    MatPaginatorModule
    
    
  ],
  providers: [{ provide: 'BASE_URL', useFactory: getBaseUrl, deps: [] }],
  bootstrap: [AppComponent]
})
export class AppModule { }
export function getBaseUrl() {
  return document.getElementsByTagName('base')[0].href;
}
