import { Inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Router } from '@angular/router';
// import * as FileSaver from 'file-saver';
// import * as XLSX from 'xlsx';
import { AddEmployees, addnewpackage, addtestmanually, Addtestparameter, Adminregister, contactus, EmailId, getreport, loginbody, newBillstatus, paceintNumber, ReportDetails, sendmessage1, temppassword, userbody, userNumber, usertestDetails } from 'src/model/userbody';
import { Observable } from 'rxjs';

const EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
const EXCEL_EXTENSION = '.xlsx';
@Injectable({
  providedIn: 'root'
})
export class AppserviceService {
  baseUrlString = '';
  userdataforwithdraw: any;
  constructor(private https: HttpClient, @Inject('BASE_URL') baseurl: string, private router: Router) {
    this.baseUrlString = baseurl;
  }

  // public exportAsExcelFile(json: any[], excelFileName: string): void {
  //   const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
  //   const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
  //   const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  //   this.saveAsExcelFile(excelBuffer, excelFileName);
  // }
  // private saveAsExcelFile(buffer: any, fileName: string): void {
  //   const data: Blob = new Blob([buffer], { type: EXCEL_TYPE });
  //   FileSaver.saveAs(data, fileName + '_export_' + new Date().getTime() + EXCEL_EXTENSION);
  // }

  signin(data: loginbody) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/login`;
    return this.https.post(url, data)
  }
  resetpassword(data: any) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/PasswordReset`;
    return this.https.post(url, data)
  }
  confirmpasswordreset(data: any) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/confirmpassword`;
    return this.https.post(url, data)
  }
  enplogin(data: loginbody) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/emplogin`;
    return this.https.post(url, data)
  }
  Adddetails(data: userbody) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/adddetails`;
    return this.https.post(url, data)
  }
  patientpaymentstaus(data: newBillstatus) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/Addpatientpaymentstatus`;
    return this.https.post(url, data)
  }
  patientreportstaus(data: newBillstatus) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/Addreportdata`;
    return this.https.post(url, data)
  }
  postuser(data: any) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/PostUsers`;
    return this.https.post(url, data)
  }
  posttamplate(data: any) {
    console.log(data)
    const url = `${this.baseUrlString}api/Template/AddTemplate`;
    return this.https.post(url, data)
  }
  updatetamplate(data: any) {
    console.log(data)
    const url = `${this.baseUrlString}api/Template/updateTemplate`;
    return this.https.post(url, data)
  }
  postemployees(data: AddEmployees) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/PostEmployees`;
    return this.https.post(url, data)
  }
  Addtestmanully(data: addtestmanually) {
    console.log(data)
    const url = `${this.baseUrlString}api/AddTest/AddTestManuallyother`;
    return this.https.post(url, data)
  }
  AddtestParameter(data: Addtestparameter) {
    const url = `${this.baseUrlString}api/AddTest/AddTestParameters`;
    return this.https.post(url, data)
  }
  postemployeestester(data: AddEmployees) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/PostEmployeestester`;
    return this.https.post(url, data)
  }
  getUserList(data: userNumber) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/getUserData`;
    return this.https.post(url, data)
  }
  UserDataList(data: EmailId) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/Listofpecient`;
    console.log(data)
    return this.https.post(url, data)
  }
  getPatientListData(data: userNumber) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/PatientData`;
    console.log(data)
    return this.https.post(url, data)
  }
  PatientReportData(data: ReportDetails) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/ListOfPendingReport`;
    console.log(data)
    return this.https.post(url, data)
  }
  PatientBillData(data: ReportDetails) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/ListOfPendingBill`;
    console.log(data)
    return this.https.post(url, data)
  }
  AllPatientReportData(data: ReportDetails) {
    const url = `${this.baseUrlString}api/Auth/listofallpatientreport`;
    return this.https.post(url, data)
  }
  PendingApproval(data: ReportDetails) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/ListOfPendingApproval`;
    console.log(data)
    return this.https.post(url, data)
  }

  getpatientwithPhoneNumberList(data: paceintNumber) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/getpatientDatawithNumber`;
    return this.https.post(url, data)
  }
  getreportdata(data: any) {
    const url = `${this.baseUrlString}api/Auth/Getreport/${data}`;
    return this.https.get(url)
  }
  Addtestbilldetails(data: usertestDetails) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/AddTestList`;
    return this.https.post(url, data)
  }
  Addtestreportdetails(data: ReportDetails) {
    console.log(data)
    const url = `${this.baseUrlString}api/Auth/AddTestReport`;
    return this.https.post(url, data)
  }
  GetDropDownList() {
    const url = `${this.baseUrlString}api/Auth/ListOfTest`;
    return this.https.get(url)
  }
  GetDropDownPackageList() {
    const url = `${this.baseUrlString}api/Auth/ListOfPackages`;
    return this.https.get(url)
  }
  GetPackageList() {
    const url = `${this.baseUrlString}api/Auth/ListOfPackages`;
    return this.https.get(url)
  }
  GetDropDownDoctorList() {
    const url = `${this.baseUrlString}api/Auth/ListOfDocDetails`;
    return this.https.get(url)
  }
  AddPackage(data: any) {
    const url = `${this.baseUrlString}api/AddTest/AddPackageDetails`;
    console.log(data)
    return this.https.post(url, data)
  }
  AddTest(data: any) {
    const url = `${this.baseUrlString}api/AddTest/AddTestDetails`;
    console.log(data)
    return this.https.post(url, data)
  }
  AddDocDetails(data: any) {
    const url = `${this.baseUrlString}api/Auth/AddDoctorDetails`;
    console.log(data)
    return this.https.post(url, data)
  }
  Addbill(data: any) {
    const url = `${this.baseUrlString}api/Auth/AddPatientBill`;
    console.log(data)
    return this.https.post(url, data)
  }
  Addbillwithoutheader(data: any) {
    const url = `${this.baseUrlString}api/Auth/AddPatientBillwithoutheader`;
    console.log(data)
    return this.https.post(url, data)
  }
  AddtestDetails(data: any) {
    const url = `${this.baseUrlString}api/Auth/AddTestReport`;
    console.log(data)
    return this.https.post(url, data)
  }
  AddReport(data: any) {
    const url = `${this.baseUrlString}api/Auth/AddPatientReport`;
    console.log(data)
    return this.https.post(url, data)
  }
  testeredited(data: any) {
    const url = `${this.baseUrlString}api/Auth/testeredit`;
    console.log(data)
    return this.https.post(url, data)
  }
  reportApporved(data: any) {
    const url = `${this.baseUrlString}api/Auth/ApprovedStatus`;
    console.log(data)
    return this.https.post(url, data)
  }

  rejectlist(data: any) {
    const url = `${this.baseUrlString}api/Auth/RejectingReport`;
    console.log(data)
    return this.https.post(url, data)
  }
  addpacakgenew(data: addnewpackage) {
    const url = `${this.baseUrlString}api/AddTest/AddPackage`;
    console.log(data)
    return this.https.post(url, data)
  }

  checkRecordData(data: any) {
    const url = `${this.baseUrlString}api/Auth/BillData/${data}`;
    return this.https.get(url)
  }
  checkrecordwithoutheader(data: any) {
    const url = `${this.baseUrlString}api/Auth/BillDatawithout/${data}`;
    return this.https.get(url)
  }
  checkBillPDF(data: any) {
    const url = `${this.baseUrlString}api/Auth/BillPDF/${data}`;
    return this.https.get(url)
  }
  checkBillPDFwithheader(data: any) {
    const url = `${this.baseUrlString}api/Auth/BillPDF/${data}`;
    return this.https.get(url)
  }
  checkBillPDFwithoutheader(data: any) {
    const url = `${this.baseUrlString}api/Auth/getpdfwithoutheader/${data}`;
    return this.https.get(url)
  }
  checkreportpdf(data: any) {
    const url = `${this.baseUrlString}api/Auth/reportPDF/${data}`;
    return this.https.get(url)
  }
  gettestreportdata(data: any) {
    const url = `${this.baseUrlString}api/Auth/Getreportdata`;
    console.log(data)
    return this.https.post(url, data)
  }
  Edittestreport(data: any) {
    const url = `${this.baseUrlString}api/Auth/getApprovalPending`;
    return this.https.post(url, data)
  }

  Edittesterreport1(data: any) {
    const url = `${this.baseUrlString}api/Auth/Gettestlist`;
    return this.https.post(url, data)
  }

  Getreportstatus(data: any) {
    const url = `${this.baseUrlString}api/Auth/getpatientstatus/${data}`;
    return this.https.get(url)
  }
  
  getemployeedetails(data: any) {
    const url = `${this.baseUrlString}api/Auth/getemployeeData/${data}`;
    return this.https.get(url)
  }

  getcontactlist(data: any) {
    const url = `${this.baseUrlString}api/Auth/getcontactlist/${data}`;
    return this.https.get(url)
  }

  getreportpdfdata(data: any): Observable<Blob> {
    const url = `${this.baseUrlString}api/Template/GetReport/${data}`;
    return this.https.get(url, { responseType: 'blob' })
  }

  checktimeout(data: any) {
    const url = `${this.baseUrlString}api/Auth/verifytoken`;
    return this.https.post(url, data)
  }

  addcontactusdata(data: contactus) {
    const url = `${this.baseUrlString}api/Auth/addcontactus`;
    return this.https.post(url, data)
  }

  sendcontactmessage(data: sendmessage1) {
    const url = `${this.baseUrlString}api/Auth/sendresponse`;
    return this.https.post(url, data)
  }
}
