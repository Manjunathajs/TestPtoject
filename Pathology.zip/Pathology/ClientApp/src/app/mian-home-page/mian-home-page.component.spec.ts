import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MianHomePageComponent } from './mian-home-page.component';

describe('MianHomePageComponent', () => {
  let component: MianHomePageComponent;
  let fixture: ComponentFixture<MianHomePageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MianHomePageComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MianHomePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
