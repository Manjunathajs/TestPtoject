import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { loginbody, temppassword } from 'src/model/userbody';
import { AppserviceService } from '../appservice.service';

@Component({
  selector: 'app-mian-home-page',
  templateUrl: './mian-home-page.component.html',
  styleUrls: ['./mian-home-page.component.scss']
})
export class MianHomePageComponent implements OnInit {
  loginForm=this.fb.group({
    username:[null],
    password:[null]});
    empdata:any;
    showSignin=false;
    showSignup=false;
    style: any;
    isLoading=true;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner :NgxSpinnerService) { }

  ngOnInit(): void {
  }


  ongetsignin()
  {

    // console.log(this.loginForm.getRawValue())
    if(this.loginForm.get('username')?.value==null || this.loginForm.get('password')?.value==null ){
      alert("Please Enter Fields Manually !!");
    }
    
    else{
      this._spinner.show();
      const createuser=new loginbody();
      createuser.EmailId=this.loginForm.get('username')?.value;
      createuser.Password=this.loginForm.get('password')?.value;
      
      this.service.signin(createuser).subscribe((res:any)=>{
        console.log("hello",res);
        if(res.status=='success'){
          this._spinner.hide();
          localStorage.setItem('LoggedInUser', JSON.stringify(res.data));
          // let userData=JSON.stringify(res.data)

          console.log("hello hi",res.data.role);
          console.log("hello hi",res.data['role']);
          // this.router.navigateByUrl('user/userhomePage');
          if(res.data.role==2){
            alert('')
          }
         if(res.data.role==1){
            console.log("hi in")
            this.router.navigateByUrl('user/dash-board');
          }
          if(res.data.role==5){
            console.log("hi in")
            this.router.navigateByUrl('user/passwordreset');
          }
              
          this._spinner.hide();
        }
        else{
            this.service.enplogin(createuser).subscribe((res:any)=>{
              if(res.status=='success'){
                this._spinner.hide();
                localStorage.setItem('LoggedInUser', JSON.stringify(res.data));
              this.empdata = res.data;
              if(this.empdata.role == 3){
                this.router.navigateByUrl('user/specialist-emp');
              }
              if(this.empdata.role == 4){
                this.router.navigateByUrl('user/tester-emp');
              }
            }
            else if(this.empdata==null){
            alert('please provide correct email and password')
            }
            })
            this._spinner.hide();
          }
      })
    }
    
  }
  forgetpassword(){
    const passwordreset = new temppassword();
    passwordreset.userEmail=this.loginForm.get('username')?.value;
    this.service.resetpassword(passwordreset).subscribe((res:any)=>{
console.log(res)
alert('Temportary Password Has Sent To Your Mail')
    })
    console.log("password reset")
  }

}
