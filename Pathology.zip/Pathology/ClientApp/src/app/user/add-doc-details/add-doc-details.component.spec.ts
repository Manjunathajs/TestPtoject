import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddDocDetailsComponent } from './add-doc-details.component';

describe('AddDocDetailsComponent', () => {
  let component: AddDocDetailsComponent;
  let fixture: ComponentFixture<AddDocDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddDocDetailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddDocDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
