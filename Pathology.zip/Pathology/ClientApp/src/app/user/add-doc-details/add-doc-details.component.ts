import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { DoctorDetails, TokenNumber } from 'src/model/userbody';

@Component({
  selector: 'app-add-doc-details',
  templateUrl: './add-doc-details.component.html',
  styleUrls: ['./add-doc-details.component.scss']
})
export class AddDocDetailsComponent implements OnInit {
  addproduct = this.fb.group({
    Email:new FormControl('',[Validators.email,Validators.required,Validators.min(4)]),
    DoctorName:new FormControl('',[Validators.required]),
    HospitalName:new FormControl('',[Validators.required]),
    DocAddress:new FormControl('',[Validators.required]),
    
  })
  hospitalname:any;
  doctorname:any;
  uploadFile:any;
  checkdata:any;
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  hospitalName!:String;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService, private _spinner: NgxSpinnerService,private sanitizer: DomSanitizer) { 
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.checkdata=res.data
       console.log(this.checkdata)
       if(this.checkdata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
  }

  ngOnInit(): void {
    // this.uploadFileEvt;
  }

  // uploadFileEvt(event: any):void {
  //   let file = event.target.files[0];
  //   this.uploadFile=file;
  //   this.addproduct.get('fileupload')?.setValue(file);
  //   let fileReader: FileReader = new FileReader();
  //   // this.data= fileReader.readAsText( this.addproduct.get('fileupload')?.value)
  // }
  onAddDocData(){
    this._spinner.show();
    let AddDetails = new DoctorDetails();
     AddDetails.Email=this.userdetails.email;
     AddDetails.DoctorName=this.addproduct.get('DoctorName')?.value;
     AddDetails.HospitalName=this.addproduct.get('HospitalName')?.value;
     AddDetails.DocAddress=this.addproduct.get('DocAddress')?.value;
      this.service.AddDocDetails(AddDetails).subscribe((res:any)=>{
        this._spinner.hide();
        console.log("hello",res);
        if(res.status=='success'){
    alert("Details updated successfully") 
    window.location.reload();
        }
        });
        
    }
    clickhome(){
      this._spinner.show();
      console.log("hi")
      this.router.navigateByUrl('user/dash-board');
      this._spinner.hide();
    }
  }
  

