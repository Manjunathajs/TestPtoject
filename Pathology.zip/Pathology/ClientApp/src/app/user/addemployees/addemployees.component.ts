import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { AddEmployees, TokenNumber } from 'src/model/userbody';

@Component({
  selector: 'app-addemployees',
  templateUrl: './addemployees.component.html',
  styleUrls: ['./addemployees.component.scss']
})
export class AddemployeesComponent implements OnInit {
  displayedColumns: any[] = ['Name','Email','MobileNumber','jobdiscription'];
  dataSource = new MatTableDataSource<any>([]);
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  Emailregex: RegExp =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
Addspicalist=this.fb.group({
  userEmail: new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
  Name:new FormControl(''),
  MobileNumber:new FormControl('',[Validators.minLength(10) ,Validators.maxLength(10)]),
  Email:new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
  Password:new FormControl('')
})
Addtester=this.fb.group({
  userEmail: new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
  Name:new FormControl(''),
  MobileNumber:new FormControl('',[Validators.minLength(10) ,Validators.maxLength(10)]),
  Email:new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
  Password:new FormControl('')
})
specialist=false;
tester=false;
  checkdata: any;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.checkdata=res.data
       console.log(this.checkdata)
       if(this.checkdata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
   }

  ngOnInit(): void {
    this.getemplist();
  }

  specialistng(){
    this.specialist=true;
    this.tester=false;
  }
testerng(){
  this.specialist=false;
  this.tester=true;
}
  register(){

    this.Addspicalist.get('userEmail')?.setValue(this.userdetails.email);
    console.log(this.Addspicalist.getRawValue(),this.Addspicalist.valid,this.Addspicalist);
    if(this.Addspicalist.valid){
      this._spinner.show();
      let postspecialist = new AddEmployees()
      postspecialist.userEmail=this.userdetails.email;
      postspecialist.Name=this.Addspicalist.get('Name')?.value;
      postspecialist.MobileNumber=this.Addspicalist.get('MobileNumber')?.value?.toString();
      postspecialist.EmailId=this.Addspicalist.get('Email')?.value;
      postspecialist.Password=this.Addspicalist.get('Password')?.value;
      postspecialist.Jobdiscription="Specialist";
      this.service.postemployees(postspecialist).subscribe((res:any)=>{
        console.log("hello",res);
        this._spinner.hide();
        if(res.status=='Success'){
         console.log("hi");
         
         alert(res.message)
        }
        else{
          console.log("hi")
          alert(res.message)
        }
        })
        window.location.reload();
    }else{
      alert('please check all inputs');
    }

  }
  Registertester(){

    this.Addspicalist.get('userEmail')?.setValue(this.userdetails.email);
    console.log(this.Addspicalist.getRawValue(),this.Addspicalist.valid,this.Addspicalist);
    if(this.Addspicalist.valid){
      this._spinner.show();
    let posttester = new AddEmployees()
    posttester.userEmail=this.userdetails.email;
    posttester.Name=this.Addspicalist.get('Name')?.value;
    posttester.MobileNumber=this.Addspicalist.get('MobileNumber')?.value?.toString();
    posttester.EmailId=this.Addspicalist.get('Email')?.value;
    posttester.Password=this.Addspicalist.get('Password')?.value;
    posttester.Jobdiscription="Tester"
    this.service.postemployeestester(posttester).subscribe((res:any)=>{
      console.log("hello",res);
      if(res.status=='Success'){
       console.log("hi");
        this._spinner.hide();
        alert(res.message)
        window.location.reload();
      }
      else{
        console.log("hi")
        alert(res.message)
      }
      })
      // window.location.reload();
    }
    else{
      alert('Please Check the Input Fields')
    }
  }
  clickhome(){
    console.log("hi")
    this.router.navigateByUrl('user/dash-board');
  }
  getemplist(){
    this._spinner.show();
    this.service.getemployeedetails(this.userdetails.email).subscribe((res:any)=>{
      this._spinner.hide();
    this.dataSource.data=res.data;
    console.log(this.dataSource.data)
    })
  }
}
