import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillReportPDFComponent } from './bill-report-pdf.component';

describe('BillReportPDFComponent', () => {
  let component: BillReportPDFComponent;
  let fixture: ComponentFixture<BillReportPDFComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillReportPDFComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BillReportPDFComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
