import { Component, OnInit, ɵɵqueryRefresh } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { BillPDF, getbillpdf, newBillstatus, TokenNumber } from 'src/model/userbody';
import { useState } from "react";

@Component({
  selector: 'app-bill-report-pdf',
  templateUrl: './bill-report-pdf.component.html',
  styleUrls: ['./bill-report-pdf.component.scss']
})

export class BillReportPDFComponent implements OnInit {
  InvoiceForm = this.fb.group({
    InvoiceNumber: ['', Validators.required],
  })

  dataLocalUrl: any;
  selectedFeatures: any = [];
  filename = 'Angular 5';
  fileUrl:any;
  docDefinition:any;
  image:any;
  pdfbill:any;
  source:any;
  source1:any;
  pdfHref:any;
  reader:any;
  pdfSrc:any;
  pdfSrc1 :any;
  pageVariable = 1;
  nav:any;
  downloadpdf =false;
  statusdata:any;
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  checkdata: any;
  constructor(private sanitizer: DomSanitizer,private fb:FormBuilder,private router:Router,private service:AppserviceService,private spinner: NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.checkdata=res.data
       console.log(this.checkdata)
       if(this.checkdata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
  }

  ngOnInit(): void {
    const invoiceNumber=window.location.href.split('=')[1];
    console.log(invoiceNumber);
    if(invoiceNumber!=null){
      this.InvoiceForm.get("InvoiceNumber")?.setValue(invoiceNumber);
      // this.getBillData()
      this.getBillPDF()
      this.senddata()
      }      
  }
  billstatus(data:any){
    this.statusdata=data;
      }
      senddata(){
    
        let Billstatus = new newBillstatus();
    Billstatus.Phonenumber = this.InvoiceForm.get("Phonenumber")?.value;
    // Billstatus.Billstatus = this.statusdata;
    this.service.patientpaymentstaus(Billstatus).subscribe((res:any)=>{
      let thedatastatus = res.data;
      console.log(thedatastatus)
    })
      
      }
  getBillPDF(){
    this.service.checkBillPDF(this.InvoiceForm.get("InvoiceNumber")?.value).subscribe((res: any) => {
      console.log(res.data)
      let docuData=res.data;
      console.log(docuData.dataFiles);

       this.nav = (window.navigator as any);
  if(this.nav.msSaveOrOpenBlob){ 
    let byteChar = window.atob(docuData.dataFiles);
    let byteArray = new Array(byteChar.length);
    for(let i = 0; i < byteChar.length; i++){
      byteArray[i] = byteChar.charCodeAt(i);
    }
    let uIntArray = new Uint8Array(byteArray);
    let blob = new Blob([uIntArray], {type : 'application/pdf'});
    this.nav.msSaveOrOpenBlob(blob, `${this.filename}.pdf`);
  } else {
    this.source = `data:application/pdf;base64,${docuData.dataFiles}`;
    const link = document.createElement("a");
    link.href = this.source;
    // link.download = `${this.filename}.pdf`;
  //  window.open(this.source);
    link.click(); 
  // link.click(); 

  }
})
 } 
 
 nextPage() {
  this.pageVariable++;
}

afterLoadComplete(pdf: any) {
  console.log('after-load-complete');
}

pageRendered(e: CustomEvent) {
  console.log('(page-rendered)', e);
}

textLayerRendered(e: CustomEvent) {
  console.log('(text-layer-rendered)', e);
}

onFileSelected() {
  let $img: any = document.querySelector('#file');

  if (typeof (FileReader) !== 'undefined') {
    let reader = new FileReader();

    reader.onload = (e: any) => {
      this.pdfSrc1 = e.target.result;
    };

    reader.readAsArrayBuffer($img.files[0]);
  }
}
downloadbill(){
this.downloadpdf=true;

  this.service.checkBillPDF(this.InvoiceForm.get("InvoiceNumber")?.value).subscribe((res: any) => {
    console.log(res.data)
    let docuData=res.data;
    console.log(docuData.dataFiles);

     this.nav = (window.navigator as any);
if(this.nav.msSaveOrOpenBlob){ 
  let byteChar = window.atob(docuData.dataFiles);
  let byteArray = new Array(byteChar.length);
  for(let i = 0; i < byteChar.length; i++){
    byteArray[i] = byteChar.charCodeAt(i);
  }
  let uIntArray = new Uint8Array(byteArray);
  let blob = new Blob([uIntArray], {type : 'application/pdf'});
  this.nav.msSaveOrOpenBlob(blob, `${this.filename}.pdf`);
} else {
  this.source1 = `data:application/pdf;base64,${docuData.dataFiles}`;
  const link = document.createElement("a");
  link.href = this.source;
  if(this.downloadpdf==true){
  link.download = `${this.filename}.pdf`;}
//  window.open(this.source);
  link.click(); 
// link.click(); 

}
})
}
}


