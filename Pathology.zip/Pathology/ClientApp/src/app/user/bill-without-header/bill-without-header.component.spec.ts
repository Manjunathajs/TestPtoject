import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BillWithoutHeaderComponent } from './bill-without-header.component';

describe('BillWithoutHeaderComponent', () => {
  let component: BillWithoutHeaderComponent;
  let fixture: ComponentFixture<BillWithoutHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BillWithoutHeaderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BillWithoutHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
