import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { billrecords, TokenNumber } from 'src/model/userbody';

@Component({
  selector: 'app-bill-without-header',
  templateUrl: './bill-without-header.component.html',
  styleUrls: ['./bill-without-header.component.scss']
})
export class BillWithoutHeaderComponent implements OnInit {
  displayedColumns: any[] = ['PatientEmail','Phonenumber','InvoiceNumber','BillDate'];
  dataSource = new MatTableDataSource<any>([]);
  EmailForm = this.fb.group({
    userEmail: ['', Validators.required],
  })
  dropDownData:any;
  dataLocalUrl:any;
  statusdata:any;
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  checkdata: any;
  constructor(private sanitizer: DomSanitizer,private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.checkdata=res.data
       console.log(this.checkdata)
       if(this.checkdata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
   }

  ngOnInit(): void {
    this.getbillrecords();
  }

  getbillrecords(){
    this._spinner.show();
    const userEmail = new billrecords();
    userEmail.userEmail = this.userdetails.email;
  this.service.checkrecordwithoutheader(this.userdetails.email).subscribe((res: any) => {
    this._spinner.hide();
    this.dataSource.data = res.data;
     console.log(this.dataSource.data)
  })
  }
}


