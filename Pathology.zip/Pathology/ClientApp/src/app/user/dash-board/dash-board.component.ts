import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { TokenNumber } from 'src/model/userbody';

@Component({
  selector: 'app-dash-board',
  templateUrl: './dash-board.component.html',
  styleUrls: ['./dash-board.component.scss']
})
export class DashBoardComponent implements OnInit {
  checkdata:any;
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  datafile: any;
  
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService,private sanitizer: DomSanitizer) { 
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.checkdata=res.data
       console.log(this.checkdata)
       if(this.checkdata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
    this.getlogo()
  }

  ngOnInit(): void {
  }
  Registration(){
this._spinner.show();
    this.router.navigateByUrl('user/patient-details');
this._spinner.hide();
  }
  GenrateBill(){
    this._spinner.show();
    this.router.navigateByUrl('user/patient-bill');
    this._spinner.hide();
  }
  Reportstatus(){
    this._spinner.show();
    this.router.navigateByUrl('user/userhomepage');
    this._spinner.hide();
  }

  Billinvoice(){
    this._spinner.show();
    this.router.navigateByUrl('user/get-patient-bill-records');
    this._spinner.hide();
  }
  Logout(){
    this._spinner.show();
    console.log("hi")
    // localStorage.removeItem('LoggedInUser');
    localStorage.clear();
    this.router.navigateByUrl('admin/login');
    this._spinner.hide();
  }
  veiwpackagedetails(){
    this._spinner.show();
    this.router.navigateByUrl('user/viewpackagedetails');
    this._spinner.hide();
  }
  Reportinvoice(){
    this._spinner.show();
    this.router.navigateByUrl('user/get-patient-report');
    this._spinner.hide();
  }
  Adddoctordetails(){
    this._spinner.show();
    this.router.navigateByUrl('user/add-doc-details');
    this._spinner.hide();
  }
  Billwithoutheader(){
    this._spinner.show();
    this.router.navigateByUrl('user/bill-without-header');
    this._spinner.hide();
  }
  Generatereport(){
    this._spinner.show();
    this.router.navigateByUrl('user/pacient-report');
    this._spinner.hide();
  }
  AddEmployees(){
    this._spinner.show();
    this.router.navigateByUrl('user/addemployees');
    this._spinner.hide();
  }
  anybutton(){
    this._spinner.show();
    this.router.navigateByUrl('user/scorall');
    this._spinner.hide();
  }
  getlogo(){
    let objectURL = 'data:image/png;base64,'+this.userdetails.datafiles
    this.datafile =this.sanitizer.bypassSecurityTrustResourceUrl(objectURL);
  }
  GetPdf(){
    this._spinner.show();
    this.router.navigateByUrl('user/pdfmaker');
    this._spinner.hide();
  }
  getindirectbilling(){
    this._spinner.show();
    this.router.navigateByUrl('user/indirect-billing');
    this._spinner.hide();
  }
}
