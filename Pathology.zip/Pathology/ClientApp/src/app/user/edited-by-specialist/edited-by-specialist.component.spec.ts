import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditedBySpecialistComponent } from './edited-by-specialist.component';

describe('EditedBySpecialistComponent', () => {
  let component: EditedBySpecialistComponent;
  let fixture: ComponentFixture<EditedBySpecialistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditedBySpecialistComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditedBySpecialistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
