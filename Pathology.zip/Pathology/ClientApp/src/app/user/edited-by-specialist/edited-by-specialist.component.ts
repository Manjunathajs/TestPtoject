import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { BillPDF, BillPDF1, TestDetails, TokenNumber } from 'src/model/userbody';

class Product{
  name: any;
  price: any;
  testcode:any;
  packagename:any;
  qty:any;
  result:any;
}
class Invoice{
  customerName: any;
  address: any;
  contactNo: any;
  email: any;
  DoctorName:any;
  Age:any;
  Gender:any;
  
  products: Product[] = [];
  additionalDetails: any;
 }
@Component({
  selector: 'app-edited-by-specialist',
  templateUrl: './edited-by-specialist.component.html',
  styleUrls: ['./edited-by-specialist.component.scss']
})
export class EditedBySpecialistComponent implements OnInit {
  specilistadvice = this.fb.group({
    interpretation:new FormControl('')
  })
  invoice = new Invoice(); 
  testdetails:any = [];
  edittestGroup:any=[];
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  InvoiceForm = this.fb.group({
    InvoiceNumber: ['', Validators.required],
    
  })
  checkdata: any;
  testGroup:any=[];
  viewtest=true;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    const invoiceNumber=window.location.href.split('=')[1];
    console.log(invoiceNumber);
    if(invoiceNumber!=null){
      this.InvoiceForm.get("InvoiceNumber")?.setValue(invoiceNumber);
      this.Reportdetails()
      this.getdataoftest()
      } 
  }
  ondelete(deleteme: number) {
    this.invoice.products.splice(deleteme,1);
       }
Reportdetails(){
  this._spinner.show();
  var inv=new BillPDF();
  inv.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value;
  this.service.Edittestreport(inv).subscribe((res: any) => {
  this.testdetails = res.data;
  this._spinner.hide();
  console.log(this.testdetails)
  this.testdetails.forEach((element:any)=>{
    if(element.subTestGroup == null)
    {
      this.testGroup.push(element.subTestGroup1)
    }        
    else if(element.subTestGroup1==null)
    {
      this.testGroup.push(element.subTestGroup)
    }
  });
        })
       }
       savepdf(){
         this._spinner.show();
         console.log(this.testGroup)
       let testdetailsList: TestDetails[]=[];
this.edittestGroup.forEach((getdata:any)=>{
getdata.forEach((letdata:any)=>{
  let testdetails = new TestDetails()
  testdetails.testdiscription=letdata.testdiscription;
  testdetails.subtest=letdata.name;
  testdetails.result = this.specilistadvice.get('interpretation')?.value;
  testdetails.reportstatus="Approved"
  testdetails.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value?.toString();
  testdetailsList.push(testdetails)
})
})
       console.log(testdetailsList)
        this.service.reportApporved(testdetailsList).subscribe((res: any) => {
          this._spinner.hide()
        console.log(res.data)
        window.location.reload();
              })
       }

       Rejectreport(){
         this._spinner.show();
        let testdetailsList: TestDetails[]=[];
        this.edittestGroup.forEach((getdata:any)=>{
          getdata.forEach((letdata:any)=>{
            let testdetails = new TestDetails()
            testdetails.testdiscription=letdata.testdiscription;
            testdetails.subtest=letdata.subtest;
            testdetails.result = this.specilistadvice.get('interpretation')?.value;
            testdetails.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value?.toString();
            testdetailsList.push(testdetails)
           })
        })
        console.log(testdetailsList)
        this.service.rejectlist(testdetailsList).subscribe((res: any) => {
          this._spinner.hide();
        console.log(res.data)
        window.location.reload();
              })
        
       }
       BackButton(){
         this._spinner.show();
        this.router.navigateByUrl('user/specialist-emp');
        this._spinner.hide();
       }

       gettestvalue(data:any){
         this._spinner.show();
        console.log(data);
              var inv=new BillPDF();
              inv.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value;
              console.log(inv);
               this.edittestGroup=[];
              this.testdetails.forEach((element:any) => {
                if(element.testName==data){
        this.edittestGroup.push(element.subTestGroup1);
                }
              });
              if(this.edittestGroup != []){
                this.viewtest = false;
              }
        console.log(this.edittestGroup)
        this._spinner.hide();
               }

               getdataoftest(){
                 this._spinner.show();
                 this.viewtest=true;
                var inv=new BillPDF1();
                inv.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value;
                this.service.Edittestreport(inv).subscribe((res: any) => {
                this.testdetails = res.data;
                console.log(this.testdetails)
                if(this.testdetails[0] == null){
                  this.router.navigateByUrl('user/specialist-emp');
                }
                 this.testGroup=[];
                this.testdetails.forEach((element:any)=>{
                 
                  if(element.subTestGroup == null)
                  {
                    this.testGroup.push(element.subTestGroup1)
                  }        
                  else if(element.subTestGroup1 == null)
                  {
                    this.testGroup.push(element.subTestGroup)
                  }
                
                 
                });
                
          // console.log(this.subtestdata)
          
          })
          this._spinner.hide();
               }
}
