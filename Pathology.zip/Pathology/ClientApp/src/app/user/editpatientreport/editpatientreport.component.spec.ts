import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditpatientreportComponent } from './editpatientreport.component';

describe('EditpatientreportComponent', () => {
  let component: EditpatientreportComponent;
  let fixture: ComponentFixture<EditpatientreportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditpatientreportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EditpatientreportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
