import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { BillPDF, BillPDF1, TestDetails, TokenNumber } from 'src/model/userbody';

class Product{
  name: any;
  price: any;
  testcode:any;
  units:any;
  packagename:any;
  qty:any;
  result:any;
  grouptest:any;
}
class Invoice{
  customerName: any;
  address: any;
  contactNo: any;
  email: any;
  DoctorName:any;
  Age:any;
  Gender:any;
  products: Product[] = [];
  additionalDetails: any;
 }

 
@Component({
  selector: 'app-editpatientreport',
  templateUrl: './editpatientreport.component.html',
  styleUrls: ['./editpatientreport.component.scss']
})
export class EditpatientreportComponent implements OnInit {
  invoice = new Invoice(); 
  showFiller = false;
  testdetails:any = [];
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  InvoiceForm = this.fb.group({
  InvoiceNumber: ['', Validators.required],
  })
  checkdata: any;
  testGroup:any=[];
  edittestGroup:any=[];
  unittestdata:any=[];
  idvtest:any=[];
  subtestdata:any=[];
  slideOpen =true;
  checkdata11 = false;
  checktest = false;
  viewtest = true;
  getsample:any;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    const invoiceNumber=window.location.href.split('=')[1];
    console.log(invoiceNumber);
    if(invoiceNumber!=null){
      this.InvoiceForm.get("InvoiceNumber")?.setValue(invoiceNumber);
      // this.Reportdetails()
      this.getdataoftest()
      } 
  }

  getsampletype(data:any){
this.getsample = data
console.log(this.getsample)
  }
       
      savepdf(){

        if(this.getsample == null){
          alert('Please select sample Type')
        }
        else if(this.getsample != null)
        {
          this._spinner.show();
        console.log(this.testGroup);
        let testdetailsList: TestDetails[]=[];
        this.edittestGroup.forEach((p:any)=>{
          p.forEach((senddata:any)=>{
            let testdetails = new TestDetails()
            testdetails.testdiscription=senddata.testdiscription
            testdetails.subtest=senddata.name;
            testdetails.result=senddata.result;
            testdetails.range = senddata.range;
            testdetails.sampletype = this.getsample;
            testdetails.units = senddata.units;
            testdetails.testcode=senddata.testcode;
            testdetails.editeddate = new Date().toLocaleString();
            testdetails.reportstatus="Pending"
            testdetails.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value?.toString();
            testdetailsList.push(testdetails)
          })
          console.log(p)
          
         })
         console.log(testdetailsList)
        this.service.testeredited(testdetailsList).subscribe((res: any) => {
        console.log(res.data)
        this._spinner.hide();
        window.location.reload();
        })
      }
       }


       BackButton(){
         this._spinner.show();
        this.router.navigateByUrl('user/tester-emp')
this._spinner.hide();
       }
      
       gettestvalue(data:any){
        //  this._spinner.show();
console.log(data);
      var inv=new BillPDF();
      inv.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value;
      console.log(inv);
       this.edittestGroup=[];
      this.testdetails.forEach((element:any) => {
        if(element.testName==data){
this.edittestGroup.push(element.subTestGroup1);
        }
      });
      if(this.edittestGroup != []){
        this.viewtest = false;
      }
console.log(this.edittestGroup)
       }

       getdataoftest(){
        this.viewtest=true;
        var inv=new BillPDF1();
        inv.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value;
        this.service.Edittesterreport1(inv).subscribe((res: any) => {
          this._spinner.hide();
        this.testdetails = res.data;
        console.log(this.testdetails)
        if(this.testdetails[0] == null)
        {
          this.router.navigateByUrl('user/tester-emp')
        }
         this.testGroup=[];
        this.testdetails.forEach((element:any)=>{
         
          if(element.subTestGroup == null)
          {
            this.testGroup.push(element.subTestGroup1)
          }        
          else if(element.subTestGroup1 == null)
          {
            this.testGroup.push(element.subTestGroup)
          }
        
         
        });
        
  console.log(this.subtestdata)
  
  })
       }
}
