import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetPatientBillRecordsComponent } from './get-patient-bill-records.component';

describe('GetPatientBillRecordsComponent', () => {
  let component: GetPatientBillRecordsComponent;
  let fixture: ComponentFixture<GetPatientBillRecordsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetPatientBillRecordsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetPatientBillRecordsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
