import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { billrecords, getreport, newBillstatus, ReportDetails, TokenNumber } from 'src/model/userbody';
class Product{
  name: any;
  price: any;
  testcode:any;
  
}
class Invoice{

  
  products: Product[] = [];
  additionalDetails: any;
 }
@Component({
  selector: 'app-get-patient-bill-records',
  templateUrl: './get-patient-bill-records.component.html',
  styleUrls: ['./get-patient-bill-records.component.scss']
})
export class GetPatientBillRecordsComponent implements OnInit {
  displayedColumns: any[] = ['SNo','PatientName','Phonenumber','Dateandtime','Age','Gender','result'];
  private paginator:any= MatPaginator;
  private sort:any= MatSort;

  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.setDataSourceAttributes();
  }

  setDataSourceAttributes() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  dataSource = new MatTableDataSource<any>([]);
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  FindtestForm = this.fb.group({
    InvoiceNumber:['',Validators.required]
  })
  EmailForm = this.fb.group({
    userEmail: ['', Validators.required],
  })
  docDefinition:any;
selectedtest:any;

dataLocalUrl: any;
selectedFeatures: any = [];
filename = 'Angular 5';
fileUrl:any;
image:any;
pdfbill:any;
source:any;
pdfHref:any;
reader:any;
pdfSrc:any;
pdfSrc1 :any;
pageVariable = 1;
verifyreport:any=[];
verifyreport1:any=[];
testreportdata:any=[];
testreportdata1:any=[];
invoice = new Invoice(); 
  checkdata: any;
  constructor(private sanitizer: DomSanitizer,private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.checkdata=res.data
       console.log(this.checkdata)
       if(this.checkdata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
   }

  ngOnInit(): void {
    // const Phonenumber=window.location.href.split('=')[1];
    // console.log(Phonenumber);
    // if(Phonenumber!=null){
    //   this.EmailForm.get("Phonenumber")?.setValue(Phonenumber);
      this.getList();
    }
    getList() {
      this._spinner.show();
      console.log("in loop of list")
      const PatientEmail = new ReportDetails();
      PatientEmail.userEmail = this.userdetails.email;
      this.service.PatientBillData(PatientEmail).subscribe((res: any) => {
  this._spinner.hide();
         this.verifyreport = res.data;
          this.verifyreport.forEach((element:any)=>{
            if(this.testreportdata==''){
              this.testreportdata.push(element)
              this.dataSource.data=this.testreportdata;
            }
            else{
              let checkdata=false;
              this.testreportdata.forEach((testdata:any)=>{
                if(testdata.invoiceNumber==element.invoiceNumber){
                  checkdata=true;
                }
              })
            if(checkdata==false){
              this.testreportdata.push(element)
              this.dataSource.data=this.testreportdata;
            }
            }
          })
       
      })
  }
  GetReportList(){
    this._spinner.show();
    const reportdata = new getreport();
    reportdata.InvoiceNumber=this.FindtestForm.get("InvoiceNumber")?.value;
    this.service.getreportdata(this.FindtestForm.get("InvoiceNumber")?.value).subscribe((res:any) => {
    console.log(res.data)
    this._spinner.hide();
    this.verifyreport1 = res.data;
          this.verifyreport1.forEach((element:any)=>{
            if(this.testreportdata1==''){
              this.testreportdata1.push(element)
              this.dataSource.data=this.testreportdata1;
            }
            else{
              let checkdata=false;
              this.testreportdata1.forEach((testdata:any)=>{
                if(testdata.invoiceNumber==element.invoiceNumber){
                  checkdata=true;
                }
              })
            if(checkdata==false){
              this.testreportdata1.push(element)
              
            }
            }
          })
          this.dataSource.data=this.testreportdata1;
    })
  }
  clickhome(){
    this._spinner.show();
    console.log("hi")
    this.router.navigateByUrl('user/dash-board');
    this._spinner.hide();
  }
    // this.getbillrecords();
  }

