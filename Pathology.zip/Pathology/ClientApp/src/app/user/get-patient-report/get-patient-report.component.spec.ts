import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetPatientReportComponent } from './get-patient-report.component';

describe('GetPatientReportComponent', () => {
  let component: GetPatientReportComponent;
  let fixture: ComponentFixture<GetPatientReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetPatientReportComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetPatientReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
