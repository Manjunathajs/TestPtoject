import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { AppserviceService } from 'src/app/appservice.service';
import { getreport, ReportDetails, TokenNumber } from 'src/model/userbody';
(<any>pdfMake).vfs = pdfFonts.pdfMake.vfs;
class Product{
  name: any;
  price: any;
  testcode:any;
  
}
class Invoice{

  
  products: Product[] = [];
  additionalDetails: any;
 }

 
@Component({
  selector: 'app-get-patient-report',
  templateUrl: './get-patient-report.component.html',
  styleUrls: ['./get-patient-report.component.scss']
})
export class GetPatientReportComponent implements OnInit {
  displayedColumns: any[] = ['PatientName','Phonenumber','Dateandtime','Age','Gender','result','ReportStatus'];
  private paginator:any= MatPaginator;
  private sort:any= MatSort;

  @ViewChild(MatSort) set matSort(ms: MatSort) {
    this.sort = ms;
    this.setDataSourceAttributes();
  }

  @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
    this.paginator = mp;
    this.setDataSourceAttributes();
  }

  setDataSourceAttributes() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  dataSource = new MatTableDataSource<any>([]);
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  FindtestForm = this.fb.group({
    InvoiceNumber:['',Validators.required]
  })
  EmailForm = this.fb.group({
    userEmail: ['', Validators.required],
  })
  // private paginator!: MatPaginator;
  // private sort!: MatSort;

  // @ViewChild(MatSort) set matSort(ms: MatSort) {
  //   this.sort = ms;
  //   this.setDataSourceAttributes();
  // }

  // @ViewChild(MatPaginator) set matPaginator(mp: MatPaginator) {
  //   this.paginator = mp;
  //   this.setDataSourceAttributes();
  // }

  // setDataSourceAttributes() {
  //   this.dataSource.paginator = this.paginator;
  //   this.dataSource.sort = this.sort;
  // }

  

  docDefinition:any;
selectedtest:any;

dataLocalUrl: any;
selectedFeatures: any = [];
filename = 'Angular 5';
fileUrl:any;
image:any;
pdfbill:any;
source:any;
pdfHref:any;
reader:any;
pdfSrc:any;
pdfSrc1 :any;
pageVariable = 1;
verifyreport:any=[];
verifyreport1:any=[];
testreportdata:any=[];
testreportdata1:any=[];
invoice = new Invoice(); 
  checkdata: any;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private spinner: NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.checkdata=res.data
       console.log(this.checkdata)
       if(this.checkdata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
   }

  ngOnInit(): void {
      this.getList();
      // this.dataSource.paginator = this.paginator;
      // this.dataSource.sort = this.sort;
    
  }
  getList() {
    console.log("in loop of list")
    const PatientEmail = new ReportDetails();
    PatientEmail.userEmail = this.userdetails.email;
    this.service.AllPatientReportData(PatientEmail).subscribe((res: any) => {

       this.verifyreport = res.data;
        this.verifyreport.forEach((element:any)=>{
          if(this.testreportdata==''){
            this.testreportdata.push(element)
            this.dataSource.data=this.testreportdata;
          }
          else{
            let checkdata=false;
            this.testreportdata.forEach((testdata:any)=>{
              if(testdata.invoiceNumber==element.invoiceNumber){
                checkdata=true;
                console.log(element);//partually completed
                console.log(testdata);//Approved
                if(testdata.reportstatus=="In-Process" || testdata.reportstatus=="Pending" )
                {
                  console.log(testdata);
                  this.testreportdata.pop(testdata);
                  console.log(testdata);
                  if(element.reportstatus=="Approved")
                  {
                    element.reportstatus="Partially Completed";
                  }
                  checkdata=false;
                }
              }
            })
          if(checkdata==false)
          {
            this.testreportdata.push(element)
            this.dataSource.data=this.testreportdata;
          }
          }
        })
     
    })
}
GetReportList(){
  const reportdata = new getreport();
  reportdata.InvoiceNumber=this.FindtestForm.get("InvoiceNumber")?.value;
  this.service.getreportdata(this.FindtestForm.get("InvoiceNumber")?.value).subscribe((res:any) => {
  console.log(res.data)
  this.verifyreport1 = res.data;
        this.verifyreport1.forEach((element:any)=>{
          if(this.testreportdata1==''){
            this.testreportdata1.push(element)
            this.dataSource.data=this.testreportdata1;
          }
          else{
            let checkdata=false;
            this.testreportdata1.forEach((testdata:any)=>{
              if(testdata.invoiceNumber==element.invoiceNumber){
                checkdata=true;
              }
            })
          if(checkdata==false){
            this.testreportdata1.push(element)
            this.dataSource.data=this.testreportdata1;
          }
          }
        })
        
  })
}
clickhome(){
  console.log("hi")
  this.router.navigateByUrl('user/dash-board');
}
}
