import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetpatientreportpdfComponent } from './getpatientreportpdf.component';

describe('GetpatientreportpdfComponent', () => {
  let component: GetpatientreportpdfComponent;
  let fixture: ComponentFixture<GetpatientreportpdfComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetpatientreportpdfComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetpatientreportpdfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
