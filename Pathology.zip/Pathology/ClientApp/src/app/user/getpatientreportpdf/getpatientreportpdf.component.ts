import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import * as pdfMake from "pdfmake/build/pdfmake";
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { MatTableDataSource } from '@angular/material/table';
import { getreport, TokenNumber, userNumber } from 'src/model/userbody';
import { reduce } from 'rxjs';
import { DomSanitizer } from '@angular/platform-browser';
(<any>pdfMake).vfs = pdfFonts.pdfMake.vfs;
class Product{
  packagename:any;
  testcode:any;
  name: any;
  price: any;
  unit:any;
  qty: any;
  result:any;
  range:any;
}

class Invoice{
  customerName: any;
  address: any;
  contactNo: any;
  Age:any;
  Gender:any;
  email: any;
  DoctorName:any;
  Labname:any;
  gstNumber:any;
  
  products: Product[] = [];
  additionalDetails: any;
 }
@Component({
  selector: 'app-getpatientreportpdf',
  templateUrl: './getpatientreportpdf.component.html',
  styleUrls: ['./getpatientreportpdf.component.scss']
})
export class GetpatientreportpdfComponent implements OnInit {
  InvoiceForm = this.fb.group({
    InvoiceNumber: ['', Validators.required],
  })
  source: any;
  withouthearderpdf:any;
  filename:any;
  pageVariable: any;
  link:any;
  docuData:any;
  dataSource = new MatTableDataSource<any>([]);
  docDefinition:any;
  invoice = new Invoice(); 
  verifydata:any=[];
  mypdf:any;
  PatientTableData: any;
  reportno: any;
  DateAndtime: any;
  mypdfwithouthead:any;
  download=true;
  hide=false;
  checkdata: any;
  getreporttestdata:any=[];
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  ctx: any;
  reportdata:any=[];
  arraydata:any=[];
  rowData:any=[];
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private spinner: NgxSpinnerService,private sanitizer: DomSanitizer) { }

  ngOnInit(): void {
   
    const invoiceNumber=window.location.href.split('=')[1];
    console.log(invoiceNumber);
    if(invoiceNumber!=null){
      this.InvoiceForm.get("InvoiceNumber")?.setValue(invoiceNumber);
      // this.getBillPDF();
      this.getreportdata();
      } 
  }
  getreportdata(){
    let invoice = new getreport();
    invoice.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value;
    this.service.gettestreportdata(invoice).subscribe((getdata:any)=>{
      console.log(getdata.data);
      this.getBillPDF();
      this.getreporttestdata=getdata.data;
      this.getreporttestdata.forEach((result:any)=>{
      this.verifydata.push(result.subTestGroup1)
      })
      console.log(this.verifydata)
      this.verifydata.forEach((element:any)=>{
        console.log(element)
        element.forEach((data:any)=>{
          console.log(data)
          this.arraydata.push(data); 
        })
        console.log(this.arraydata)
      })
      this.getBillPDF();
       this.arraydata.forEach((p:any)=>{
            let test = new Product;
            test.packagename=p.testdiscription;
            test.name = p.subtest;
            test.qty=p.result;
            test.price=p.range;
            test.unit=p.unit;
            this.invoice.products.push(test)
          })
            })
            console.log(this.invoice.products)
  }
  getBillPDF(){
    console.log(this.userdetails)
    this.service.checkreportpdf(this.InvoiceForm.get("InvoiceNumber")?.value).subscribe((res: any) => {
      console.log(res.data)
      this.docuData=res.data[0];
      this.invoice.customerName=this.docuData.name;
      this.filename=this.docuData.name +"_Report";
      this.invoice.contactNo=this.docuData.phonenumber;
      this.invoice.address=this.docuData.patientregisternumber;
      this.invoice.Labname=this.userdetails.name
      this.invoice.gstNumber=this.userdetails.gstNumber;
      this.invoice.Age=this.docuData.age;
      this.invoice.Gender=this.docuData.gender;
      this.invoice.DoctorName=this.docuData.doctorName;
      this.DateAndtime = this.docuData.date;
     this.reportno=this.docuData.invoiceNumber;
   
     this.createPdfDoc();
  const pdfdata=pdfMake.createPdf(this.docDefinition);
          console.log(pdfdata);
          pdfdata.getBase64((data)=>{
              this.mypdf = data;
            });
            this.createpdfdoc();
            const pdfwithouthead=pdfMake.createPdf(this.withouthearderpdf);
                    console.log(pdfwithouthead);
                    pdfwithouthead.getBase64((pdfdata)=>{
                        this.mypdfwithouthead = pdfdata;
                      });
  })
  }
 
  createPdfDoc(){
    this.docDefinition = {
      pageMargins : [25, 25, 25, 35],

  defaultStyle : {
    fontSize  : 12,
    columnGap : 20
  },
      


  
      // header: {
      //   columns: [
      //     {
      //       width:'*',
            
      //       // text:[
      //       //   {text:`${this.userdetails.name}\n`,fontSize: 20,alignment: 'right',color: '#047886'},
      //       //   {text:`GST No : ${this.userdetails.gstNumber}`,alignment: 'right'}
      //       // ],
      //       // alignment: 'right'
      //       text:
      //         [
      //         { text:'Patient Details\n',style:'sectionHeader',margin: [ 9, 5, 0, 0]},
      //         { text:`Name :  ${this.invoice.customerName}\n`},
      //         { text: `Register No :  ${this.invoice.address}\n` },
      //         { text: `Mobile No :  ${this.invoice.contactNo}\n`},
      //         { text: `Age/Gender : ${this.invoice.Age}/${this.invoice.Gender}\n`}
      //       ],
           
      //     },
      //  {
      //    columns:[
      //     [{text: `${this.userdetails.name}`,fontSize: 20,alignment: 'right',color: '#047886'},{text:`GST No : ${this.userdetails.gstNumber}`,alignment: 'right'}],
      //    ]

      //  }         
      // ],
    
      // }
      

      footer: {
        columns: [
          // 'Left part',
          [{text:`Lab Address : ${this.userdetails.labAddress} | contact no. ${this.userdetails.phoneNumber}`,alignment:'center',color:'#d51212',fillColor:'black'}]
        ]
      },
      content: [
        {
table:{
  headerRows: 2,
  // One column, full width
  widths: ['*'],
  
}
        },
      //   {
      //     columns: [
      //     [{text: `${this.userdetails.name}`,fontSize: 20,alignment: 'right',color: '#047886'},{text:`GST No : ${this.userdetails.gstNumber}`,alignment: 'right'}],
      //   ]
      // },
      //   {
      //     text: 'Pacient Details',
      //     style: 'sectionHeader',
      //   },
      //   {
      //     columns: [
      //       [{text:`Name :  ${this.invoice.customerName}`},{ text: `Register No :  ${this.invoice.address}` },{ text: `Mobile No :  ${this.invoice.contactNo}`},{ text: `Age/Gender : ${this.invoice.Age}/${this.invoice.Gender}`}],
      //       [{text: `Date: ${this.DateAndtime}`,alignment: 'right'},{text: `Invoice No : ${this.reportno}`,alignment: 'right'},{text:`Doc Name : ${this.invoice.DoctorName}`,alignment: 'right'}]
      //     ]
      //   },
        {
          text: 'Pacient Report',
          bold:true,
          fontSize:20,
          color:'#002693',
          style: 'sectionHeader',
          alignment:'center'
        },
        {
          border: [true, true, false, false],
         table: {
          
           widths: ['*', '*', '*', '*'],
           body: [
             [{text:'Test',fontSize: 16,bold: true,color:'black'},{text:'Result',fontSize: 16,bold: true,color:'black'},{text:'Units',fontSize: 16,bold: true,color:'black'},{text:'Range',fontSize: 16,bold: true,color:'black'}],
               ...this.invoice.products.map(p => ([p.name,p.qty,p.unit, p.price])),
           ], 
         },
         layout: {
          hLineWidth: function() {
          // Here you can use ternary operator or if condtions to change its value according to row and column
            return 0;
          },
          vLineWidth: function() {
            // Here you can use ternary operator or if condtions to change its value according to row and column
            return 0;
          }
      }
       },
        // {
        //     text: this.invoice.additionalDetails,
        //     margin: [0, 0 ,0, 0 ,15]          
        // },
        {
          columns: [
           [{ text: 'LAB Signature', alignment: 'left', italics: true,margin: [ 0, 20, 0, 0 ]}],
           [{ text: 'Doctor Signature', alignment: 'right', italics: true,margin: [ 0, 20, 0, 0 ]}],
          ]
        },
        {
          text: 'Terms and Conditions',
          style: 'sectionHeader'
        },
        {
            ul: [
              'These Terms and Conditions shall apply to any Services that' +this.userdetails.name + 'provides to the Client, unless those Services are the subject of aseparate written agreement signed by' + this.userdetails.name + 'and the Client These Terms and Conditions apply to the exclusion of any other termspresented by the Client or implied by custom or course of dealing'
            ],
        },
        // {
        //   columns:[
        //     [{text:`Lab Address : ${this.userdetails.labAddress} | contact no. ${this.userdetails.phoneNumber}`,alignment:'center',color:'#d51212',margin: [ 0, 100, 0, 0 ],fillColor:'black'}]
        //   ]
        // }
      ],
      styles: {
        sectionHeader: {
          bold: true,
          decoration: 'underline',
          fontSize: 14,
          margin: [0, 15,0, 15]          
        }
      }
    };
  }
  
 
  
  createpdfdoc(){
    this.withouthearderpdf ={
      content: [
        {
          text: 'Pacient Details',
          style: 'sectionHeader'
        },
        {
          columns: [
            [
              {text:`Name :  ${this.invoice.customerName}`},
              { text: `Register No :  ${this.invoice.address}` },
              { text: `Mobile No :  ${this.invoice.contactNo}`},
              {text: `Age : ${this.invoice.Age}`},
              { text:`Gender : ${this.invoice.Gender}`}
            ],
            [
              {
                text: `Date : ${this.DateAndtime}`,
                alignment: 'right'
              },
              { 
                text: `Invoice No : ${(this.reportno)}`,
                alignment: 'right'
              },
              {
                text:`Doc Name : ${this.invoice.DoctorName}`,
                alignment: 'right'
              }
            ]
          ]
        },
        {
          text: 'Pacient Report',
          style: 'sectionHeader'
        },
        {
          table: {
            headerRows: 1,
            widths: ['*', '*', '*'],
            body: [
              ['Test','Result','Range'],
              ...this.invoice.products.map(p => ([p.name,p.qty, p.price])),
            ]
          }
        },
        {
            text: this.invoice.additionalDetails,
            margin: [0, 0 ,0, 15]          
        },
        {
          columns: [
            [{ text: 'LAB Signature', alignment: 'left', italics: true}],
            [{ text: 'Signature', alignment: 'right', italics: true}],
            // [{setImage:`${this.image}`,size:'50'}]          
          ]
        },
        {
          text: 'Terms and Conditions',
          style: 'sectionHeader'
        },
        {
            ul: [
              'These Terms and Conditions shall apply to any Services that "LabLife Labs" provides to the Client, unless those Services are the subject of aseparate written agreement signed by "SuperNove Labs" and the Client These Terms and Conditions apply to the exclusion of any other termspresented by the Client or implied by custom or course of dealing'
            ],
        }
      ],
      styles: {
        sectionHeader: {
          bold: true,
          decoration: 'underline',
          fontSize: 14,
          margin: [0, 15,0, 15]          
        }
      }
    }
    }

  Showpdf(){
    this.download=false;
    this.hide=true;
      // console.log(this.mypdf);
   
       const nav = (window.navigator as any);
  if(nav.msSaveOrOpenBlob){ 
    // download PDF in IE
    let byteChar = window.atob(this.mypdf);
    let byteArray = new Array(byteChar.length);
    for(let i = 0; i < byteChar.length; i++){
      byteArray[i] = byteChar.charCodeAt(i);
    }
    let uIntArray = new Uint8Array(byteArray);
    let blob = new Blob([uIntArray], {type : 'application/pdf'});
    nav.msSaveOrOpenBlob(blob, `${this.filename}.pdf`);
  } else {
    this.source = `data:application/pdf;base64,${this.mypdf}`;
    this.link = document.createElement("a");
    this.link.href = this.source;
  //  window.open(this.source);
    // window.open(this.reader);
    // this.link.download = `${this.filename}.pdf`
    this.link.click(); 
  
  }
  // })
  }
  downloadbill(){
    // console.log(this.mypdf);
      
    const nav = (window.navigator as any);
if(nav.msSaveOrOpenBlob){ 
 // download PDF in IE
 let byteChar = window.atob(this.mypdf);
 let byteArray = new Array(byteChar.length);
 for(let i = 0; i < byteChar.length; i++){
   byteArray[i] = byteChar.charCodeAt(i);
 }
 let uIntArray = new Uint8Array(byteArray);
 let blob = new Blob([uIntArray], {type : 'application/pdf'});
 nav.msSaveOrOpenBlob(blob, `${this.filename}.pdf`);
} else {
 this.source = `data:application/pdf;base64,${this.mypdf}`;
 this.link = document.createElement("a");
 this.link.href = this.source;
 this.link.download = `${this.filename+"_report With Header"}.pdf`
 this.link.click(); 

}
  }

  
downloadwithoutheader(){
      
    const nav = (window.navigator as any);
if(nav.msSaveOrOpenBlob){ 
 let byteChar = window.atob(this.mypdfwithouthead);
 let byteArray = new Array(byteChar.length);
 for(let i = 0; i < byteChar.length; i++){
   byteArray[i] = byteChar.charCodeAt(i);
 }
 let uIntArray = new Uint8Array(byteArray);
 let blob = new Blob([uIntArray], {type : 'application/pdf'});
 nav.msSaveOrOpenBlob(blob, `${this.filename+"_report Without Header"}.pdf`);
} else {
 this.source = `data:application/pdf;base64,${this.mypdfwithouthead}`;
 this.link = document.createElement("a");
 this.link.href = this.source;
 this.link.download = `${this.filename+"_Report Without Header"}.pdf`
 this.link.click(); 

}
}

  nextPage() {
    this.pageVariable++;
  }
  
  afterLoadComplete(pdf: any) {
    console.log('after-load-complete');
  }
  
  pageRendered(e: CustomEvent) {
    console.log('(page-rendered)', e);
  }
  
  textLayerRendered(e: CustomEvent) {
    console.log('(text-layer-rendered)', e);
  }
  
  onFileSelected() {
    let $img: any = document.querySelector('#file');
  
    if (typeof (FileReader) !== 'undefined') {
      let reader = new FileReader();
  
      reader.onload = (e: any) => {
        this.source = e.target.result;
      };
  
      reader.readAsArrayBuffer($img.files[0]);
    }
  }
     
}



