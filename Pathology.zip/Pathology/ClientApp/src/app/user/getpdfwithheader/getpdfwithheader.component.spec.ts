import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GetpdfwithheaderComponent } from './getpdfwithheader.component';

describe('GetpdfwithheaderComponent', () => {
  let component: GetpdfwithheaderComponent;
  let fixture: ComponentFixture<GetpdfwithheaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GetpdfwithheaderComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(GetpdfwithheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
