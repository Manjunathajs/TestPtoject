import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { getbillpdf, TokenNumber } from 'src/model/userbody';
import * as pdfMake from "pdfmake/build/pdfmake";
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { left } from '@popperjs/core';
(<any>pdfMake).vfs = pdfFonts.pdfMake.vfs;
class Product{
  packagename:any;
  testcode:any;
  name: any;
  price: any;
  qty: any;
  result:any;
  range:any;
  discount:any;
}

class Invoice{
  customerName: any;
  address: any;
  contactNo: any;
  Age:any;
  Gender:any;
  email: any;
  DoctorName:any;
  LabName:any;
  
  products: Product[] = [];
  additionalDetails: any;
 }
@Component({
  selector: 'app-getpdfwithheader',
  templateUrl: './getpdfwithheader.component.html',
  styleUrls: ['./getpdfwithheader.component.scss']
})
export class GetpdfwithheaderComponent implements OnInit {
  InvoiceForm = this.fb.group({
    InvoiceNumber: ['', Validators.required],
  })
  source: any;
  
  filename:any;
  pageVariable: any;
  link:any;
  docuData:any;
  dataSource = new MatTableDataSource<any>([]);
  docDefinition:any;
  withouthearderpdf:any;
  invoice = new Invoice(); 
  verifydata:any=[];
  mypdf:any;
  mypdfwithouthead:any;
  PatientTableData: any;
  reportno: any;
  DateAndtime: any;
  download=true;
  hide=false;
  dis:any;
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  checkdata: any;
  discountprice:any;
  logoImage: any;
  constructor(private sanitizer: DomSanitizer,private fb:FormBuilder,private router:Router,private service:AppserviceService,private spinner: NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    console.log(this.userdetails);
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.checkdata=res.data
      //  console.log(this.checkdata)
       if(this.checkdata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    // console.log(this.userdetails)
  }

  ngOnInit(): void {
    const invoiceNumber=window.location.href.split('=')[1];
    // console.log(invoiceNumber);
    if(invoiceNumber!=null){
      this.InvoiceForm.get("InvoiceNumber")?.setValue(invoiceNumber);
      // this.getBillData()
      this.logoImage='data:image/jpeg;base64,' +  this.userdetails.datafiles;
      this.getBillPDF()
      }      
  }
  getBillPDF(){
    this.service.checkreportpdf(this.InvoiceForm.get("InvoiceNumber")?.value).subscribe((res: any) => {
      // console.log(res.data)
      let totalcost=0;
      this.verifydata = res.data;
      this.docuData=this.verifydata[0];

      this.verifydata.forEach((element:any)=>{
        let test = new Product;
        test.name = element.testdiscription;
        test.price=element.amount;
        totalcost=totalcost+element.amount;
        test.discount="-";
        this.dis= element.quantity;
        test.result=totalcost-(totalcost/100)*this.dis.toString();
        this.discountprice = test.result;
       this.invoice.products.push(test)

      }); 
      // console.log(this.invoice);
      this.invoice.customerName=this.docuData.name;
      this.filename=this.docuData.name;
      this.invoice.contactNo=this.docuData.phonenumber;
      this.invoice.Age=this.docuData.age;
      this.invoice.address=this.docuData.patientregisternumber;
      this.invoice.Gender=this.docuData.gender;
      this.DateAndtime = this.docuData.date;
      this.invoice.LabName=this.userdetails.name;
      this.invoice.DoctorName=this.docuData.doctorName;
     this.reportno=this.docuData.invoiceNumber;
     this.createPdfDocwithheader();
  const pdfdata=pdfMake.createPdf(this.docDefinition);
          // console.log(pdfdata);
          pdfdata.getBase64((data)=>{
              this.mypdf = data;
            });
    })
 } 

 createPdfDocwithheader(){
  this.docDefinition = {
    header: {
      // margin: [10, 0, 0, 0],
      columns: [
          {
              margin: [50, 0, 0, 0],
              text: this.userdetails.name
          },
        //   {
        //     // usually you would use a dataUri instead of the name for client-side printing
        //     // sampleImage.jpg however works inside playground so you can play with it
        //     image:this.logoImage,
        //     width: 20,
        //     margin: [-50, 0, 0, 0],   
        //     alignment:'left'    
        // }
      ]
  },
    content: [
      {
        text: 'Patient Details',
        style: 'sectionHeader'
      },
      {
        columns: [
          [
            {text:`Name :  ${this.invoice.customerName}`},
            { text: `Register No :  ${this.invoice.address}` },
            { text: `Mobile No :  ${this.invoice.contactNo}`},
            {text: `Age : ${this.invoice.Age}`},
          { text:`Gender : ${this.invoice.Gender}`}
          ],
          [
            {
              text: `Date : ${this.DateAndtime}`,
              margin:[80,0,0,0]
              // alignment: 'right',
            },
            { 
              text: `Bill No : ${(this.reportno)}`,
              // alignment: 'right',
              margin:[80,0,0,0]
            },
          
          ]
        ]
      },
      {
        text: 'Patient Bill',
        decoration: 'underline',
        style: 'sectionHeader'
      },
      {
        table: {
          headerRows: 1,
          widths: ['*', 'auto', 'auto', 'auto'],
          body: [
            ['Test', 'Price', 'Discount', 'Amount'],
            ...this.invoice.products.map(p => ([p.name, p.price, p.discount, (p.price).toFixed(2)])),
            [{text: 'Total Amount', colSpan: 2}, {}, this.dis+"%", this.invoice.products.reduce((sum, p)=> sum + (p.price), 0).toFixed(2)],
            [{text: 'Discount Amount', colSpan: 3},{},{},  this.discountprice]
          ]
        }
      },
      {
          text: this.invoice.additionalDetails,
          margin: [0, 0 ,0, 15]          
      },
      {
        columns: [
          [{ text: 'LAB Signature', alignment: 'left', italics: true,margin:[0,50,0,0]}],
          [{ text: 'Signature', alignment: 'right', italics: true, margin:[0,50,0,0]}],
          // [{setImage:`${this.image}`,size:'50'}]          
        ]
      },
      {
        text: 'Terms and Conditions',
        decoration: 'underline',
        style: 'sectionHeader'
      },
      {
          ul: [
            'These Terms and Conditions shall apply to any Services that "LabLife Labs" provides to the Client, unless those Services are the subject of aseparate written agreement signed by "LabLife Labs" and the Client These Terms and Conditions apply to the exclusion of any other termspresented by the Client or implied by custom or course of dealing'
          ],
      }
    ],
    styles: {
      sectionHeader: {
        bold: true,
        fontSize: 16,
        margin: [0, 15,0, 15]          
      }
    }
  };
}

Showpdf(){
  this.download=false;
  this.hide=true;
    // console.log(this.mypdf);
    
     const nav = (window.navigator as any);
if(nav.msSaveOrOpenBlob){ 
  // download PDF in IE
  let byteChar = window.atob(this.mypdf);
  let byteArray = new Array(byteChar.length);
  for(let i = 0; i < byteChar.length; i++){
    byteArray[i] = byteChar.charCodeAt(i);
  }
  let uIntArray = new Uint8Array(byteArray);
  let blob = new Blob([uIntArray], {type : 'application/pdf'});
  nav.msSaveOrOpenBlob(blob, `${this.filename}.pdf`);
} else {
  this.source = `data:application/pdf;base64,${this.mypdf}`;
  this.link = document.createElement("a");
  this.link.href = this.source;
//  window.open(this.source);
  // window.open(this.reader);
  // this.link.download = `${this.filename}.pdf`
  this.link.click(); 

}
// })
}
nextPage() {
  this.pageVariable++;
}

afterLoadComplete(pdf: any) {
  // console.log('after-load-complete');
}

pageRendered(e: CustomEvent) {
  // console.log('(page-rendered)', e);
}

textLayerRendered(e: CustomEvent) {
  // console.log('(text-layer-rendered)', e);
}

onFileSelected() {
  let $img: any = document.querySelector('#file');

  if (typeof (FileReader) !== 'undefined') {
    let reader = new FileReader();

    reader.onload = (e: any) => {
      this.source = e.target.result;
    };

    reader.readAsArrayBuffer($img.files[0]);
  }
}
downloadbill(){
// this.downloadpdf=true;
console.log(this.mypdf);
      
const nav = (window.navigator as any);
if(nav.msSaveOrOpenBlob){ 
// download PDF in IE
let byteChar = window.atob(this.mypdf);
let byteArray = new Array(byteChar.length);
for(let i = 0; i < byteChar.length; i++){
byteArray[i] = byteChar.charCodeAt(i);
}
let uIntArray = new Uint8Array(byteArray);
let blob = new Blob([uIntArray], {type : 'application/pdf'});
nav.msSaveOrOpenBlob(blob, `${this.filename+"_Bill With Header"}.pdf`);
} else {
this.source = `data:application/pdf;base64,${this.mypdf}`;
this.link = document.createElement("a");
this.link.href = this.source;
//  window.open(this.source);
// window.open(this.reader);
this.link.download = `${this.filename+"_Bill With Header"}.pdf`
this.link.click(); 

}
}

}
