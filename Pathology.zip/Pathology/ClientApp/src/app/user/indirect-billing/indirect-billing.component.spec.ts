import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IndirectBillingComponent } from './indirect-billing.component';

describe('IndirectBillingComponent', () => {
  let component: IndirectBillingComponent;
  let fixture: ComponentFixture<IndirectBillingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IndirectBillingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(IndirectBillingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
