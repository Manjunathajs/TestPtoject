
  import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
  import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
  import { Router } from '@angular/router';
  import { NgxSpinnerService } from 'ngx-spinner';
  import { AppserviceService } from 'src/app/appservice.service';
  import * as pdfMake from "pdfmake/build/pdfmake";
  import * as pdfFonts from 'pdfmake/build/vfs_fonts';
  import { BillReport, EmailId, TestDetails, TokenNumber, userNumber } from 'src/model/userbody';
  import {formatDate} from '@angular/common';
  import { DomSanitizer } from '@angular/platform-browser';
  import { DateAdapter } from '@angular/material/core';
  import { TestBed } from '@angular/core/testing';
  import { MatTableDataSource } from '@angular/material/table';
  import { MatChipInputEvent } from '@angular/material/chips';
  import { map, Observable, ReplaySubject, startWith } from 'rxjs';
  
  (<any>pdfMake).vfs = pdfFonts.pdfMake.vfs;
  class Product{
    packagename:any;
    testcode:any;
    name: any;
    subtest:any;
    price: any;
    qty: any;
    result:any;
    range:any;
    discount:any='-';
  }
  
  class Invoice{
    customerName: any;
    address: any;
    contactNo: any;
    Age:any;
    Gender:any;
    email: any;
    DoctorName:any;
    LabName:any;
    products: Product[] = [];
    additionalDetails: any;
   }
  
  @Component({
    selector: 'app-indirect-billing',
    templateUrl: './indirect-billing.component.html',
    styleUrls: ['./indirect-billing.component.scss']
  })
  export class IndirectBillingComponent implements OnInit {
    @ViewChild('search') searchTextBox: ElementRef | any ;
    AddDataForm = this.fb.group({
      Email:new FormControl('',[Validators.email,Validators.required,Validators.min(4) ]),
      Phonenumber:new FormControl('',[Validators.required,Validators.min(4) ]),
      DataFiles:new FormControl(''),
    })
    DiscountForm = this.fb.group({
      discount:new FormControl('',[ ]),
      totalPrice:new FormControl('',[]),
    })
    //  item="primary";
    loggedInuser:any=localStorage.getItem('LoggedInUser');
    userdetails:any=JSON.parse(this.loggedInuser);
    displayedColumns: any[] = ['testdiscription','Amount'];
    selectFormControl = new FormControl();
    Packagesbilling =new FormControl('');
    doctordisplayColumns:any[] =['DoctorName','DataFiles']
    DoctorSignature = new FormControl('');
    dataSource:any = [];
    dropDownData:any=[];
    dropDownData1:any=[];
    filterdata:any=[];
    dropDownData2:any;
    PackageData:any=[];
    testdata:any=[];
    invoice = new Invoice(); 
    selectedtest:any=[];
    selectedpackage:any=[];
    selectdoctorname:any;
    show=true;
    mypdf1:any;
    docDefinition:any;
    withouthearderpdf:any;
    mypdf:any;
    notclicked=true;
    isDisplay = true;
    hideme = false;
    Addtest = true;
    hideAll = true;
    AddDoctor=true;
    uniqueItems!:any;
    checkdata:Boolean=false;
    checkpackage:Boolean=false;
    PaymentorderId:any;
    Billdate:any;
    docsource:any;
    PatientTableData:any;
    DoctorName:any;
    DoctorDetails:any;
    image:any;
    selecttestlist:any=[];
    addOnBlur = true;
    selectpackage:any=[];
    fruits:any=[];
    groups:any=[];
    dropdowntest: any;
    dropdowntest1: any;
    toekndata: any;
    dis: any;
    reportData:any;
    verifydata: any=[];
    docuData: any;
    discountprice: any;
    filename: any;
    DateAndtime: any;
    reportno: any;
    applyFilter(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
      let tempdropdown: any[]=[];
      if(this.dropDownData!="undefined")
      {
      this.dropdowntest.forEach((element:any) => {
  
        if(element.testdiscription.toLowerCase().includes(filterValue.trim().toLowerCase())){
  
          tempdropdown.push(element)
        }
      });
    }
      this.dropDownData="";
      this.dropDownData=tempdropdown;
      console.log(this.dropDownData)
    // }
    
    }
    applyFilter1(event: Event) {
      const filterValue = (event.target as HTMLInputElement).value;
      let tempdropdown1: any[]=[];
      if(this.dropDownData1!="undefined")
      {
      this.dropdowntest1.forEach((data:any) => {
  
        if(data.packageName.toLowerCase().includes(filterValue.trim().toLowerCase())){
  
          tempdropdown1.push(data)
        }
      });
    }
      this.dropDownData1="";
      this.dropDownData1=tempdropdown1;
      console.log(this.dropDownData)
    // }
    
    }
    constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private spinner: NgxSpinnerService,private sanitizer: DomSanitizer) {
      let tokennumber = new TokenNumber();
      tokennumber.Email =this.userdetails.tokenNumber;
      this.service.checktimeout(tokennumber).subscribe((res:any)=>{
        this.toekndata=res.data
         console.log(this.toekndata)
         if(this.toekndata==false){
          alert('session as ended login again')
          this.router.navigateByUrl('login');
         }
        })
      console.log(this.userdetails)
    }
    ngOnInit(): void {
      this.getbill();
      this.getpackage();
      this.getdocdetails();
      this.notclicked=true;
      this.show=true;
      this.invoice=new Invoice(); 
      console.log(this.invoice.products)
      const Phonenumber=window.location.href.split('=')[1];
      console.log(Phonenumber);
      if(Phonenumber!=null){
        this.AddDataForm.get("Phonenumber")?.setValue(Phonenumber);
        this.getpatientlist();
      }
   }
  
  getbill(){
   this.service.GetDropDownList().subscribe((res:any)=>{
      console.log("hello",res);
      if(res.status=='success'){
        this.testdata=res.data;
        this.testdata.forEach((gettest:any)=>{
          if(this.dropDownData==''){
            this.dropDownData.push(gettest)
            this.dropdowntest=this.dropDownData;
          }
          else{
            let checktest = false;
            this.dropDownData.forEach((verifytest:any)=>{
              if(verifytest.testdiscription==gettest.testdiscription){
                checktest=true;
              }
            });
            if(checktest==false){
              this.dropDownData.push(gettest);
              this.dropdowntest=this.dropDownData;
            }
          }
        })
        console.log(this.dropDownData);
     }
      else{ }
    })
  }
  
  getpackage(){
    this.service.GetDropDownPackageList().subscribe((res:any)=>{
      console.log("hello",res);
      if(res.status=='success'){
         this.PackageData=res.data;
         this.PackageData.forEach((Element:any)=>{
           if(this.dropDownData1==''){
            console.log(Element)
             this.dropDownData1.push(Element);
             this.dropdowntest1=this.dropDownData1;
           }
           else{
             let checkelement=false;
            this.dropDownData1.forEach((data:any) => {
        if(data.packageName==Element.packageName){
             checkelement=true;
    }
  });
        if(checkelement==false){
          this.dropDownData1.push(Element);
          this.dropdowntest1=this.dropDownData1;
        }
         }
         })
           }
          })
        }
  
  getdocdetails(){
    this.service.GetDropDownDoctorList().subscribe((res:any)=>{
      console.log("hello",res);
      if(res.status=='success'){
         this.dropDownData2=res.data;
         this.DoctorDetails = res.data[0];
         console.log(this.DoctorDetails);
     }
    })
  }
  
  getpatientlist(){
    const number = new userNumber();
    number.Phonenumber = this.AddDataForm.get("Phonenumber")?.value;
    this.service.getPatientListData(number).subscribe((res: any) => {
      this.PatientTableData=res.data[0];
      if(this.PatientTableData == null){
        alert('This Patient Has Not Registered')
      }
      else{
  this.hideAll=false;
      this.invoice.customerName = this.PatientTableData.name;
      this.invoice.address=this.PatientTableData.patientregisternumber;
      this.invoice.email=this.PatientTableData.patientEmail;
      this.invoice.contactNo =this.PatientTableData.phonenumber;
      this.invoice.Age=this.PatientTableData.age;
      this.invoice.Gender=this.PatientTableData.gender;
      this.getdetails();
      }
     })
  }
  
  getdetails(){
    const number = new userNumber();
    number.Phonenumber = this.AddDataForm.get("Phonenumber")?.value;
    this.service.getPatientListData(number).subscribe((res: any) => {
      this.dataSource = res.data;
         console.log(this.dataSource)
  
    })
  }
  
  calculateTotalPrice(){
    let totalcost=0;
  this.invoice.products.forEach((elements:any)=>{
  totalcost=totalcost+elements.price;
  console.log(elements);
  })
  console.log(totalcost);
  this.dis= Number(this.DiscountForm.get("discount")?.value);
  let price=totalcost-(totalcost/100)*this.dis;
  this.DiscountForm.get("totalPrice")?.setValue(price.toString());
   
  }
  
  generatePDF(action = 'open'){
     if(action==='download'){
     pdfMake.createPdf(this.docDefinition).download();
    }else if(action === 'print'){
      pdfMake.createPdf(this.docDefinition).print();   
     }
    else{
      pdfMake.createPdf(this.docDefinition).open();
    }
  }
  
  clickhome(){
    console.log("hi")
    this.router.navigateByUrl('user/dash-board');
  }
  
  getDrowdowndata(data:any){ 
    this.selectedtest = data;
    console.log(this.selectedtest)
  this.fruits=this.selectedtest;
  }
  
  onDiscount(){
   this.calculateTotalPrice();
  
  }
  
  getDrowdowndata1(data:any){
    this.fruits.forEach((deleteitem:any)=>{
  this.fruits.splice(deleteitem)
    });
    this.selectpackage = data;
    console.log(this.selectpackage)
    this.selectpackage.forEach((select:any)=>{  
      this.PackageData.forEach((element:any) => {
        if(element.packageName==select.packageName){
          let checkpackage1=false;
          this.selectedpackage.forEach((selectlist:any)=>{
            if(selectlist.testcode==element.testcode){
            checkpackage1=true;
            }
          });
          if(checkpackage1==false){
            this.selectedpackage.push(element)
          }
        }
      })
    })
  
    this.fruits=this.selectedpackage;
    }
    getDrowdowndata2(data:any){
   this.selectdoctorname =data;
    }
  
  sendsubmit(){
    console.log(this.selectedtest);
    console.log(this.invoice.products);
  this.selectedtest.forEach((listtest:any)=>{
    this.checkdata=false;
    this.invoice.products.forEach((data:any)=>
    {
  if(data.testcode==listtest.testcode){
  this.checkdata=true;
  alert('The Test Has Been Already Added')
  }
  });
  console.log(this.checkdata)
  if(this.checkdata==false)
  {
    let test=new Product;
    test.name=listtest.testdiscription;
    test.subtest = listtest.subtest;
    test.result = listtest.result;
    test.range =listtest.range;
    test.price=listtest.amount;
    test.testcode=listtest.testcode;
    test.qty=1;
    this.Addtest = false;
  this.invoice.products.push(test)
  }
  })
  this.calculateTotalPrice();
  }
  
  sendsubmitpackage(){
    console.log(this.selectedpackage);
    console.log(this.invoice.products);
  console.log(this.PackageData);
  // this.checkdata=false;
  this.selectedpackage.forEach((select:any)=>{
    this.PackageData.forEach((element:any) => {
      if(element.packageName==select.packageName){
        this.checkpackage=false;
        this.invoice.products.forEach((data:any)=>
        {
        if(data.testcode==element.testcode){
          data.price=element.amount;
        this.checkpackage=true;
        }
        });
        if( this.checkpackage==false)
        {
        let test=new Product;
            test.name=element.testdiscription;
            test.price=element.amount;
            test.testcode=element.testcode;
            test.range=element.range;
            test.qty=1;
            this.Addtest = false;
          this.invoice.products.push(test) 
        }
    }
    });
  })
  
  }
  
  ondelete(deleteme: number) {
   this.invoice.products.splice(deleteme,1);
      }
  
  savepdf(){
    let testdetailsList: TestDetails[]=[];
    console.log(this.invoice.products)
    this.invoice.products.forEach((p:any)=>{
      console.log(p);
      let testdetails = new TestDetails();
      testdetails.testdiscription = p.name;
      testdetails.result=p.result;
      testdetails.subtest=p.subtest;
      testdetails.range=p.range;
      testdetails.amount=p.price;
      testdetails.quantity= Number(this.DiscountForm.get("discount")?.value);
      testdetails.userEmail =this.userdetails.email;
      let phno=this.AddDataForm.get("Phonenumber")?.value;
      testdetails.Phonenumber =phno?.toString();
      testdetails.doctorName=this.PatientTableData.doctorName;
      testdetails.Patientregisternumber=this.PatientTableData.patientregisternumber;
      testdetails.Name=this.PatientTableData.name;
      testdetails.reportstatus="In-Process";
      testdetails.Age=this.PatientTableData.age.toString();
      testdetails.gender=this.PatientTableData.gender;
      testdetails.totalamount = this.DiscountForm.get("totalPrice")?.value;
      testdetailsList.push(testdetails);
     })
     console.log(testdetailsList)
     this.service.AddtestDetails(testdetailsList).subscribe((res:any)=>{
      if(res.status=='Success'){
        this.reportData=res.data;
        this.getBillPDF();
        this.hideme = !this.hideme;
        this.isDisplay = !this.isDisplay;
        this.show=false;
        this.notclicked=false;
        this.spinner.hide();
    alert(res.message) 
      }
     })
  }
  
  
  Checkbillinfo(){
    this.router.navigateByUrl('user/get-patient-bill-records');
  }
  
  getBillPDF(){
      let totalcost=0;
      this.verifydata = this.reportData;
      this.docuData=this.verifydata[0];
  this.invoice = new Invoice(); 
      this.verifydata.forEach((element:any)=>{
        let test = new Product;
        test.name = element.testdiscription;
        test.price=element.amount;
        totalcost=totalcost+element.amount;
        test.discount="-";
        this.dis= element.quantity;
        test.result=totalcost-(totalcost/100)*this.dis.toString();
        this.discountprice = test.result;
       this.invoice.products.push(test)
  
      }); 
      console.log(this.invoice);
      this.invoice.customerName=this.docuData.name;
      this.filename=this.docuData.name;
      this.invoice.contactNo=this.docuData.phonenumber;
      this.invoice.Age=this.docuData.age;
      this.invoice.address=this.docuData.patientregisternumber;
      this.invoice.Gender=this.docuData.gender;
      this.DateAndtime = this.docuData.date;
      this.invoice.LabName=this.userdetails.name;
      this.invoice.DoctorName=this.docuData.doctorName;
     this.reportno=this.docuData.invoiceNumber;
     this.createPdfDocwithheader();
  const pdfdata=pdfMake.createPdf(this.docDefinition);
          // console.log(pdfdata);
          pdfdata.getBase64((data)=>{
              this.mypdf = data;
            });
  } 
  
  createPdfDocwithheader(){
    this.docDefinition = {
      header: {
        // margin: [10, 0, 0, 0],
        columns: [
            {
                margin: [50, 0, 0, 0],
                text: this.userdetails.name
            },
          //   {
          //     // usually you would use a dataUri instead of the name for client-side printing
          //     // sampleImage.jpg however works inside playground so you can play with it
          //     image:'data:image/png;base64,' +  this.userdetails.datafiles,
          //     width:120,
          //     margin: [-50, 0, 0, 0],   
          //     alignment:'left'
          // }
        ]
    },
      content: [
        {
          text: 'Patient Details',
          style: 'sectionHeader'
        },
        {
          columns: [
            [
              {text:`Name :  ${this.invoice.customerName}`},
              { text: `Register No :  ${this.invoice.address}` },
              { text: `Mobile No :  ${this.invoice.contactNo}`},
              {text: `Age : ${this.invoice.Age}`},
            { text:`Gender : ${this.invoice.Gender}`}
            ],
            [
              {
                text: `Date : ${this.DateAndtime}`,
                margin:[80,0,0,0]
                // alignment: 'right',
              },
              { 
                text: `Bill No : ${(this.reportno)}`,
                // alignment: 'right',
                margin:[80,0,0,0]
              },
            
            ]
          ]
        },
        {
          text: 'Patient Bill',
          decoration: 'underline',
          style: 'sectionHeader'
        },
        {
          table: {
            headerRows: 1,
            widths: ['*', 'auto', 'auto', 'auto'],
            body: [
              ['Test', 'Price', 'Discount', 'Amount'],
              ...this.invoice.products.map(p => ([p.name, p.price, p.discount, (p.price).toFixed(2)])),
              [{text: 'Total Amount', colSpan: 2}, {}, this.dis+"%", this.invoice.products.reduce((sum, p)=> sum + (p.price), 0).toFixed(2)],
              [{text: 'Discount Amount', colSpan: 3},{},{},  this.discountprice]
            ]
          }
        },
        {
            text: this.invoice.additionalDetails,
            margin: [0, 0 ,0, 15]          
        },
        {
          columns: [
            [{ text: 'LAB Signature', alignment: 'left', italics: true,margin:[0,50,0,0]}],
            [{ text: 'Signature', alignment: 'right', italics: true, margin:[0,50,0,0]}],
            // [{setImage:`${this.image}`,size:'50'}]          
          ]
        },
        {
          text: 'Terms and Conditions',
          decoration: 'underline',
          style: 'sectionHeader'
        },
        {
            ul: [
              'These Terms and Conditions shall apply to any Services that "LabLife Labs" provides to the Client, unless those Services are the subject of aseparate written agreement signed by "LabLife Labs" and the Client These Terms and Conditions apply to the exclusion of any other termspresented by the Client or implied by custom or course of dealing'
            ],
        }
      ],
      styles: {
        sectionHeader: {
          bold: true,
          fontSize: 16,
          margin: [0, 15,0, 15]          
        }
      }
    };
  }
  
  
  }