import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { EmailId, parientreport, ReportDetails, TokenNumber, userNumber } from 'src/model/userbody';
import * as pdfMake from "pdfmake/build/pdfmake";
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { concat, concatWith } from 'rxjs';
import { MatTableDataSource } from '@angular/material/table';
(<any>pdfMake).vfs = pdfFonts.pdfMake.vfs;

class Product{
  name: any;
  price: any;
  testcode:any;
  packagename:any;
  qty:any;
  result:any;
}
class Invoice{
  customerName: any;
  address: any;
  contactNo: any;
  email: any;
  DoctorName:any;
  Age:any;
  Gender:any;
  
  products: Product[] = [];
  additionalDetails: any;
 }
 


@Component({
  selector: 'app-pacient-report',
  templateUrl: './pacient-report.component.html',
  styleUrls: ['./pacient-report.component.scss']
})
export class PacientReportComponent implements OnInit {
  Emailregex: RegExp =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  AddDataForm = this.fb.group({
    Email:new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
    Phonenumber:new FormControl('',[Validators.required,Validators.min(10)]),
    Age:new FormControl(''),
    // Phonenumber:new FormControl(''),
    gender:new FormControl('')
  
  })
  // displayedColumns1: any[] = ['Email','PatientEmail','testdiscription','range','result'];
  Report = new FormControl('');
  ReportPackages =new FormControl('');
  dataSource = new MatTableDataSource<any>([]);
  doctordisplayColumns:any[] =['DoctorName','DataFiles']
  DoctorSignature = new FormControl('');
  dropDownData:any;
  dropDownData1:any=[];
  invoice = new Invoice(); 
  selectedtest:any;
  selectedpackage:any;
  PackageData:any;
  docDefinition:any;
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  checkdata:Boolean=false;
  checkpackage:Boolean=false;
  sendingdata:any;
  PaymentorderId:any;
  mypdf:any;
  PatientTableData:any;
  dropDownData2:any;
  selectdoctorname:any;
  DateAndtime:any;
  reportno:any;
  DoctorDetails:any;
  isDisplay = true;
  hideme = false;
  AddDoctor=true;
  hideAll=true;
  toekndata:any;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private spinner: NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.toekndata=res.data
       console.log(this.toekndata)
       if(this.toekndata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
   }

  ngOnInit(): void {
    this.invoice=new Invoice();
    this.getTest();
    this.getPackage();
    this.getdocdetails();
    const Phonenumber=window.location.href.split('=')[1];
    console.log(Phonenumber);
    if(Phonenumber!=null){
      this.AddDataForm.get("Phonenumber")?.setValue(Phonenumber);
    }
    
  }

  getpatientlist(){
    const email = new userNumber();
  email.Phonenumber = this.AddDataForm.get("Phonenumber")?.value;
  this.service.getPatientListData(email).subscribe((res: any) => {
    this.dataSource.data = res.data;
    this.PatientTableData=res.data[0];
    if(this.PatientTableData == null){
      alert('This Email Has Not Registered')
    }
    else{
this.hideAll=false;
    // console.log(this.PatientTableData);
    this.invoice.customerName = this.PatientTableData.name;
    this.invoice.address=this.PatientTableData.patientregisternumber;
    this.invoice.email=this.PatientTableData.patientEmail;
    this.invoice.contactNo =this.PatientTableData.phonenumber;
    this.invoice.DoctorName=this.PatientTableData.doctorName;
    this.invoice.Age=this.PatientTableData.age;
    this.invoice.Gender=this.PatientTableData.gender;
    }
   })
  }

  generatePDF(action = 'open'){
    console.log(this.invoice.products)
    this.createPdfDoc();
    if(action==='download'){
    pdfMake.createPdf(this.docDefinition).download();
   }else if(action === 'print'){
     pdfMake.createPdf(this.docDefinition).print();   
    }
   else{
     pdfMake.createPdf(this.docDefinition).open();
   }
 }
 
 createPdfDoc(){
   this.docDefinition = {
     content: [
       {
         text: 'Super-Nova Labs',
         fontSize: 16,
         decoration: 'underline',
         alignment: 'center',
         color: '#047886'
       },
       {
         text: 'Offical Report',
         fontSize: 15,
         bold: true,
         alignment: 'center',
         color: 'skyblue'
       },
       {
         text: 'Pacient Details',
         style: 'sectionHeader'
       },
       {
         columns: [
           [
            {text:`Name :  ${this.invoice.customerName}`},
            { text: `Register No :  ${this.invoice.address}` },
            { text: `EmailAddress :  ${this.invoice.email}` },
            { text: `Mobile No :  ${this.invoice.contactNo}`},
            { text: `Age : ${this.invoice.Age}`},
            { text:`Gender : ${this.invoice.Gender}`}
           ],
           [
            {
              text: `Date: ${this.DateAndtime}`,
              alignment: 'right'
            },
             { 
               text: `Report No : ${this.reportno}`,
               alignment: 'right'
             },
             {
              text:`Doc Name : ${this.invoice.DoctorName}`,
              alignment: 'right'
            }
           ]
         ]
       },
       {
         text: 'Pacient Report',
         style: 'sectionHeader'
       },
       {
        table: {
          headerRows: 1,
          widths: ['*', '*', '*'],
          body: [
            ['Test','Result','Range'],
            ...this.invoice.products.map(p => ([p.name,p.qty, p.price])),
          ]
        }
      },
       {
           text: this.invoice.additionalDetails,
           margin: [0, 0 ,0,15]          
       },
       {
         columns: [
          [{ text: 'LAB Signature', alignment: 'left', italics: true}],
          [{ text: 'Doctor Signature', alignment: 'right', italics: true}],
          //  [{ text: 'Signature', alignment: 'right', italics: true}],
         ]
       },
       {
         text: 'Terms and Conditions',
         style: 'sectionHeader'
       },
       {
           ul: [
             'Order can be return in max 10 days.',
             'Warrenty of the product will be subject to the manufacturer terms and conditions.',
             'This is system generated invoice.',
           ],
       }
     ],
     styles: {
       sectionHeader: {
         bold: true,
         decoration: 'underline',
         fontSize: 14,
         margin: [0, 15,0, 15]          
       }
     }
   };
 }
 
  clickhome(){
    console.log("hi")
  this.router.navigateByUrl('user/dash-board');
  }
  getTest(){
    this.service.GetDropDownList().subscribe((res:any)=>{
      console.log("hello",res);
      if(res.status=='success'){
         this.dropDownData=res.data;
        console.log(this.dropDownData);
        }
      else{
      }
    })
  }
  getdocdetails(){
    this.service.GetDropDownDoctorList().subscribe((res:any)=>{
      console.log("hello",res);
      if(res.status=='success'){
         this.dropDownData2=res.data;
         this.DoctorDetails = res.data[0];
         console.log(this.DoctorDetails);
     }
    })
  }
  getPackage(){
this.service.GetDropDownPackageList().subscribe((res:any)=>{
  if(res.status=='success'){
    this.PackageData=res.data;
       this.PackageData.forEach((Element:any)=>{
         if(this.dropDownData1==''){
          console.log(Element)
           this.dropDownData1.push(Element)
         }
         else{
           let checkelement=false;
          this.dropDownData1.forEach((data:any) => {
      if(data.packageName==Element.packageName){
           checkelement=true;
  }
});
      if(checkelement==false){
        this.dropDownData1.push(Element)
      }
       }
       })
         }
})
  }

  Drowdowndata(data:any){
    this.selectedtest=data;
    }

 Drowdowndata1(data:any){  
    this.selectedpackage=data;
   }
   getDrowdowndata2(data:any){
    this.selectdoctorname =data;
     }

    sendsubmit(){
      console.log(this.selectedtest);
      console.log(this.invoice.products);
      this.checkdata=false;
        this.invoice.products.forEach((data:any)=>
        {
          console.log(data)
      if(data.testcode==this.selectedtest.testcode){
      this.checkdata=true;
      alert('The Test Has Been Already Added')
      }
      });
      console.log(this.checkdata)
      if(this.checkdata==false){
      let test=new Product;
      test.testcode=this.selectedtest.testcode;
      test.name=this.selectedtest.testdiscription;
      const chars = '0123456789';
    const stringLength = 10;
      this.PaymentorderId="";
      for (let i = 0; i < stringLength; i++) {
      const rnum = Math.floor(Math.random() * chars.length);
      this.PaymentorderId += chars.substring(rnum, rnum + 1);
     }
     this.DateAndtime=new Date().toLocaleString();
     this.reportno='INV'+this.PaymentorderId;
      test.qty=0;
      test.price=this.selectedtest.range;
      this.invoice.products.push(test);
      }
    }

    sendsubmitpackage(){
      console.log(this.selectedpackage);
      console.log(this.invoice.products);
    console.log(this.PackageData);
    // this.checkdata=false;
    this.PackageData.forEach((element:any) => {
      if(element.packageName==this.selectedpackage.packageName){
        this.checkpackage=false;
        this.invoice.products.forEach((data:any)=>
        {
        if(data.testcode==element.testcode){
        this.checkpackage=true;
        }
        });
        if( this.checkpackage==false)
        {
        let test=new Product;
          test.packagename = element.packageName;
            test.name=element.testdiscription;
            test.qty=0;
            const chars = '0123456789';
            const stringLength = 10;
              this.PaymentorderId="";
              for (let i = 0; i < stringLength; i++) {
              const rnum = Math.floor(Math.random() * chars.length);
              this.PaymentorderId += chars.substring(rnum, rnum + 1);
             }
             this.DateAndtime=new Date().toLocaleString();
             this.reportno='INV'+this.PaymentorderId;;
            test.price=element.range;
            test.testcode=element.testcode;
            
          this.invoice.products.push(test) 
        }
    }
    });
    }
    sendsubmitdoctorname(){
    console.log(this.selectdoctorname);
    this.invoice.DoctorName =this.selectdoctorname.doctorName;
    
    }
    ondelete(deleteme: number) {
      this.invoice.products.splice(deleteme,1);
         }

         savepdf(){
          this.hideme = !this.hideme;
          this.isDisplay = !this.isDisplay;
          this.createPdfDoc();
          let createuser2 = new parientreport()
          const pdfdata=pdfMake.createPdf(this.docDefinition);
          console.log(pdfdata);
          pdfdata.getBase64((data)=>{
              this.mypdf = data;
            });
            createuser2.userEmail =this.userdetails.email;
            createuser2.PhoneNumber =this.AddDataForm.get("Phonenumber")?.value;
            createuser2.InvoiceNumber=this.reportno;
            createuser2.BillDate=this.DateAndtime;
            createuser2.Age=this.PatientTableData.age;
            createuser2.PatientName=this.PatientTableData.name;
            createuser2.gender =this.PatientTableData.gender;
          this.spinner.getSpinner;
        setTimeout(() => {
          createuser2.DataFiles =  this.mypdf;
          this.service.AddReport(createuser2).subscribe((res:any)=>{
            console.log("hello",res);
            if(res.status=='success'){
              this.spinner.hide();
        alert("Details updated successfully") 
            }
          })
        }, 3000);
         }
   
    
}
