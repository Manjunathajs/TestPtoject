import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { newpasswordreset, TokenNumber } from 'src/model/userbody';

@Component({
  selector: 'app-passwordreset',
  templateUrl: './passwordreset.component.html',
  styleUrls: ['./passwordreset.component.scss']
})
export class PasswordresetComponent implements OnInit {
  Passwordreset=this.fb.group({
    username:[null],
    NewPassword:[null],
   ConfirmPassword:[null]
  })
  passwordsMatching = false;
  isConfirmPasswordDirty = false;
  confirmPasswordClass = 'form-control';
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  toekndata: any;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.toekndata=res.data
       console.log(this.toekndata)
       if(this.toekndata==false){
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
   }

  ngOnInit(): void {
    // this.checkPasswords()
  }
resetpassword(){
  this._spinner.show();
  const newpassword = new newpasswordreset();
  newpassword.userEmail=this.userdetails.email;
  newpassword.newpassword=this.Passwordreset.get("NewPassword")?.value;
  newpassword.confirmpassword=this.Passwordreset.get("ConfirmPassword")?.value;
  this.service.confirmpasswordreset(newpassword).subscribe((res:any) => {
    alert("password changed, please login again");
    this._spinner.hide();
    this.router.navigateByUrl('admin/login');
  })

}
// checkPasswords() {
//   this.isConfirmPasswordDirty = true;
//   if (this.Passwordreset.get("NewPassword")?.value == this.Passwordreset.get("ConfirmPassword")?.value) {
//     this.passwordsMatching = true;
//     this.confirmPasswordClass = 'form-control is-valid';
//   } else {
//     this.passwordsMatching = false;
//     this.confirmPasswordClass = 'form-control is-invalid';
//     alert('Check the password')
//   }
// }
}
