import { Component, OnInit } from '@angular/core';
import {FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { TokenNumber, userbody } from 'src/model/userbody';


@Component({
  selector: 'app-patient-details',
  templateUrl: './patient-details.component.html',
  styleUrls: ['./patient-details.component.scss']
})
export class PatientDetailsComponent implements OnInit {
  Emailregex: RegExp =
  /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  AddDataForm = this.fb.group({
    Name: new FormControl(''),
    patientEmail:new FormControl('',[Validators.email,Validators.min(4),Validators.pattern(this.Emailregex) ]),
    userEmail:new FormControl('',[Validators.email,Validators.required,Validators.min(4),Validators.pattern(this.Emailregex) ]),
    Age:new FormControl('',[Validators.required, Validators.pattern("^[0-9]*$")]),
    Gender:new FormControl(''),
    Address:new FormControl('',[Validators.required]),
    PhoneNumber:new FormControl('',[Validators.required,Validators.minLength(10),Validators.maxLength(10), Validators.pattern("^[0-9]*$") ]),
    AlternativeNumber:new FormControl('',[Validators.pattern("^[0-9]*$")] ),
    adharNumber:new FormControl('',[Validators.pattern("^[0-9]*$")] ),
    passPortNumber:new FormControl(''),
    doctorName:new FormControl('')
  })
  dropDownData2:any;
  selectdoctorname:any;
  reportbutton=true;
  DoctorDetails:any;
  countnum:any;
  loggedInuser:any=localStorage.getItem('LoggedInUser');
  userdetails:any=JSON.parse(this.loggedInuser);
  statusdata:any;
  toekndata: any;
  hide = true;

  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner :NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.toekndata=res.data
       console.log(this.toekndata)
       if(this.toekndata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
   }

  ngOnInit(): void {
    this.getdocdetails();
  }
  getdocdetails(){
    this.service.GetDropDownDoctorList().subscribe((res:any)=>{
      console.log("hello",res);
      if(res.status=='success'){
         this.dropDownData2=res.data;
         this.DoctorDetails = res.data;
         console.log(this.DoctorDetails);
     }
    })
  }

  getDrowdowndata2(data:any){
    this.selectdoctorname = data;
  }

  getsubmit(){
    this.AddDataForm.get('userEmail')?.setValue(this.userdetails.email);
    console.log(this.AddDataForm.getRawValue(),this.AddDataForm.valid,this.AddDataForm);
    // console.log(this.AddDataForm.get('PhoneNumber')?.value?.toString().length)
    if(this.AddDataForm.valid){
      console.log(this.selectdoctorname);
      this._spinner.show();
      if(this.statusdata!=undefined)
      {
        let createuser = new userbody()
        {
          createuser.Name =this.AddDataForm.get('Name')?.value;
          createuser.PatientEmail =this.AddDataForm.get('patientEmail')?.value;
          createuser.Age =Number(this.AddDataForm.get('Age')?.value);
          createuser.gender=this.statusdata;
          createuser.PhoneNumber =this.AddDataForm.get('PhoneNumber')?.value?.toString();
          createuser.AlternativeNumber=this.AddDataForm.get('AlternativeNumber')?.value;
          createuser.adharNumber=this.AddDataForm.get('adharNumber')?.value;
          createuser.passPortNumber=this.AddDataForm.get('passPortNumber')?.value;
          createuser.doctorName=this.AddDataForm.get('doctorName')?.value;
          createuser.Address =this.AddDataForm.get('Address')?.value;
          createuser.userEmail =this.userdetails.email;
          console.log(createuser)
          this._spinner.hide();
          this.service.Adddetails(createuser).subscribe((res:any)=>{
            console.log("hello",res);
            this.reportbutton=false;
            // window.location.reload();
            console.log('hi')
            if(res.status=='success'){
             console.log("hi");
             
               
            }
            else{
              console.log("hi")
              alert(res.message)
              if(res.message=="Patient Details Added Successfully "){
                this.router.navigateByUrl('user/patient-bill?phonenumber='+this.AddDataForm.get('PhoneNumber')?.value);
              }
            }
            this._spinner.hide();
            })
        }
      }
     else{
      alert("Please select Gender")
      this._spinner.hide();
     } 
    }
    else{
      alert('please check the input fields')
    }
    
    
  }

  billstatus(data:any){
      this.statusdata=data;
  }


  //    sendsubmitdoctorname(){

  //    }

  // senddata(){

  // }

  clickhome(){
    console.log("hi")
    this.router.navigateByUrl('user/dash-board');
  }

  generatereport(){
    // console.log(data);
   
  }

}
