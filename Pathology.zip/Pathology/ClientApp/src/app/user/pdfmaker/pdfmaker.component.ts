import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import jspdf, { jsPDF } from 'jspdf';
import * as html2canvas from "html2canvas"; 
import { AppserviceService } from 'src/app/appservice.service';
import { BillPDF, getreport } from 'src/model/userbody';
import { DomSanitizer } from '@angular/platform-browser';
import { MatTableDataSource } from '@angular/material/table';
var pdfMake = require("pdfmake/build/pdfmake");
var pdfFonts = require("pdfmake/build/vfs_fonts");
pdfMake.vfs = pdfFonts.pdfMake.vfs;
var htmlToPdfmake = require("html-to-pdfmake");
// import pdfMake from 'pdfmake/build/pdfmake';
// import pdfFonts from 'pdfmake/build/vfs_fonts';
// pdfMake.vfs = pdfFonts.pdfMake.vfs;
class Product{
  packagename:any;
  testcode:any;
  name: any;
  price: any;
  unit:any;
  qty: any;
  result:any;
  range:any;
}

class Invoice{
  customerName: any;
  address: any;
  contactNo: any;
  Age:any;
  Gender:any;
  email: any;
  DoctorName:any;
  Labname:any;
  gstNumber:any;
  
  products: Product[] = [];
  additionalDetails: any;
 }
@Component({
  selector: 'app-pdfmaker',
  templateUrl: './pdfmaker.component.html',
  styleUrls: ['./pdfmaker.component.scss']
})
export class PdfmakerComponent implements OnInit {
  @ViewChild('content') content: any = ElementRef;
  jspdf:any;
  // @ViewChild('pdfTable', { static: false }) pdfTable:any = ElementRef ;
  // @ViewChild('pdfTable') pdfTable:any = ElementRef;

  loggedInuser:any=localStorage.getItem('LoggedInUser');
  userdetails:any=JSON.parse(this.loggedInuser);
  getreporttestdata:any=[];
  verifydata: any=[];
  InvoiceForm = this.fb.group({
    InvoiceNumber: ['', Validators.required] 
    })
  invoice = new Invoice(); 
  arraydata:any=[];
  alltestdata:any=[];
  groupdata:any=[];
  data1:any;
  patientdetails:any;
  datafile: any;
  source: any;
  
  filename:any;
  pageVariable: any;
  link:any;
  docuData:any;
  dataSource = new MatTableDataSource<any>([]);
  docDefinition:any;
  withouthearderpdf:any;
  mypdf:any;
  mypdfwithouthead:any;
  PatientTableData: any;
  reportno: any;
  DateAndtime: any;
  hide=false;
  dis:any;
  checkdata: any;
  discountprice:any;
  tempBlob: any;
  InvoiceNumber:any;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private spinner: NgxSpinnerService,private sanitizer: DomSanitizer) { }

  ngOnInit(): void {
    const invoiceNumber=window.location.href.split('=')[1];
    console.log(invoiceNumber);
    if(invoiceNumber!=null){
      this.InvoiceNumber=invoiceNumber;
      this.InvoiceForm.get("InvoiceNumber")?.setValue(invoiceNumber);
      this.Showpdf();
      // this.download();
      } 
      // this.getreportpdf();
    // this.pdfveiwer();
    console.log(this.userdetails)
    let objectURL = 'data:image/png;base64,'+this.userdetails.datafiles
    this.datafile =this.sanitizer.bypassSecurityTrustResourceUrl(objectURL);
  }
//   pdfveiwer(){
//     var inv=new BillPDF();
//     inv.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value;
//     this.service.gettestreportdata(inv).subscribe((getdata:any)=>{
//       console.log(getdata.data);
//       // this.getBillPDF();
//       this.getreporttestdata=getdata.data;
//       this.getreporttestdata.forEach((result:any)=>{
//       this.verifydata.push(result.subTestGroup1)
//       })
//       console.log(this.verifydata)
//       this.verifydata.forEach((element:any)=>{
//         element.forEach((data:any)=>{
//           console.log(data)
//           this.arraydata.push(data); 
//         })
//       })
//        this.arraydata.forEach((p:any)=>{
//             let test = new Product;
//             test.packagename=p.testdiscription;
//             test.name=p.subtest;
//             this.invoice.products.push(test)
//           })
//           this.invoice.products.forEach((gele:any)=>{
//             if(this.groupdata==''){
//               this.groupdata.push(gele)
//             }
//             else{
//               let checkdata = false;
//               this.groupdata.forEach((getdata:any)=>{
//               if(getdata.packagename==gele.packagename){
//                 checkdata=true;
//               }
//               })
//               if(checkdata==false){
//                 this.groupdata.push(gele)
//               }
//             }
//           })
//     })
//     // var inv=new BillPDF();
//     // inv.InvoiceNumber='INV7743236202'
//     this.service.checkreportpdf(this.InvoiceForm.get("InvoiceNumber")?.value).subscribe((res: any) => {
// this.patientdetails=res.data[0];
// console.log(res.data)
// console.log(this.patientdetails)
//     })
    
//     console.log(this.groupdata)
//     console.log(this.invoice.products)
//   }
  // makePdf() {
  //   let doc = new jspdf('p', 'pt',[1500, 1600]);
  //   doc.html(this.content.nativeElement, {
  //     width: 190,
  //     callback: function (doc) {
  //     // doc.save();
  //     window.open(doc.output('bloburl'));
  //     }
  // });
  // }
  // downloadpdf() {
  //   let doc = new jspdf('p', 'pt',[1500, 1600]);
  //   doc.html(this.content.nativeElement, {
  //     width: 190,
  //     callback: function (doc) {
  //     doc.save();
  //     // window.open(doc.output('bloburl'));
  //     }
  // });
  // }

  // downloadAsPDF() {
  //   const pdfTable = this.pdfTable.nativeElement;
  //   var html = htmlToPdfmake(pdfTable.innerHTML);

  //   const documentDefinition = { content: html };
  //   pdfMake.createPdf(documentDefinition).open();
  // }

  // getreportpdf(){
  //   // var inv=new BillPDF();
  //   // inv.InvoiceNumber=this.InvoiceForm.get("InvoiceNumber")?.value;
  //   this.service.getreportpdfdata(this.InvoiceForm.get("InvoiceNumber")?.value).subscribe((res:any)=>{
  //     console.log(res.data)
  //   })
  // }
  
  download(){
    this.spinner.show();
    this.service.getreportpdfdata(this.InvoiceForm.get("InvoiceNumber")?.value).subscribe(blob=>{
      const a = document.createElement('a');
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl;
      a.download = this.InvoiceNumber+'.pdf';
      a.click();
      URL.revokeObjectURL(objectUrl);
      this.spinner.hide();
    });
  }

  Showpdf(){
    this.tempBlob= null;
    this.spinner.show();
    this.service.getreportpdfdata(this.InvoiceForm.get("InvoiceNumber")?.value).subscribe(blob=>{
      console.log(blob);
      this.tempBlob = new Blob([blob], { type:'application/pdf' });
      const fileReader = new FileReader();
      fileReader.onload = () => {
        this.source = new Uint8Array(fileReader.result as ArrayBuffer);
    };
    fileReader.readAsArrayBuffer(this.tempBlob); 
this.spinner.hide();
    //   const a = document.createElement('a');
    //   const objectUrl = URL.createObjectURL(blob)
    //   a.href = objectUrl;
    // this.source = `data:application/pdf;base64,${objectUrl}`;
    // this.link = document.createElement("a");
    // this.link.href = this.source;

    // this.link.click(); 
  
  });
  // })
  }

  print(){
    this.spinner.show();
    this.service.getreportpdfdata(this.InvoiceForm.get("InvoiceNumber")?.value).subscribe(blob=>{
      const a = document.createElement('a');
      const objectUrl = URL.createObjectURL(blob)
      a.href = objectUrl;
      a.download = this.InvoiceNumber+'.pdf';
      URL.revokeObjectURL(objectUrl);
      const blobUrl = URL.createObjectURL(blob);
      const iframe = document.createElement('iframe');
      iframe.style.display = 'none';
      iframe.src = blobUrl;
      document.body.appendChild(iframe);
      if(iframe.contentWindow!=null){
        iframe.contentWindow.print();
      }
      URL.revokeObjectURL(objectUrl);

      this.spinner.hide();
    }); 
  }

  nextPage() {
    this.pageVariable++;
  }
  
  afterLoadComplete(pdf: any) {
    console.log('after-load-complete');
  }
  
  pageRendered(e: CustomEvent) {
    console.log('(page-rendered)', e);
  }
  
  textLayerRendered(e: CustomEvent) {
    console.log('(text-layer-rendered)', e);
  }
  
  onFileSelected() {
    let $img: any = document.querySelector('#file');
  
    if (typeof (FileReader) !== 'undefined') {
      let reader = new FileReader();
  
      reader.onload = (e: any) => {
        this.source = e.target.result;
      };
  
      reader.readAsArrayBuffer($img.files[0]);
    }
  }
}
