import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SpecialistEmpComponent } from './specialist-emp.component';

describe('SpecialistEmpComponent', () => {
  let component: SpecialistEmpComponent;
  let fixture: ComponentFixture<SpecialistEmpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SpecialistEmpComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(SpecialistEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
