import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { AppserviceService } from 'src/app/appservice.service';
import { newBillstatus, ReportDetails, TokenNumber } from 'src/model/userbody';
(<any>pdfMake).vfs = pdfFonts.pdfMake.vfs;
class Product{
  name: any;
  price: any;
  testcode:any;
  
}
class Invoice{

  
  products: Product[] = [];
  additionalDetails: any;
 }
@Component({
  selector: 'app-specialist-emp',
  templateUrl: './specialist-emp.component.html',
  styleUrls: ['./specialist-emp.component.scss']
})
export class SpecialistEmpComponent implements OnInit {
  displayedColumns: any[] = ['SNo','PatientName','Phonenumber','Dateandtime','Age','Gender','result','Getreport','ReportStatus'];
  dataSource = new MatTableDataSource<any>([]);
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  EmailForm = this.fb.group({
    userEmail: ['', Validators.required],
  })
  docDefinition:any;
selectedtest:any;

dataLocalUrl: any;
selectedFeatures: any = [];
filename = 'Patient Report';
fileUrl:any;
image:any;
pdfbill:any;
source:any;
pdfHref:any;
reader:any;
pdfSrc:any;
pdfSrc1 :any;
pageVariable = 1;
statusdata:any;
reportdata:any;
patientData:any=[];
invoice = new Invoice();
testdatadetails:any=[];
  toekndata: any;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) { }

  ngOnInit(): void {
      this.getList();  
  }


  getList() {
    this._spinner.show();
    console.log("in loop of list")
    const PatientEmail = new ReportDetails();
    PatientEmail.userEmail = this.userdetails.userEmail;
    this.service.PendingApproval(PatientEmail).subscribe((res: any) => {
this.reportdata=res.data;
this._spinner.hide();
console.log(this.reportdata)
console.log(this.patientData)
let filterData=  this.reportdata.filter((obj:any, pos:any, arr:any) => {
  return arr.map((mapObj:any) => mapObj["invoiceNumber"]).indexOf(obj["invoiceNumber"]) === pos;
});
console.log(filterData);
this.testdatadetails=filterData;
this.dataSource.data = this.testdatadetails;
    })
}
billstatus(data:any){
  this.statusdata=data;
    }
Logout(){
  this._spinner.show();
  console.log("hi")
  this.router.navigateByUrl('admin/login');
  this._spinner.hide();
}

GetReport(data:any){
  this._spinner.show();
  this.router.navigateByUrl('user/edited-by-specialist?invoiceNumber='+data.invoiceNumber);
  this._spinner.hide();
}

senddata(data:any){
  this._spinner.show();
  let Billstatus = new newBillstatus();
  console.log(this.EmailForm.get("Phonenumber")?.value)
Billstatus.Phonenumber = data.phoneNumber;
Billstatus.reportstatus = this.statusdata;
this.service.patientreportstaus(Billstatus).subscribe((res:any)=>{
let thedatastatus = res.data;
this._spinner.hide();
console.log(thedatastatus)
})
}
}
