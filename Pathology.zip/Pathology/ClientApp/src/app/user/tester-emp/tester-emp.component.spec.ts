import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TesterEmpComponent } from './tester-emp.component';

describe('TesterEmpComponent', () => {
  let component: TesterEmpComponent;
  let fixture: ComponentFixture<TesterEmpComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TesterEmpComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TesterEmpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
