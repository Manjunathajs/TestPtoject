import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';
import { AppserviceService } from 'src/app/appservice.service';
import { newBillstatus, ReportDetails, TokenNumber } from 'src/model/userbody';
(<any>pdfMake).vfs = pdfFonts.pdfMake.vfs;
class Product{
  name: any;
  price: any;
  testcode:any;
  
}
class Invoice{

  
  products: Product[] = [];
  additionalDetails: any;
 }
@Component({
  selector: 'app-tester-emp',
  templateUrl: './tester-emp.component.html',
  styleUrls: ['./tester-emp.component.scss']
})
export class TesterEmpComponent implements OnInit {
  displayedColumns: any[] = ['SNo','PatientName','Phonenumber','Dateandtime','Age','Gender','result','Getreport','ReportStatus'];
  dataSource = new MatTableDataSource<any>([]);
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  EmailForm = this.fb.group({
    userEmail: ['', Validators.required],
  })
  docDefinition:any;
selectedtest:any;

dataLocalUrl: any;
selectedFeatures: any = [];
filename = 'Angular 5';
fileUrl:any;
image:any;
pdfbill:any;
source:any;
pdfHref:any;
reader:any;
pdfSrc:any;
pdfSrc1 :any;
pageVariable = 1;
statusdata:any;
testerreports:any=[];
reportdata:any=[];
testreportdata:any=[];
invoice = new Invoice(); 
  toekndata: any;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private spinner: NgxSpinnerService) {
    
   }

  ngOnInit(): void {
   this.getList();
    console.log(this.userdetails)
  }
  getList() {
    this.spinner.show();
    const PatientEmail = new ReportDetails();
    PatientEmail.userEmail = this.userdetails.userEmail;
    this.service.PatientReportData(PatientEmail).subscribe((res: any) => {
      this.spinner.hide();
      this.testerreports = res.data;
      this.testerreports.forEach((testreport:any)=>{
        if(testreport.reportstatus=="In-Process"){
          this.testreportdata.push(testreport)
        }
      })

        this.testreportdata.forEach((Element:any)=>{
          if(this.reportdata == ''){
            this.reportdata.push(Element);
            // this.dataSource.data = this.reportdata;
          }
          else{
            let checktest = false;
            this.reportdata.forEach((testdata:any)=>{
              if(testdata.invoiceNumber==Element.invoiceNumber){
                checktest=true;
              }
            })
            if(checktest==false){
              this.reportdata.push(Element);
              // this.dataSource.data = this.reportdata;
            }
          }

        })
        this.dataSource.data = this.reportdata;
    })
}
GetReport(data:any){
  this.router.navigateByUrl('user/editpatientreport?invoiceNumber='+data.invoiceNumber);
}
billstatus(data:any){
  this.statusdata=data;
    }
Logout(){
  this.router.navigateByUrl('admin/login');
}
senddata(data:any){
  let Billstatus = new newBillstatus();
  
Billstatus.Phonenumber = data.phoneNumber;
Billstatus.result = this.statusdata;
Billstatus.reportstatus="Pending";
this.service.patientreportstaus(Billstatus).subscribe((res:any)=>{
})
}
}
