import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserhomepageComponent } from './userhomepage/userhomepage.component';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from '../login/login.component';
import { PatientDetailsComponent } from './patient-details/patient-details.component';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldControl, MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatInputModule } from '@angular/material/input';
import { MatTableModule } from '@angular/material/table';
import { PatientBillComponent } from './patient-bill/patient-bill.component';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import {MatDialogModule} from '@angular/material/dialog';
import { PacientReportComponent } from './pacient-report/pacient-report.component';
import { GetPatientReportComponent } from './get-patient-report/get-patient-report.component';
import { GetPatientBillRecordsComponent } from './get-patient-bill-records/get-patient-bill-records.component';
import { BillReportPDFComponent } from './bill-report-pdf/bill-report-pdf.component';
import  {  PdfViewerModule  }  from  'ng2-pdf-viewer';
import { AddDocDetailsComponent } from './add-doc-details/add-doc-details.component';
import { GetpatientreportpdfComponent } from './getpatientreportpdf/getpatientreportpdf.component';
import { DashBoardComponent } from './dash-board/dash-board.component';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MDBBootstrapModule } from "angular-bootstrap-md";
import { ViewpackagedetailsComponent } from './viewpackagedetails/viewpackagedetails.component';
import { BillWithoutHeaderComponent } from './bill-without-header/bill-without-header.component';
import { GetpdfwithheaderComponent } from './getpdfwithheader/getpdfwithheader.component';
import { AddemployeesComponent } from './addemployees/addemployees.component';
import { SpecialistEmpComponent } from './specialist-emp/specialist-emp.component';
import { TesterEmpComponent } from './tester-emp/tester-emp.component';
import { EditpatientreportComponent } from './editpatientreport/editpatientreport.component';
import { EditedBySpecialistComponent } from './edited-by-specialist/edited-by-specialist.component';
import {MatChipsModule} from '@angular/material/chips';
import { NgxSpinnerModule } from 'ngx-spinner';
import { PasswordresetComponent } from './passwordreset/passwordreset.component';
import {ScrollingModule} from '@angular/cdk/scrolling';
import {MatAutocompleteModule} from '@angular/material/autocomplete';
import { MatSelectFilterModule } from 'mat-select-filter';
import { AdminLoginComponent } from '../admin-login/admin-login.component';
import { PdfmakerComponent } from './pdfmaker/pdfmaker.component';
import { IndirectBillingComponent } from './indirect-billing/indirect-billing.component';
import {MatSidenavModule} from '@angular/material/sidenav';
import { PdfJsViewerModule } from 'ng2-pdfjs-viewer'; // <-- Import PdfJsViewerModule module
import { MianHomePageComponent } from '../mian-home-page/mian-home-page.component';
import { SharedComponent } from '../admin/shared/shared.component';
import { MainloginComponent } from '../admin/mainlogin/mainlogin.component';
import { NgxPaginationModule } from 'ngx-pagination';
import {MatPaginatorModule} from '@angular/material/paginator';



const routes: Routes = [
  {
    path:'',
    redirectTo: 'LABLIFE/home',
    pathMatch: 'prefix',

  }, 
  {
    path:'LABLIFE',
    children:[
      {
        path:'home',
        component:LoginComponent
      },
      {
        path:'adminLogin',
        component:AdminLoginComponent
      }
    ]
  },
  {
    path:'user',
    children:[
      {
        path:'dash-board',
        component:DashBoardComponent
      },
      {
        path:'userhomepage',
        component:UserhomepageComponent
      },
      {
        path:'patientdetails',
        component:PatientDetailsComponent
      },
      {
        path:'patient-bill',
        component:PatientBillComponent
      },
      {
        path:'pacient-report',
        component:PacientReportComponent
      },
      {
        path:'get-patient-report',
        component:GetPatientReportComponent
      },
      {
        path:'get-patient-bill-records',
        component:GetPatientBillRecordsComponent
      },
      {
        path:'bill-report-pdf',
        component:BillReportPDFComponent
      },
      {
        path:'add-doc-details',
       component:AddDocDetailsComponent
      },
      {
        path:'getpatientreportpdf',
        component:GetpatientreportpdfComponent
      },
      {
        path:'viewpackagedetails',
        component:ViewpackagedetailsComponent
      },
      {
        path:'bill-without-header',
        component:BillWithoutHeaderComponent
      },
      {
        path:'getpdfwithheader',
        component:GetpdfwithheaderComponent
      },
      {
        path:'addemployees',
        component:AddemployeesComponent
      },
      {
        path:'specialist-emp',
        component:SpecialistEmpComponent
      },
      {
        path:'tester-emp',
        component:TesterEmpComponent
      },
      {
        path:'editpatientreport',
        component:EditpatientreportComponent
      },
      {
        path:'edited-by-specialist',
        component:EditedBySpecialistComponent
      },
      {
        path:'passwordreset',
        component:PasswordresetComponent
      },
      {
        path:'pdfmaker',
        component:PdfmakerComponent
      },
      {
        path:'shared',
        component:SharedComponent
      },
      {
        path:'login',
        component:MainloginComponent
    },
    {
      path:'indirect-billing',
      component:IndirectBillingComponent
    }
    
     
    ]}
]

@NgModule({
  declarations: [
    // LoginComponent,
     UserhomepageComponent,
    PatientDetailsComponent,
    PatientBillComponent,
    PacientReportComponent,
    GetPatientReportComponent,
    GetPatientBillRecordsComponent,
    BillReportPDFComponent,
    AddDocDetailsComponent,
    GetpatientreportpdfComponent,
    DashBoardComponent,
    ViewpackagedetailsComponent,
    BillWithoutHeaderComponent,
    GetpdfwithheaderComponent,
    AddemployeesComponent,
    SpecialistEmpComponent,
    TesterEmpComponent,
    EditpatientreportComponent,
    EditedBySpecialistComponent,
    PasswordresetComponent,
    PdfmakerComponent,
    IndirectBillingComponent,
    
    
    
    
  ],
  imports: [
    MatSidenavModule,
    CommonModule,
    PdfJsViewerModule,
    RouterModule.forChild(routes),
    MatCardModule,
    MatFormFieldModule ,
    FormsModule,
    ReactiveFormsModule,
    MatToolbarModule,
   MatInputModule,
    MatTableModule,
     MatSelectModule,
      MatIconModule,
      PdfViewerModule,
      MatDialogModule,
MatDatepickerModule,
MDBBootstrapModule.forRoot(),
MatChipsModule,
NgxSpinnerModule,
ScrollingModule,
MatAutocompleteModule,
MatSelectFilterModule,
NgxPaginationModule,
MatPaginatorModule
  ]
})
export class UserModule { }
