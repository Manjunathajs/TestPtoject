import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { window } from 'rxjs';
import { AppserviceService } from 'src/app/appservice.service';
import { EmailId, paceintNumber, Patientregisternumber, TokenNumber} from 'src/model/userbody';

@Component({
  selector: 'app-userhomepage',
  templateUrl: './userhomepage.component.html',
  styleUrls: ['./userhomepage.component.scss']
})
export class UserhomepageComponent implements OnInit {
  displayedColumns: any[] = ['SNo','Name','PatientEmail','phonenumber','Patientregisternumber','Age','gender','Adharnumber','DoctorName'];
  dataSource = new MatTableDataSource<any>([]);
  PhoneNumberForm = this.fb.group({
    PhoneNumber: ['',Validators.min(10)],
    // Patientregisternumber:[''],
    Name:[''],
    // paymentstatus:['']
  });
  getbillstatus:any;
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  toekndata: any;
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.toekndata=res.data
       console.log(this.toekndata)
       if(this.toekndata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
   }

  ngOnInit(): void {
    this.getList();
    
  }

  Add_details(){
   console.log("hi")
   this.router.navigateByUrl('user/patient-details');
  }

  getList() {
  this._spinner.show();
    const email = new EmailId();
    email.EmailId = this.userdetails.email;
    this.service.UserDataList(email).subscribe((res: any) => {
  this.dataSource.data = res.data;
  this._spinner.hide();
  console.log(this.dataSource.data)
 })
}


clickhome(){
  this._spinner.show();
  console.log("hi")
  this.router.navigateByUrl('user/dash-board');
  this._spinner.hide();
}



GetUserDetails(){
  this._spinner.show();
  console.log(this.getbillstatus)
    const PhoneNumber = new paceintNumber();
    PhoneNumber.Phonenumber = this.PhoneNumberForm.get("PhoneNumber")?.value;
    PhoneNumber.Name=this.PhoneNumberForm.get("Name")?.value;
    this.service.getpatientwithPhoneNumberList(PhoneNumber).subscribe((res:any) => {
      if (res.status == 'success') {
        this._spinner.hide();
        this.dataSource.data = res.data;
        
       }
      else {
        this._spinner.hide();
      }
      console.log("hello hi the output is",res.data);
    }) 
}
}