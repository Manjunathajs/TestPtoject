import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppserviceService } from 'src/app/appservice.service';
import { TokenNumber } from 'src/model/userbody';

@Component({
  selector: 'app-viewpackagedetails',
  templateUrl: './viewpackagedetails.component.html',
  styleUrls: ['./viewpackagedetails.component.scss']
})
export class ViewpackagedetailsComponent implements OnInit {
  displayedColumns: any[] = ['packagename','testdiscription','amount','testcode']
  // testdisplayColumns:any[] = []
  dataSource = new MatTableDataSource<any>([]);
  packagesource = new MatTableDataSource<any>([]);
  packagename:any=[];
  showPackage:any=[];
  singlepackagename:any=[];
  toekndata: any;
  loggedInuser: any = localStorage.getItem('LoggedInUser');
  userdetails: any = JSON.parse(this.loggedInuser);
  constructor(private fb:FormBuilder,private router:Router,private service:AppserviceService,private _spinner: NgxSpinnerService) {
    let tokennumber = new TokenNumber();
    tokennumber.Email =this.userdetails.tokenNumber;
    this.service.checktimeout(tokennumber).subscribe((res:any)=>{
      this.toekndata=res.data
       console.log(this.toekndata)
       if(this.toekndata==false){
        alert('session as ended login again')
        this.router.navigateByUrl('login');
       }
      })
    console.log(this.userdetails)
   }

  ngOnInit(): void {
    this.getpackagelist();
    // this.gettestlist();
  }
  getpackagelist(){
    this._spinner.show();
    this.service.GetPackageList().subscribe((res:any)=>{
      // console.log("hello",res);
      this.dataSource.data=res.data;
      this._spinner.hide();
         this.packagename.forEach((Element:any)=>{
           if(Element.packageName==''){
           this.singlepackagename.push(Element)
           this.dataSource.data=this.singlepackagename;
           }
           else{
             let checkdata=false;
             this.singlepackagename.forEach((data:any)=>{
               if(data.packageName==Element.packageName){
                 checkdata=true;
               }
             })
             if(checkdata==false){
               this.singlepackagename.push(Element);
               this.showPackage=this.singlepackagename;
             }
           }
           
         })
      })
  }
  clickhome(){
    console.log("hi")
    this.router.navigateByUrl('user/dash-board');
  }
}
