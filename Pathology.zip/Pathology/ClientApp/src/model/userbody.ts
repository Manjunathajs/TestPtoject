export class userbody{
    Name!:any;
    Age!:any;
    gender!:any;
    Address!:any;  
    PhoneNumber!:any;
AlternativeNumber!:any;
    PatientEmail!:any;
    adharNumber!:any;
    passPortNumber!:any;
    doctorName!:any;
    userEmail!:any;
}
export class AddEmployees{
    userEmail!:any;
    Name!:any;
    MobileNumber!:any;
    EmailId!:any;
    Password!:any;
    Jobdiscription!:any;
}
export class loginbody{

    EmailId!:any;
    Password!:any;
}
export class temppassword{
    userEmail:any;
}
export class newpasswordreset{
    userEmail!:any;
    newpassword!:any;
    confirmpassword!:any;
}
export class Adminregister{
    Name!:any;
    Email!:any;
    AdminEmail!:any;
    PhoneNumber!:any;
    GSTNumber!:any;
    Address!:any;
    Password!:any;
}
export class userNumber{
    Phonenumber!:any;
}
export class EmailId{
    EmailId!:any;
}
export class Patientregisternumber{
    patientregisternumber!:any;
}
export class paceintNumber{
    Phonenumber!:any;
    Patientregisternumber!:any;
    Name!:any;
    paymentstatus!:any;
}
export class usertestDetails{
    Email!:any;
    testdiscription!:any;
    Amount!:any;
    Range!:any;
    
}
export class getbillpdf{
    InvoiceNumber!:any;
    BillType!:any;
}
export class DoctorDetails{
    Email!:any;
    HospitalName!:any;
    DoctorName!:any;
   DocAddress!:any;
}
export class ReportDetails{
userEmail!:any;
}
export class BillReport{
    userEmail!:any;
    Phonenumber!:any;
    PatientName!:any;
    BillDate!:any;
    BillType!:any;
    InvoiceNumber!:any;
    DataFiles!:any;
}
export class TestDetails{
    editeddate!:any;
    subtest!:any;
    testcode!:any;
    sampletype!:any;
    userEmail!:string;
    Name!:string;
    Date!:string;
    Age!:string;
    gender!:string;
    units!:any;
    reportstatus!:string;
    Phonenumber!:any;
    InvoiceNumber!:any;
    testdiscription!:string;
    quantity!:any;
    amount!:any;
    Patientregisternumber!:any;
    result!:any;
    range!:string;
    doctorName!:any;
    totaltest!:any;
    totalamount!:any;
}
export class parientreport{
    Age!:any;
    PatientName!:any;
    gender!:any;
    userEmail!:any;
    PhoneNumber!:any;
    InvoiceNumber!:any;
    BillDate!:any;
    DataFiles!:any;
}
export class billrecords{
    userEmail!:any;
    DataFiles!:any;
}
export class newBillstatus{
    Phonenumber!:any;
    result!:any;
    reportstatus!:any;
}
export class BillPDF{
    InvoiceNumber!:any;
}
export class BillPDF1{
    InvoiceNumber!:any;
    
}
export class getreport{
    InvoiceNumber!:any;
}
export class TokenNumber{
    Email!:any;
}
export class addtestmanually{
    testdiscription:any;
    subtest:any;
    Range:any;
    Units:any;
    amount:any;
    testcode:any;
}
export class Addtestparameter{
    TestName!:any;
    Name!:any;
    Range!:any;
    TestId!:any;
    testcode!:any;
    TestParamName!:any;
}
export class contactus{
    name!:any;
    emailaddress!:any;
    contactnumber!:any;
    organisation!:any;
    yourmessage!:any;
}
export class sendmessage1{
    name!:any;
    emailaddress!:any;
}
export class addnewpackage{
    UserEmail!:any;
    purchaseDate!:any;
    expiryDate!:any;
    status!:any;
}