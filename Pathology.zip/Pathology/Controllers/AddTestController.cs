﻿using Medical_Lab.Model.Data_Model;
using Medical_Lab.Model.Request_Model;
using Medical_Lab.Model.Responce_Model;
using Microsoft.AspNetCore.Mvc;
using System;

using System.Threading.Tasks;

using ClosedXML.Excel;
using System.Linq;

namespace Medical_Lab.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AddTestController : ControllerBase
    {
        private DataBaseContext context;
        public bool verifydata;
        public AddTestController(DataBaseContext _context)
        {
            this.context = _context;

        }

        [HttpPost]
        [Route("AddPackageDetails")]
        public async Task<IActionResult> AddnewPackageAsync([FromForm] TestData test)
        {
            Response userresponse = new Response();
            context.PackageTable.RemoveRange(context.PackageTable);
            context.SaveChanges();
            try
            {
                XLWorkbook workBook = new XLWorkbook(test.DataFiles.OpenReadStream());
                //Read the first Sheet from Excel file.
                IXLWorksheet workSheet = workBook.Worksheet(1);
                bool firstRow = true;
                foreach (IXLRow row in workSheet.Rows())
                {
                    //Use the first row to add columns to DataTable.
                    if (firstRow)
                    {
                        foreach (IXLCell cell in row.Cells())
                        {
                            Console.WriteLine(cell.Value.ToString());

                        }
                        firstRow = false;

                    }
                    else
                    {
                        int i = 0;
                        var testtabledata = new PackageTable();
                        foreach (IXLCell cell in row.Cells())
                        {
                            var firstcolumn1 = cell;
                            var firstcolumn = firstcolumn1.ToString().Substring(0, 1);
                            if (firstcolumn == "A")
                            {
                                testtabledata.PackageName = firstcolumn1.Value.ToString();

                            }
                            if (firstcolumn == "B")
                            {
                                testtabledata.testdiscription = firstcolumn1.Value.ToString();
                            }
                            if (firstcolumn == "C")
                            {
                                testtabledata.subtest = firstcolumn1.Value.ToString();
                            }
                            if (firstcolumn == "D")
                            {
                                testtabledata.units = firstcolumn1.Value.ToString();
                            }
                            if (firstcolumn == "E")
                            {
                                testtabledata.Range = firstcolumn1.Value.ToString();
                            }
                            if (firstcolumn == "F")
                            {
                                testtabledata.Amount = (int)Convert.ToInt32(firstcolumn1.Value);
                            }
                            if (firstcolumn == "G")
                            {
                                testtabledata.testcode = firstcolumn1.Value.ToString();
                            }
                        }

                        context.PackageTable.Update(testtabledata);
                        context.SaveChanges();
                        userresponse.status = "Success";
                        userresponse.message = "Data is Inserted";


                    }
                }
            }
            catch (Exception ex)
            {
                userresponse.status = "Failed";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }


            return Ok(userresponse);
        }
        [HttpPost]
        [Route("AddTestDetails")]
        public async Task<IActionResult> AddnewTestAsync([FromForm] TestData test)
        {
            Response userresponse = new Response();
            context.testtable.RemoveRange(context.testtable);
            context.SaveChanges();
            try
            {
                XLWorkbook workBook = new XLWorkbook(test.DataFiles.OpenReadStream());
                //Read the first Sheet from Excel file.
                IXLWorksheet workSheet = workBook.Worksheet(1);
                bool firstRow = true;
                foreach (IXLRow row in workSheet.Rows())
                {

                    //Use the first row to add columns to DataTable.
                    if (firstRow)
                    {
                        foreach (IXLCell cell in row.Cells())
                        {

                            Console.WriteLine(cell.Value.ToString());

                        }
                        firstRow = false;

                    }
                    else
                    {
                        int i = 0;
                        var testtabledata = new TestTable();
                        foreach (IXLCell cell in row.Cells())
                        {
                            var firstcolumn1 = cell;
                            var firstcolumn = firstcolumn1.ToString().Substring(0, 1);
                            if (firstcolumn == "A")
                            {
                                testtabledata.testdiscription = firstcolumn1.Value.ToString();
                            }
                            if (firstcolumn == "B")
                            {
                                testtabledata.subtest = firstcolumn1.Value.ToString();
                            }
                            if (firstcolumn == "C")
                            {
                                testtabledata.units = firstcolumn1.Value.ToString();
                            }
                            if (firstcolumn == "D")
                            {
                                testtabledata.Range = firstcolumn1.Value.ToString();
                            }
                            if (firstcolumn == "E")
                            {
                                testtabledata.Amount = (int)Convert.ToInt32(firstcolumn1.Value);
                            }
                            if (firstcolumn == "F")
                            {
                                testtabledata.testcode = firstcolumn1.Value.ToString();
                            }
                        }

                        context.testtable.Add(testtabledata);
                        context.SaveChanges();
                        userresponse.status = "Success";
                        userresponse.message = "Data is Inserted";

                    }
                }
            }
            catch (Exception ex)
            {
                userresponse.status = "Failed";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }


            return Ok(userresponse);
        }


        [HttpPost]
        [Route("AddTestManually")]
        public IActionResult AddTestManually([FromBody] TestTable test)
        {
            Response userresponse = new Response();
            if (test.testdiscription == "")
            {
                userresponse.status = "failed";
                userresponse.message = "test description not found";
                return StatusCode(500, userresponse);
            }
            else
            {
                try
                {
                    var testData = new TestTable();
                    testData.Amount = test.Amount;
                    testData.testdiscription = test.testdiscription;
                    testData.subtest = test.subtest;
                    testData.Range = test.Range;
                    testData.units = test.units;
                    testData.testcode = test.testcode;
                    context.testtable.Add(testData);
                    context.SaveChanges();
                    userresponse.status = "success";
                    userresponse.message = "test added successfully";
                    return Ok(userresponse);
                }
                catch (Exception ex)
                {
                    userresponse.status = "failed";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }
            }
        }


        [HttpPost]
        [Route("AddTestParameters")]
        public IActionResult AddTestParameters([FromBody] TestParameters testParameter)
        {
            Response userresponse = new Response();
            if (testParameter.TestName == "")
            {
                userresponse.status = "failed";
                userresponse.message = "test Name not found";
                return StatusCode(500, userresponse);
            }
            else if (testParameter.Name == "")
            {
                userresponse.status = "failed";
                userresponse.message = "test parameter Name not found";
                return StatusCode(500, userresponse);
            }
            else
            {
                try
                {
                    var testData = context.testtable.FirstOrDefault(r => r.testdiscription == testParameter.TestName);
                    if (testData != null)
                    {
                        var testParameterData = new TestParameters();
                        testParameterData.TestName = testParameter.TestName;
                        testParameterData.Name = testParameter.Name;
                        testParameterData.Range = testParameter.Range;
                        testParameterData.TestId = testData.Id;
                        testParameterData.TestCode = testData.testcode;
                        testParameterData.TestParamName = testParameter.TestParamName;
                        testParameterData.unit = testParameter.unit;
                        context.TestParameters.Add(testParameterData);
                        context.SaveChanges();
                        userresponse.status = "success";
                        userresponse.message = "test Parameter added successfully";
                        userresponse.data = testParameterData;
                        return Ok(userresponse);

                    }
                    else
                    {
                        userresponse.status = "failed";
                        userresponse.message = "test Not found please add test and then add parameters";
                        return StatusCode(500, userresponse);
                    }

                }
                catch (Exception ex)
                {
                    userresponse.status = "failed";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("AddTestManuallyother")]
        public IActionResult AddTestManuallyother([FromBody] AddtestmanullyRequest test)
        {
            Response userresponse = new Response();
            if (test.testdiscription == "")
            {
                userresponse.status = "failed";
                userresponse.message = "test description not found";
                return StatusCode(500, userresponse);
            }
            else
            {
                try
                {
                    var testData = new TestTable();
                    testData.Amount = Convert.ToInt32(test.Amount);
                    testData.testdiscription = test.testdiscription;
                    testData.subtest = test.subtest;
                    testData.Range = test.Range;
                    testData.units = test.units;
                    testData.testcode = test.testcode;
                    context.testtable.Add(testData);
                    context.SaveChanges();
                    userresponse.status = "success";
                    userresponse.message = "test added successfully";
                    return Ok(userresponse);
                }
                catch (Exception ex)
                {
                    userresponse.status = "failed";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }
            }
        }

        [HttpPost]
        [Route("updateTestParameters")]
        public IActionResult updateTestParameters([FromBody] TestParameters testParameter)
        {
            Response userresponse = new Response();
            if (testParameter.TestName == "")
            {
                userresponse.status = "failed";
                userresponse.message = "test Name not found";
                return StatusCode(500, userresponse);
            }
            else if (testParameter.Name == "")
            {
                userresponse.status = "failed";
                userresponse.message = "test parameter Name not found";
                return StatusCode(500, userresponse);
            }
            else
            {
                try
                {
                    var testData = context.TestParameters.FirstOrDefault(r => r.Id == testParameter.Id);
                    if (testData != null)
                    {
                        testData.TestName = testParameter.TestName;
                        testData.Name = testParameter.Name;
                        testData.Range = testParameter.Range;
                        testData.TestParamName = testParameter.TestParamName;


                        context.TestParameters.Update(testData);
                        context.SaveChanges();
                        userresponse.status = "success";
                        userresponse.message = "test Parameter added successfully";
                        userresponse.data = testData;
                        return Ok(userresponse);

                    }
                    else
                    {
                        userresponse.status = "failed";
                        userresponse.message = "test Not found please add test and then add parameters";
                        return StatusCode(500, userresponse);
                    }

                }
                catch (Exception ex)
                {
                    userresponse.status = "failed";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }
            }
        }

        [HttpPost]
        [Route("AddPackage")]
        public IActionResult addPackage([FromBody] SubscriptionPackage subscriptionPackage)
        {
            Response userresponse = new Response();
            if (subscriptionPackage.UserEmail == "")
            {
                userresponse.status = "failed";
                userresponse.message = "user email not found";
                return StatusCode(500, userresponse);
            }
            else
            {
                try
                {
                    var SubscriptionPackagedata = new SubscriptionPackage();
                    SubscriptionPackagedata.purchaseDate = DateTime.Today.ToString();
                    SubscriptionPackagedata.expiryDate = DateTime.Now.AddDays(365).ToString();
                    SubscriptionPackagedata.UserEmail = subscriptionPackage.UserEmail;
                    SubscriptionPackagedata.status = "Active";
                    context.SubscriptionPackage.Add(SubscriptionPackagedata);
                    context.SaveChanges();
                    userresponse.status = "success";
                    userresponse.message = "test Parameter added successfully";
                    userresponse.data = SubscriptionPackagedata;
                    return Ok(userresponse);
                }
                catch (Exception ex)
                {
                    userresponse.status = "failed";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }
            }
        }
    }
}
