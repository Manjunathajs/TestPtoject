﻿using Medical_Lab.Extension;
using Medical_Lab.Model.Data_Model;
using Medical_Lab.Model.Request_Model;
using Medical_Lab.Model.Responce_Model;
using Medical_Lab.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;


namespace Medical_Lab.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : Controller
    {
        private DataBaseContext context;
        private readonly IMailService mailService;
        private readonly IUserRepository userRepository;
        private readonly ITokenService _tokenService;
        private readonly IConfiguration _config;
        public AuthController(DataBaseContext _context, IMailService mailService, IUserRepository userRepository, ITokenService tokenService, IConfiguration config)
        {
            this.context = _context;
            this.mailService = mailService;
            this.userRepository = userRepository;
            _tokenService = tokenService;
            _config = config;
        }


        [HttpPost]
        [Route("PostUsers")]
        public async Task<IActionResult> AddUser([FromForm] AddUserReq user)
        {
            Response userresponse = new Response();
            var newuser = user.Createuser();
            var userfound = context.Userr.FirstOrDefault(r => r.Email == user.AdminEmail && r.Role == 2);
            if (userfound != null)
            {
                if (user.Email == null || user.Email == "")
                {
                    userresponse.data = null;
                    userresponse.status = "fail";
                    userresponse.message = "email not found unable to add user ";
                    return Ok(userresponse);
                }
                else if (user.Password == null || user.Password == "")
                {
                    userresponse.status = "fail";
                    userresponse.message = "passsword not found unable to add user";
                    return Ok(userresponse);
                }
                else
                {
                    var userfound1 = context.Userr.FirstOrDefault(R => R.Email == user.Email);
                    if (userfound1 == null)
                    {
                        try
                        {
                            Random random = new Random();
                            const string chars = "0123456789";
                            var data = new string(Enumerable.Repeat(chars, 5)
                            .Select(s => s[random.Next(s.Length)]).ToArray());
                            data = string.Concat("LAB", data);
                            IFormFile myfile = user.DataFiles;
                            var userData = new UserRegistration();
                            using (MemoryStream ms = new MemoryStream())
                            {
                                await myfile.CopyToAsync(ms);
                                userData.DataFiles = ms.ToArray();
                                userData.Lab_Name = user.Name;
                                userData.Email = user.Email;
                                userData.Password = user.Password;
                                userData.Phonenumber = user.PhoneNumber;
                                userData.GST_Number = user.GSTNumber;
                                userData.Lab_Address = user.Address;
                                userData.AdminEmail = user.AdminEmail;
                                userData.Labcode = data;
                                userData.Role = 1;
                            }
                            context.Userr.Add(userData);
                            context.SaveChanges();
                            userresponse.status = "Success";
                            userresponse.message = "Account Created Successfully ";
                            userresponse.data = userData;
                            return Ok(userresponse);
                        }
                        catch (Exception ex)
                        {
                            userresponse.status = "Failed";
                            userresponse.message = ex.Message;
                            return StatusCode(500, userresponse);
                        }
                    }
                    else
                    {
                        userresponse.data = null;
                        userresponse.status = "Fail";
                        userresponse.message = "User already Present ";
                        return Ok(userresponse);
                    }

                }

            }
            else
            {
                userresponse.data = null;
                userresponse.status = "Fail";
                userresponse.message = "Unable to add, Admin not found";
                return Ok(userresponse);
            }

        }

        [HttpPost]
        [Route("PostEmployees")]
        public IActionResult PostEmployees([FromBody] RequestEmpData user)
        {
            Response userresponse = new Response();

            var userfound = context.Userr.FirstOrDefault(r => r.Email == user.userEmail);
            if (userfound != null)
            {
                var empfound = context.employeesdata.FirstOrDefault(r => r.email == user.EmailId);
                if (empfound == null)
                {
                    try
                    {
                        var empdata = new EmployeesData()
                        {
                            userEmail = user.userEmail,
                            Name = user.Name,
                            MoblieNumber = user.MobileNumber,
                            email = user.EmailId,
                            password = user.Password,
                            jobdiscription = user.jobdiscription,
                            role = 3
                        };
                        context.employeesdata.Add(empdata);
                        context.SaveChanges();
                        userresponse.status = "Success";
                        userresponse.message = "Account Created Successfully ";
                        userresponse.data = empdata;
                        return Ok(userresponse);
                    }
                    catch (Exception ex)
                    {
                        userresponse.status = "fail";
                        userresponse.message = ex.Message;
                        return StatusCode(500, userresponse);
                    }
                }
                else
                {
                    userresponse.status = "Failed";
                    userresponse.message = "Employee Email Already Exists";
                    userresponse.data = "";
                    return Ok(userresponse);
                }
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("PostEmployeestester")]
        public IActionResult PostEmployeestester([FromBody] RequestEmpData user)
        {
            Response userresponse = new Response();

            var userfound = context.Userr.FirstOrDefault(r => r.Email == user.userEmail);
            if (userfound != null)
            {
                var empfound = context.employeesdata.FirstOrDefault(r => r.email == user.EmailId);
                if (empfound == null)
                {
                    try
                    {
                        var empdata = new EmployeesData()
                        {
                            userEmail = user.userEmail,
                            Name = user.Name,
                            MoblieNumber = user.MobileNumber,
                            email = user.EmailId,
                            password = user.Password,
                            jobdiscription = user.jobdiscription,
                            role = 4
                        };
                        context.employeesdata.Add(empdata);
                        context.SaveChanges();
                        userresponse.status = "Success";
                        userresponse.message = "Account Created Successfully ";
                        userresponse.data = empdata;
                        return Ok(userresponse);
                    }
                    catch (Exception ex)
                    {
                        userresponse.status = "fail";
                        userresponse.message = ex.Message;
                        return StatusCode(500, userresponse);
                    }
                }

            }
            return Ok(userresponse);

        }


        [HttpPost]
        [Route("login")]
        public IActionResult login([FromBody] LoginUserReq userinfo)
        {

            Response userresponse = new Response();

            try
            {
                var username = userinfo.EmailId;
                var password = userinfo.Password;
                var userfound = userRepository.authenticate(username);
                if (userfound == null)
                {
                    var EmpUserfound = context.employeesdata.FirstOrDefault(R => R.email == username || R.email.Equals(username));
                    if (EmpUserfound == null)
                    {
                        userresponse.status = "fail";
                        userresponse.message = "user is not found. enter valid user email";
                        return Ok(userresponse);
                    }
                    else
                    {
                        if (userinfo.Password != null)
                        {
                            if (EmpUserfound.password == password)
                            {
                                var checkStatus = getpackageStatus(EmpUserfound.userEmail);
                                if (checkStatus == "Active")
                                {
                                    var user = new UserRegistration()
                                    {
                                        Lab_Name = "LabLife",
                                        Password = EmpUserfound.password,
                                        Phonenumber = EmpUserfound.MoblieNumber,
                                        Email = EmpUserfound.email,

                                    };
                                    ResponseUser userdata = new ResponseUser();
                                    userdata.Email = EmpUserfound.email;
                                    userdata.Role = (int)EmpUserfound.role;
                                    userdata.Name = EmpUserfound.Name;
                                    userdata.PhoneNumber = EmpUserfound.MoblieNumber;
                                    userdata.userEmail = EmpUserfound.userEmail;
                                    userdata.joddiscription = EmpUserfound.jobdiscription;
                                    userdata.TokenNumber = _tokenService.BuildToken(_config["Jwt:Key"].ToString(), _config["Jwt:Issuer"].ToString(), user);
                                    userresponse.status = "success";
                                    userresponse.message = "login successfull";
                                    userresponse.data = userdata;
                                    return Ok(userresponse);
                                }
                                else
                                {
                                    userresponse.status = "Fail";
                                    userresponse.message = "No Package Available, Please Purchase Package";
                                    return Ok(userresponse);
                                }

                            }
                            else
                            {
                                userresponse.status = "Fail";
                                userresponse.message = "password entered are incorrect ";
                                return Ok(userresponse);
                            }
                        }
                        else
                        {
                            userresponse.status = "Fail";
                            userresponse.message = "Enter your Password";
                            return Ok(userresponse);
                        }
                    }

                }
                else
                {
                    if (userinfo.Password != null)
                    {
                        var passwordcheck = context.Userr.FirstOrDefault(R => R.Email == username || R.Email.Equals(username));
                        if (passwordcheck.Password == password)
                        {
                            var checkStatus = getpackageStatus(passwordcheck.Email);
                            if (checkStatus == "Active")
                            {

                                var user = new UserRegistration()
                                {
                                    Lab_Name = userfound.Lab_Name,
                                    Password = userfound.Password,
                                    Phonenumber = userfound.Phonenumber,
                                    Email = userfound.Email,

                                };
                                ResponseUser userdata = new ResponseUser();
                                userdata.Name = passwordcheck.Lab_Name;
                                userdata.Email = passwordcheck.Email;
                                userdata.Password = passwordcheck.Password;
                                userdata.PhoneNumber = passwordcheck.Phonenumber;
                                userdata.GSTNumber = passwordcheck.GST_Number;
                                userdata.LabAddress = passwordcheck.Lab_Address;
                                userdata.Labcode = passwordcheck.Labcode;
                                userdata.Role = (int)passwordcheck.Role;
                                userdata.datafiles = passwordcheck.DataFiles;
                                userdata.TokenNumber = _tokenService.BuildToken(_config["Jwt:Key"].ToString(), _config["Jwt:Issuer"].ToString(), user);
                                userresponse.status = "success";
                                userresponse.message = "login successfull";
                                userresponse.data = userdata;
                                /*+generatedToken;*/
                                return Ok(userresponse);
                            }
                            else
                            {
                                userresponse.status = "Fail";
                                userresponse.message = "No Package Available, Please Purchase Package";
                                return Ok(userresponse);
                            }

                        }
                        else
                        {
                            userresponse.status = "Fail";
                            userresponse.message = "password entered are incorrect ";
                            return Ok(userresponse);
                        }
                    }
                    else
                    {
                        userresponse.status = "Fail";
                        userresponse.message = "Enter your Password";
                        return Ok(userresponse);
                    }
                }
            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
        }

        [HttpPost]
        [Route("verifytoken")]
        public IActionResult verifytoken(EmailRequest EmailRequest)
        {
            string token = EmailRequest.Email;
            bool result = _tokenService.IsTokenValid(_config["Jwt:Key"].ToString(),
                _config["Jwt:Issuer"].ToString(), token);
            Response userresponse = new Response();
            userresponse.data = result;
            userresponse.status = "success";

            return Ok(userresponse);
        }

        [HttpPost]
        [Route("emplogin")]
        public IActionResult emplogin([FromBody] LoginUserReq userinfo)
        {

            Response userresponse = new Response();
            /*    LoginUserResponse userresponse = new LoginUserResponse();*/

            try
            {
                var username = userinfo.EmailId;
                var password = userinfo.Password;
                var userfound = context.employeesdata.FirstOrDefault(R => R.email == username || R.email.Equals(username));
                if (userfound == null)
                {
                    userresponse.status = "fail";
                    userresponse.message = "user is not found. enter valid user email";
                    return Ok(userresponse);
                }
                else
                {
                    if (userinfo.Password != null)
                    {
                        var passwordcheck = context.employeesdata.FirstOrDefault(R => R.email == username || R.email.Equals(username));
                        if (passwordcheck.password == password)
                        {

                            ResponseUser userdata = new ResponseUser();
                            userdata.Email = passwordcheck.email;
                            userdata.Role = (int)passwordcheck.role;
                            userdata.Name = passwordcheck.Name;
                            userdata.PhoneNumber = passwordcheck.MoblieNumber;
                            userdata.userEmail = passwordcheck.userEmail;
                            userdata.joddiscription = passwordcheck.jobdiscription;
                            userresponse.status = "success";
                            userresponse.message = "login successfull";
                            userresponse.data = userdata;
                            return Ok(userresponse);
                        }
                        else
                        {
                            userresponse.status = "Fail";
                            userresponse.message = "password entered are incorrect ";
                            return Ok(userresponse);
                        }
                    }
                    else
                    {
                        userresponse.status = "Fail";
                        userresponse.message = "Enter your Password";
                        return Ok(userresponse);
                    }
                }
            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
        }

        [HttpPost]
        [Route("adddetails")]
        public IActionResult adddetails([FromBody] AddDetails user1)
        {
            Response userresponse = new Response();
            /* var CellNumber = user1.PhoneNumber;*/

            var userfound1 = context.adddata.FirstOrDefault(R => R.Phonenumber == user1.PhoneNumber);

            if (userfound1 != null)
            {

                userresponse.status = "failed";
                userresponse.message = "Patient is Already Registered";

            }
            else if (user1.PhoneNumber == "")
            {
                userresponse.status = "failed";
                userresponse.message = "Please Provide The Phone Number";
            }
            else if (user1.Name == "" || user1.Name == null)
            {
                userresponse.status = "failed";
                userresponse.message = "Please Provide the Required Details";
            }
            else
            {
                try
                {
                    Random random = new Random();
                    const string chars = "0123456789";
                    var data = new string(Enumerable.Repeat(chars, 10)
                    .Select(s => s[random.Next(s.Length)]).ToArray());
                    data = string.Concat("REG", data);
                    var Adduser = new AddData()
                    {
                        Name = user1.Name,
                        Age = user1.Age,
                        gender = user1.gender,
                        Address = user1.Address,
                        Phonenumber = user1.PhoneNumber,
                        AlternativeNumber = user1.AlternativeNumber,
                        PatientEmail = user1.PatientEmail,
                        adharNumber = user1.adharNumber,
                        passPortNumber = user1.passPortNumber,
                        doctorName = user1.doctorName,
                        userEmail = user1.userEmail,
                        Patientregisternumber = data,
                        paymentstatus = "Generate Bill"
                    };

                    context.adddata.Add(Adduser);
                    context.SaveChanges();
                    userresponse.status = "Success";
                    userresponse.message = "Patient Details Added Successfully ";
                    userresponse.data = Adduser;

                }
                catch (Exception ex)
                {
                    userresponse.status = "fail";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }

            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("AddDoctorDetails")]
        public IActionResult AddDoctorDetails([FromBody] AddDocDetailsRequest user1)
        {
            Response userresponse = new Response();
            var userfound1 = context.Userr.FirstOrDefault(R => R.Email == user1.Email);
            if (userfound1 != null)
            {
                try
                {
                    var addDoctor = new DocterDetails()
                    {
                        Email = user1.Email,
                        DoctorName = user1.DoctorName,
                        HospitalName = user1.HospitalName,
                        DocAddress = user1.DocAddress,
                    };
                    context.docterDetails.Add(addDoctor);
                    context.SaveChanges();
                    userresponse.status = "success";
                    userresponse.message = "Doctor Details Successfully Added";
                    userresponse.data = addDoctor;
                }
                catch (Exception ex)
                {
                    userresponse.status = "fail";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }
            }
            return Ok(userresponse);
        }




        [HttpPost]
        [Route("getUserData")]
        public IActionResult getUserData([FromBody] RequestNumber userinfo)
        {
            Response userresponse = new Response();
            try
            {
                var username = userinfo.PhoneNumber;

                var userfound = context.adddata.FirstOrDefault(R => R.Phonenumber == username);
                if (userfound != null)
                {
                    ResponseUser userdata = new ResponseUser();
                    var userrData = new List<ResponseUser>();

                    userdata.Name = userfound.Name;
                    userdata.Email = userfound.PatientEmail;
                    userdata.PhoneNumber = userfound.Phonenumber;
                    userrData.Add(userdata);
                    userresponse.status = "success";
                    userresponse.message = "Data retrieved successfull";
                    userresponse.data = userrData;
                    return Ok(userresponse);

                }
                else
                {
                    userresponse.status = "Fail";
                    userresponse.message = "User Not Found ";
                    return Ok();
                }

            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }

        }
        [HttpPost]
        [Route("Listofpecient")]
        public IActionResult Listofpecient([FromBody] LoginUserReq Users)
        {
            Response userresponse = new Response();

            try
            {
                var userList = new List<AddData>();
                userList = context.adddata.Where(r => r.userEmail == Users.EmailId).ToList();

                if (userList != null)

                {
                    userresponse.status = "Success";
                    userresponse.message = "User list retrieved";
                    userresponse.data = userList;
                    return Ok(userresponse);
                }
            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("PatientData")]
        public IActionResult PatientData([FromBody] RequestPhoneNumber Users)
        {
            Response userresponse = new Response();

            try
            {
                var userList = new List<AddData>();
                userList = context.adddata.Where(r => r.Phonenumber == Users.Phonenumber).ToList();

                if (userList != null)

                {
                    userresponse.status = "Success";
                    userresponse.message = "User list retrieved";
                    userresponse.data = userList;
                    return Ok(userresponse);
                }
            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("getpatientDatawithNumber")]
        public IActionResult getpatientDatawithNumber([FromBody] RequestNumber userinfo)
        {
            Response userresponse = new Response();

            try
            {
                if (userinfo.PhoneNumber != "" && userinfo.Name != "")
                {
                    var usernumber = userinfo.PhoneNumber;
                    var userfound = new List<AddData>();
                    userfound = context.adddata.Where(R => R.Phonenumber == usernumber).ToList();
                    if (userfound != null)
                    {
                        PatientResponce userdata = new PatientResponce();
                        var userrData = new List<PatientResponce>();
                        foreach (var item in userfound)
                        {
                            userdata.Name = item.Name;
                            userdata.PatientEmail = item.PatientEmail;
                            userdata.phonenumber = item.Phonenumber;
                            userdata.Patientregisternumber = item.Patientregisternumber;
                            userdata.Age = (int)item.Age;
                            userdata.paymentstatus = item.paymentstatus;
                            userdata.gender = item.gender;
                            userdata.adharNumber = item.adharNumber;
                            userdata.doctorName = item.doctorName;
                            userrData.Add(userdata);
                            context.SaveChanges();

                        }

                        userresponse.status = "success";
                        userresponse.message = "Data retrieved successfull";
                        userresponse.data = userrData;
                        return Ok(userresponse);


                    }
                }
                else if (userinfo.PhoneNumber != "" && userinfo.Name == "")
                {
                    var usernumber = userinfo.PhoneNumber;
                    var userfound = new List<AddData>();
                    userfound = context.adddata.Where(R => R.Phonenumber == usernumber).ToList();
                    if (userfound != null)
                    {
                        PatientResponce userdata = new PatientResponce();
                        var userrData = new List<PatientResponce>();
                        foreach (var item in userfound)
                        {
                            userdata.Name = item.Name;
                            userdata.PatientEmail = item.PatientEmail;
                            userdata.phonenumber = item.Phonenumber;
                            userdata.Patientregisternumber = item.Patientregisternumber;
                            userdata.Age = (int)item.Age;
                            userdata.paymentstatus = item.paymentstatus;
                            userdata.gender = item.gender;
                            userdata.adharNumber = item.adharNumber;
                            userdata.doctorName = item.doctorName;
                            userrData.Add(userdata);
                            context.SaveChanges();

                        }

                        userresponse.status = "success";
                        userresponse.message = "Data retrieved successfull";
                        userresponse.data = userrData;
                        return Ok(userresponse);


                    }

                }
                else if (userinfo.PhoneNumber == "" && userinfo.Name != "")
                {
                    var username = userinfo.Name;
                    var userfound = new List<AddData>();
                    userfound = context.adddata.Where(R => R.Name == username).ToList();
                    if (userfound != null)
                    {
                        PatientResponce userdata = new PatientResponce();
                        var userrData = new List<PatientResponce>();
                        foreach (var item in userfound)
                        {
                            userdata.Name = item.Name;
                            userdata.PatientEmail = item.PatientEmail;
                            userdata.phonenumber = item.Phonenumber;
                            userdata.Patientregisternumber = item.Patientregisternumber;
                            userdata.Age = (int)item.Age;
                            userdata.paymentstatus = item.paymentstatus;
                            userdata.gender = item.gender;
                            userdata.adharNumber = item.adharNumber;
                            userdata.doctorName = item.doctorName;
                            userrData.Add(userdata);
                            context.SaveChanges();

                        }

                        userresponse.status = "success";
                        userresponse.message = "Data retrieved successfull";
                        userresponse.data = userrData;
                        return Ok(userresponse);
                    }
                }
                else if (userinfo.PhoneNumber == "" && userinfo.Name == "")
                {
                    userresponse.status = "Fail";
                    userresponse.message = "Please Give Some Data";
                    return Ok();
                }


            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpGet]
        [Route("ListOfTest")]
        public IActionResult ListOfTest()
        {
            Response userresponse = new Response();
            try
            {
                var userfound = context.testtable.Where(R => true).ToList();
                if (userfound != null)
                {
                    userresponse.status = "success";
                    userresponse.data = userfound;
                    userresponse.message = "data retrieved";
                    return Ok(userresponse);
                }
            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
            return Ok();
        }
        [HttpGet]
        [Route("ListOfDocDetails")]
        public IActionResult ListOfDocDetails()
        {
            Response userresponse = new Response();
            try
            {
                var userfound = context.docterDetails.Where(R => true).ToList();
                if (userfound != null)
                {
                    userresponse.status = "success";
                    userresponse.data = userfound;
                    userresponse.message = "data retrieved";
                    return Ok(userresponse);
                }
            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
            return Ok();
        }

        [HttpPost]
        [Route("AddTestReport")]
        public IActionResult AddTestReport([FromBody] List<AddPackagelist> user1)
        {
            Response userresponse = new Response();
            try
            {
                var invData = user1.Take(1).FirstOrDefault();
                var invoiceNumber = 00000001;
                var invoiceTableData = context.invoicenumber.Where(r => true).OrderByDescending(x => x.id).FirstOrDefault();
                if (invoiceTableData != null)
                {
                    invoiceNumber = invoiceTableData.invoiceNumber + 1;
                }
                var datedata = DateTime.Now;
                var AddInvoice = new InvoiceNumber()
                {
                    userEmail = invData.userEmail,
                    Name = invData.Name,
                    Date = datedata.ToString(),
                    Age = invData.Age,
                    gender = invData.gender,
                    Phonenumber = invData.Phonenumber,
                    invoiceNumber = invoiceNumber,
                    Patientregisternumber = invData.Patientregisternumber,
                    TotalAmount = invData.TotalAmount

                };
                context.invoicenumber.Add(AddInvoice);
                var reportInvoice = "INV" + invoiceNumber;
                foreach (var report in user1)
                {
                    var AddTest1 = new TestReport()
                    {
                        userEmail = report.userEmail,
                        Name = report.Name,
                        Date = datedata.ToString(),
                        Age = report.Age,
                        gender = report.gender,
                        subtest = report.subtest,
                        reportstatus = report.reportstatus,
                        Phonenumber = report.Phonenumber,
                        InvoiceNumber = reportInvoice,
                        testdiscription = report.testdiscription,
                        result = report.result,
                        Range = report.Range,
                        quantity = report.quantity,
                        doctorName = report.doctorName,
                        amount = report.amount,
                        Patientregisternumber = report.Patientregisternumber

                    };
                    context.testreport.Add(AddTest1);
                    context.SaveChanges();
                    var PDFList = new List<TestReport>();
                    PDFList = context.testreport.Where(r => r.InvoiceNumber == reportInvoice).ToList();

                    userresponse.data = PDFList;
                }
                userresponse.status = "Success";
                userresponse.message = "Test Report Added Successfully ";
                return Ok(userresponse);
            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
        }

        [HttpPost]
        [Route("TesterEdited")]
        public IActionResult TesterEdited([FromBody] List<TestReportRequest> user1)
        {
            Response userresponse = new Response();
            foreach (var testerreport in user1)
            {
                var testfound = context.testreport.FirstOrDefault(r => r.testdiscription == testerreport.testdiscription && r.InvoiceNumber == testerreport.InvoiceNumber);
                if (testfound != null)
                {
                    try
                    {
                        if (testerreport.result != null)
                        {
                            testfound.InvoiceNumber = testerreport.InvoiceNumber;
                            testfound.testdiscription = testerreport.testdiscription;
                            testfound.result = testerreport.result;
                            testfound.reportstatus = testerreport.reportstatus;
                            context.testreport.Update(testfound);
                            context.SaveChanges();
                        }

                    }
                    catch (Exception ex)
                    {
                        userresponse.status = "fail";
                        userresponse.message = ex.Message;
                        return StatusCode(500, userresponse);
                    }
                }
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("Rejectlist")]
        public IActionResult Rejectlist([FromBody] List<TestReportRequest> user1)
        {
            Response userresponse = new Response();
            foreach (var testerreport in user1)
            {
                var testfound = context.testreport.FirstOrDefault(r => r.testdiscription == testerreport.testdiscription && r.InvoiceNumber == testerreport.InvoiceNumber);
                if (testfound != null)
                {
                    try
                    {

                        testfound.InvoiceNumber = testerreport.InvoiceNumber;
                        testfound.testdiscription = null;
                        testfound.result = null;
                        testfound.Range = null;
                        testfound.reportstatus = testerreport.reportstatus;
                        context.testreport.Update(testfound);
                        context.SaveChanges();

                    }
                    catch (Exception ex)
                    {
                        userresponse.status = "fail";
                        userresponse.message = ex.Message;
                        return StatusCode(500, userresponse);
                    }
                }
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("ListOfPendingReport")]
        public IActionResult ListOfPatientReport([FromBody] PatientEmailRequest userinfo)
        {
            Response userresponse = new Response();
            try
            {
                var userList = new List<TestReport>();
                userList = context.testreport.Where(r => r.userEmail == userinfo.userEmail && r.reportstatus == "In-Process").ToList();
                if (userList != null)
                {
                    userresponse.status = "Success";
                    userresponse.message = "User list retrieved";
                    userresponse.data = userList;
                    return Ok(userresponse);
                }

            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("ListOfPendingBill")]
        public IActionResult ListOfPendingBill([FromBody] PatientEmailRequest userinfo)
        {
            Response userresponse = new Response();
            try
            {
                var userList = new List<TestReport>();
                userList = context.testreport.Where(r => r.userEmail == userinfo.userEmail ).ToList();
                if (userList != null)
                {
                    userresponse.status = "Success";
                    userresponse.message = "User list retrieved";
                    userresponse.data = userList;
                    return Ok(userresponse);
                }

            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("listofallpatientreport")]
        public IActionResult listofallpatientreport([FromBody] PatientEmailRequest userinfo)
        {
            Response userresponse = new Response();
            try
            {
                var userList = new List<TestReport>();
                userList = context.testreport.Where(r => r.userEmail == userinfo.userEmail).ToList();
                if (userList != null)
                {
                    userresponse.status = "Success";
                    userresponse.message = "User list retrieved";
                    userresponse.data = userList;
                    return Ok(userresponse);
                }

            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("ListOfPendingApproval")]
        public IActionResult ListOfPendingApproval([FromBody] PatientEmailRequest userinfo)
        {
            Response userresponse = new Response();
            try
            {
                var userList = new List<TestReport>();
                userList = context.testreport.Where(r => r.userEmail == userinfo.userEmail && r.reportstatus == "Pending").ToList();
                if (userList != null)
                {
                    userresponse.status = "Success";
                    userresponse.message = "User list retrieved";
                    userresponse.data = userList;
                    return Ok(userresponse);
                }

            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("AddPatientBill")]
        public IActionResult AddPatientBill([FromBody] BillPDF bill)

        {
            Response userresponse = new Response();
            try
            {
                var newbillreport = new AddtestreportXL();
                {
                    newbillreport.userEmail = bill.userEmail;
                    newbillreport.PhoneNumber = bill.PhoneNumber;
                    newbillreport.PatientName = bill.PatientName;
                    newbillreport.BillDate = bill.BillDate;
                    newbillreport.Billtype = bill.BillType;
                    newbillreport.InvoiceNumber = bill.InvoiceNumber;
                    newbillreport.DataFiles = bill.DataFiles;
                    context.addtestreportxl.Add(newbillreport);
                    context.SaveChanges();
                }
                userresponse.data = newbillreport;
                userresponse.status = "success";
                userresponse.message = "Patient bill added successfully ";





                return Ok(userresponse);
            }
            catch (Exception ex)
            {
                userresponse.status = "Failed";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
        }
        [HttpPost]
        [Route("AddPatientBillwithoutheader")]
        public IActionResult AddPatientBillwithoutheader([FromBody] BillPDF bill)

        {
            Response userresponse = new Response();
            try
            {
                var newbillreport = new AddtestreportXL();
                {
                    newbillreport.userEmail = bill.userEmail;
                    newbillreport.PhoneNumber = bill.PhoneNumber;
                    newbillreport.PatientName = bill.PatientName;
                    newbillreport.BillDate = bill.BillDate;
                    newbillreport.Billtype = bill.BillType;
                    newbillreport.InvoiceNumber = bill.InvoiceNumber;
                    newbillreport.DataFiles = bill.DataFiles;
                    context.addtestreportxl.Add(newbillreport);
                    context.SaveChanges();
                }
                userresponse.data = newbillreport;
                userresponse.status = "success";
                userresponse.message = "Patient bill added successfully ";





                return Ok(userresponse);
            }
            catch (Exception ex)
            {
                userresponse.status = "Failed";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
        }
        [HttpGet]
        [Route("BillData/{userEmail}")]
        public IActionResult BillData(string userEmail)
        {
            Response userresponse = new Response();

            try
            {
                /* var RecordList = new List<AddtestreportXL>();*/
                var RecordList = context.addtestreportxl.Where(r => r.userEmail == userEmail && r.Billtype == "Bill_With_header").ToList();
                if (RecordList != null)

                {
                    userresponse.status = "Success";
                    userresponse.message = "data retrieved";
                    userresponse.data = RecordList;
                    return Ok(userresponse);
                }

            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpGet]
        [Route("BillDatawithout/{userEmail}")]
        public IActionResult BillDatawithout(string userEmail)

        {
            Response userresponse = new Response();

            try
            {
                var RecordList = new List<AddtestreportXL>();
                RecordList = context.addtestreportxl.Where(r => r.userEmail == userEmail).ToList();
                if (RecordList != null)

                {
                    userresponse.status = "Success";
                    userresponse.message = "data retrieved";
                    userresponse.data = RecordList;
                    return Ok(userresponse);
                }

            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpGet]
        [Route("BillPDF/{InvoiceNumber}")]
        public IActionResult BillPDF(string InvoiceNumber)
        {
            Response userresponse = new Response();
            try
            {
                var PDFList = new List<AddtestreportXL>();
                PDFList = context.addtestreportxl.Where(r => r.InvoiceNumber == InvoiceNumber && r.Billtype == "Bill_With_header").ToList();
                if (PDFList != null)
                {
                    userresponse.status = "Success";
                    userresponse.message = "data retrieved";
                    userresponse.data = PDFList;
                    return Ok(userresponse);
                }
            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpGet]
        [Route("getpdfwithoutheader/{InvoiceNumber}")]
        public IActionResult getpdfwithoutheader(string InvoiceNumber)
        {
            Response userresponse = new Response();
            try
            {
                var PDFList = new List<AddtestreportXL>();
                PDFList = context.addtestreportxl.Where(r => r.InvoiceNumber == InvoiceNumber && r.Billtype == "Bill_Without_Header").ToList();
                if (PDFList != null)
                {
                    userresponse.status = "Success";
                    userresponse.message = "data retrieved";
                    userresponse.data = PDFList;
                    return Ok(userresponse);
                }
            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpGet]
        [Route("Getreport/{InvoiceNumber}")]
        public IActionResult Getreport(string InvoiceNumber)
        {
            Response userresponse = new Response();
            try
            {
                var PDFList = new List<TestReport>();
                PDFList = context.testreport.Where(r => r.InvoiceNumber == InvoiceNumber).ToList();
                if (PDFList != null)
                {
                    userresponse.status = "Success";
                    userresponse.message = "data retrieved";
                    userresponse.data = PDFList;
                    return Ok(userresponse);
                }
            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }
        [HttpGet]
        [Route("BillwithheaderPDF/{InvoiceNumber}")]
        public IActionResult BillwithheaderPDF(string InvoiceNumber)
        {
            Response userresponse = new Response();
            try
            {
                /*var PDFList = new List<PatientReport>();*/
                var PDFList = context.addtestreportxl.FirstOrDefault(r => r.InvoiceNumber == InvoiceNumber);
                if (PDFList != null)

                {
                    userresponse.status = "Success";
                    userresponse.message = "data retrieved";
                    userresponse.data = PDFList;
                    return Ok(userresponse);
                }
            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpGet]
        [Route("reportPDF/{InvoiceNumber}")]
        public IActionResult reportPDF(string InvoiceNumber)
        {
            Response userresponse = new Response();
            try
            {
                var PDFList = new List<TestReport>();
                PDFList = context.testreport.Where(r => r.InvoiceNumber == InvoiceNumber).ToList();
                if (PDFList != null)

                {
                    userresponse.status = "Success";
                    userresponse.message = "data retrieved";
                    userresponse.data = PDFList;
                    return Ok(userresponse);
                }
            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }


        [HttpGet]
        [Route("Edittestreport/{InvoiceNumber}")]
        public IActionResult Edittestreport(string InvoiceNumber)
        {
            Response userresponse = new Response();
            try
            {
                /*var PDFList = new List<PatientReport>();*/
                var PDFList = context.testreport.Where(r => r.InvoiceNumber == InvoiceNumber).ToList();
                if (PDFList != null)

                {
                    userresponse.status = "Success";
                    userresponse.message = "data retrieved";
                    userresponse.data = PDFList;
                    return Ok(userresponse);
                }
            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }
        [HttpGet]
        [Route("getpatientstatus/{patientregisternumber}")]
        public IActionResult getpatientstatus(string patientregisternumber)
        {
            Response userresponse = new Response();
            try
            {
                /*var PDFList = new List<PatientReport>();*/
                var PDFList = context.testreport.Where(r => r.Patientregisternumber == patientregisternumber).ToList();
                if (PDFList != null)

                {
                    userresponse.status = "Success";
                    userresponse.message = "data retrieved";
                    userresponse.data = PDFList;
                    return Ok(userresponse);
                }
            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpGet]
        [Route("ListOfPackages")]
        public IActionResult ListOfPackages()
        {
            Response userresponse = new Response();
            try
            {
                var userfound = context.PackageTable.Where(R => true).ToList();
                if (userfound != null)
                {
                    userresponse.status = "success";
                    userresponse.data = userfound;
                    userresponse.message = "data retrieved";
                    Console.WriteLine("show the output");
                    Console.WriteLine("this is output" + userresponse.data);
                    return Ok(userresponse);
                }
            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
            return Ok();
        }

        [HttpPost]
        [Route("Addpatientpaymentstatus")]
        public IActionResult Addpatientpaymentstatus([FromBody] PaymentstatusRequest billstatus)
        {
            Response userresponse = new Response();
            try
            {
                var patientfound = context.adddata.FirstOrDefault(r => r.Phonenumber == billstatus.PhoneNumber);
                if (patientfound != null)
                {
                    patientfound.paymentstatus = billstatus.Billstatus;
                    context.adddata.Update(patientfound);
                    context.SaveChanges();

                }
                userresponse.status = "success";
                userresponse.message = "Patient Bill status is Updated";
                userresponse.data = patientfound;
                return Ok(userresponse);
            }
            catch (Exception ex)
            {
                userresponse.status = "Failed";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
        }

        [HttpPost]
        [Route("Addreportdata")]
        public IActionResult Addreportdata([FromBody] PaymentstatusRequest billstatus)
        {
            Response userresponse = new Response();
            try
            {
                var patientfound = context.patientreport.FirstOrDefault(r => r.PhoneNumber == billstatus.PhoneNumber);
                if (patientfound != null)
                {
                    patientfound.ReportStatus = billstatus.Billstatus;
                    context.patientreport.Update(patientfound);
                    context.SaveChanges();

                }
                userresponse.status = "success";
                userresponse.message = "Patient Bill status is Updated";
                userresponse.data = patientfound;
                return Ok(userresponse);
            }
            catch (Exception ex)
            {
                userresponse.status = "Failed";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
        }
        [HttpGet]
        [Route("getPackages")]
        public IActionResult getPackages()
        {
            Response userresponse = new Response();
            try
            {
                var userfound = context.PackageTable.Where(R => true).ToList();
                var listPackage = new List<PackageTable>();
                List<PackageTable> packageData = new List<PackageTable>();

                var prevPackage = "";
                packageData.AddRange(listPackage);
                foreach (var package in userfound)
                {
                    prevPackage = package.PackageName;
                    var count = 0;
                    if (listPackage.Count > 0)
                    {
                        if (prevPackage == listPackage[0].PackageName)
                        {
                            foreach (var listdata in listPackage)
                            {
                                count++;
                                if (listdata.testcode != package.testcode)
                                {
                                    if (count == listPackage.Count)
                                    {
                                        listPackage.Add(package);
                                        break;
                                    }
                                }
                            }
                        }
                    }
                    else
                    {

                        listPackage.Clear();
                        listPackage.Add(package);
                    }

                }
                if (userfound != null)
                {
                    userresponse.status = "success";
                    userresponse.data = packageData;
                    userresponse.message = "data retrieved";
                    return Ok(userresponse);
                }
            }
            catch (Exception ex)
            {
                userresponse.status = "fail";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
            return Ok();
        }
        [HttpGet]
        [Route("getemployeeData/{userEmail}")]
        public IActionResult getemployeeData(string userEmail)

        {
            Response userresponse = new Response();

            try
            {
                var RecordList = new List<EmployeesData>();
                RecordList = context.employeesdata.Where(r => r.userEmail == userEmail).ToList();
                if (RecordList != null)

                {
                    userresponse.status = "Success";
                    userresponse.message = "data retrieved";
                    userresponse.data = RecordList;
                    return Ok(userresponse);
                }

            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return StatusCode(500, userresponse);
            }
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("PasswordReset")]
        public IActionResult PasswordReset([FromBody] PatientEmailRequest userinfo)
        {
            Response userresponse = new Response();
            var tempUserData = context.Userr.FirstOrDefault(r => r.Email == userinfo.userEmail);
            if (tempUserData != null)
            {
                Random random = new Random();
                const string chars = "0123456789";
                var data = new string(Enumerable.Repeat(chars, 8).Select(s => s[random.Next(s.Length)]).ToArray());
                tempUserData.Password = data;
                tempUserData.Role = 5;
                context.Userr.Update(tempUserData);
                context.SaveChanges();
                var reqotp = new requestMail()
                {
                    toEmail = userinfo.userEmail,
                    password = data,
                };

                this.mailService.requestOtp(reqotp);
                userresponse.status = "success";
                userresponse.message = "Temporary Password has sent successfully";
                userresponse.data = null;
                return Ok(userresponse);

            }
            else
            {
                userresponse.status = "fail";
                userresponse.message = "Please Provide correct Email Address";
                userresponse.data = null;
                return Ok(userresponse);
            }
        }

        [HttpPost]
        [Route("confirmpassword")]
        public IActionResult confirmpassword([FromBody] ConfirmPasswordRequest revdata)
        {
            Response userresponse = new Response();
            try
            {
                var userfound = context.Userr.FirstOrDefault(r => r.Email == revdata.userEmail);
                if (userfound != null)
                {
                    userfound.Email = revdata.userEmail;
                    userfound.Password = revdata.confirmpassword;
                    userfound.Role = 1;
                    context.Userr.Update(userfound);
                    context.SaveChanges();

                }
                userresponse.status = "success";
                userresponse.message = "Password has Updated";
                userresponse.data = userfound;
                return Ok(userresponse);
            }
            catch (Exception ex)
            {
                userresponse.status = "Failed";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }
        }
        [HttpPost]
        [Route("Gettestlist")]
        public IActionResult Gettestlist([FromBody] testlistRequest testlist)
        {
            Response userresponse = new Response();
            var testresponselist = new List<SubTestGroup>();
            var listfound = context.testertestreport.Where(a => a.InvoiceNumber == testlist.InvoiceNumber).ToList();
            if (listfound.Count <= 0)
            {
                var testfound = context.testreport.Where(r => r.InvoiceNumber == testlist.InvoiceNumber).ToList();
                if (testfound != null)
                {
                    try
                    {

                        foreach (var item in testfound)
                        {
                            var tesresList = new SubTestGroup();
                            tesresList.subTestGroup = context.TestParameters.Where(a => a.TestName == item.testdiscription).ToList();
                            foreach (var subtest in tesresList.subTestGroup)
                            {
                                var newtestdataresult = new Tester_test_Report();
                                {
                                    newtestdataresult.InvoiceNumber = testlist.InvoiceNumber;
                                    newtestdataresult.testdiscription = item.testdiscription;
                                    newtestdataresult.testcode = subtest.TestCode;
                                    newtestdataresult.Name = subtest.Name;
                                    newtestdataresult.unit = subtest.unit;
                                    newtestdataresult.result = "";
                                    newtestdataresult.Range = subtest.Range;
                                    newtestdataresult.editeddate = DateTime.Now.ToString();
                                    newtestdataresult.reportstatus = "Pending";
                                    newtestdataresult.TestParamName = subtest.TestParamName;
                                }
                                context.testertestreport.Add(newtestdataresult);
                                context.SaveChanges();
                            }
                        }
                        var responseData = Getreportdata(testlist.InvoiceNumber);

                        userresponse.status = "success";
                        userresponse.message = "Data received successfully";
                        userresponse.data = responseData;
                        return Ok(userresponse);
                    }
                    catch (Exception ex)
                    {
                        userresponse.status = "Failed";
                        userresponse.message = ex.Message;
                        return StatusCode(500, userresponse);
                    }
                }

            }
            else
            {
                try
                {
                    var responseData = Getreportdata(testlist.InvoiceNumber);
                    userresponse.status = "success";
                    userresponse.message = "Data received successfully";
                    userresponse.data = responseData;
                    return Ok(userresponse);
                }
                catch (Exception ex)
                {
                    userresponse.status = "Failed";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }

            }
            userresponse.status = "Failed";
            userresponse.message = "no data";
            return StatusCode(500, userresponse);
        }

        public List<SubTestGroup> Getreportdata(String invoiceNumber)
        {
            var testresponselist = new List<SubTestGroup>();
            try
            {
                var testfound = context.testreport.Where(r => r.InvoiceNumber == invoiceNumber && r.reportstatus == "In-Process").ToList();

                foreach (var newitem in testfound)
                {
                    var testresList = new SubTestGroup();
                    testresList.TestName = newitem.testdiscription;
                    testresList.subTestGroup1 = context.testertestreport.Where(k => k.testdiscription == newitem.testdiscription && k.InvoiceNumber == newitem.InvoiceNumber).ToList();
                    testresponselist.Add(testresList);
                }
;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return testresponselist;
        }

        [HttpPost]
        [Route("testeredit")]
        public IActionResult testeredit([FromBody] List<testerresultRequest> testlist)
        {
            Response userresponse = new Response();
            var changestatus = true;
            if (testlist.Count > 0)
            {
                var checkIsPresent = context.testertestreport.Where(r => r.InvoiceNumber == testlist[0].InvoiceNumber).FirstOrDefault();
                //if (checkIsPresent != null)
                //{
                foreach (var item in testlist)
                {
                    var testfound = context.testertestreport.Where(r => r.InvoiceNumber == item.InvoiceNumber && r.Name == item.subtest).FirstOrDefault();
                    if (testfound != null)
                    {
                        try
                        {
                            if (testfound.result != null)
                            {
                                changestatus = false;
                            }
                            else if (testfound.result == null)
                            {
                                changestatus = true;
                            }
                            testfound.result = item.result;
                            context.testertestreport.Update(testfound);
                            context.SaveChanges();

                        }
                        catch (Exception ex)
                        {
                            userresponse.status = "Failed";
                            userresponse.message = ex.Message;
                            return StatusCode(500, userresponse);
                        }

                    }
                    else
                    {
                        return StatusCode(500, userresponse);
                    }
                }
                foreach (var item in testlist)
                {
                    var reportfound = context.testreport.Where(r => r.InvoiceNumber == item.InvoiceNumber && r.testdiscription == item.testdiscription).FirstOrDefault();
                    if (changestatus == false)
                    {
                        reportfound.reportstatus = item.reportstatus;
                        reportfound.sampletype = item.sampletype;
                        context.testreport.Update(reportfound);
                        context.SaveChanges();
                    }
                }
            }
            userresponse.status = "success";
            userresponse.message = "Data received successfully";
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("ApprovedStatus")]
        public IActionResult ApprovedStatus([FromBody] List<ApprovedResultRequest> testlist)
        {
            Response userresponse = new Response();
            foreach (var item in testlist)
            {
                var statusfound = context.testertestreport.Where(r => r.InvoiceNumber == item.InvoiceNumber && r.Name == item.subtest).FirstOrDefault();
                if (statusfound != null)
                {
                    try
                    {
                  
                        statusfound.reportstatus = "Approved";
                        statusfound.TestReportDate = DateTime.Now.ToString();
                        context.testertestreport.Update(statusfound);
                        context.SaveChanges();
                        var changestatus = context.testreport.FirstOrDefault(a => a.InvoiceNumber == item.InvoiceNumber && a.testdiscription == item.testdiscription);
                        if (changestatus != null)
                        {
                            changestatus.result = item.result;
                            changestatus.reportstatus = item.reportstatus;
                            context.testreport.Update(changestatus);
                            context.SaveChanges();
                        }
                    }
                    catch (Exception ex)
                    {
                        userresponse.status = "Failed";
                        userresponse.message = ex.Message;
                        return StatusCode(500, userresponse);
                    }
                }
                else
                {
                    return StatusCode(500, userresponse);
                }
            }
            userresponse.status = "success";
            userresponse.message = "Approved successfully";
            return Ok(userresponse);
        }

        [HttpPost]
        [Route("Getreportdata")]
        public IActionResult Getreportdata([FromBody] testlistRequest testlist)
        {
            Response userresponse = new Response();
            var testresponselist = new List<SubTestGroup>();
            var testreportfound = context.testertestreport.Where(a => a.InvoiceNumber == testlist.InvoiceNumber).ToList();
            if (testreportfound.Count > 0)
            {
                var testfound = context.testreport.Where(r => r.InvoiceNumber == testlist.InvoiceNumber).ToList();
                if (testfound != null)
                {
                    try
                    {
                        foreach (var item in testfound)
                        {
                            var tesresList = new SubTestGroup();
                            tesresList.subTestGroup1 = context.testertestreport.Where(a => a.testdiscription == item.testdiscription && a.InvoiceNumber == item.InvoiceNumber).ToList();
                            testresponselist.Add(tesresList);
                        }

                        userresponse.status = "success";
                        userresponse.message = "Data received successfully";
                        userresponse.data = testresponselist;
                        return Ok(userresponse);
                    }
                    catch (Exception ex)
                    {
                        userresponse.status = "Failed";
                        userresponse.message = ex.Message;
                        return StatusCode(500, userresponse);
                    }
                }
            }
            userresponse.status = "Failed";
            userresponse.message = "no data";
            return StatusCode(500, userresponse);

        }

        [HttpPost]
        [Route("RejectingReport")]
        public IActionResult RejectingReport([FromBody] List<RejectReportRequest> testdata)
        {
            Response userresponse = new Response();
            foreach (var item in testdata)
            {
                var testlist = context.testertestreport.FirstOrDefault(a => a.InvoiceNumber == item.InvoiceNumber && a.Name == item.subtest);
                if (testlist != null)
                {
                    try
                    {
                        testlist.result = "";
                        testlist.reportstatus = "In-Process";
                        context.testertestreport.Update(testlist);
                        context.SaveChanges();
                    }
                    catch (Exception ex)
                    {
                        userresponse.status = "Failed";
                        userresponse.message = ex.Message;
                        return StatusCode(500, userresponse);
                    }
                }
            }
            foreach (var itemdata in testdata)
            {
                var reportlist = context.testreport.FirstOrDefault(x => x.InvoiceNumber == itemdata.InvoiceNumber && x.testdiscription == itemdata.testdiscription);
                if (reportlist != null)
                {
                    try
                    {
                        reportlist.result = "";
                        reportlist.reportstatus = "In-Process";
                        context.testreport.Update(reportlist);
                        context.SaveChanges();
                    }
                    catch (Exception ex)
                    {
                        userresponse.status = "Failed";
                        userresponse.message = ex.Message;
                        return StatusCode(500, userresponse);
                    }
                }
            }
            userresponse.status = "success";
            userresponse.message = "Reject successfully";
            return Ok(userresponse);

        }


        [HttpPost]
        [Route("getApprovalPending")]
        public IActionResult getApprovalPending([FromBody] testlistRequest testlist)
        {
            Response userresponse = new Response();
            var testresponselist = new List<SubTestGroup>();

            var testfound = context.testreport.Where(r => r.InvoiceNumber == testlist.InvoiceNumber && r.reportstatus == "Pending").ToList();
            if (testfound != null)
            {
                try
                {

                    foreach (var newitem in testfound)
                    {
                        var testresList = new SubTestGroup();
                        testresList.TestName = newitem.testdiscription;
                        testresList.subTestGroup1 = context.testertestreport.Where(k => k.testdiscription == newitem.testdiscription && k.InvoiceNumber == newitem.InvoiceNumber).ToList();
                        testresponselist.Add(testresList);
                    }


                    userresponse.status = "success";
                    userresponse.message = "Data received successfully";
                    userresponse.data = testresponselist;
                    return Ok(userresponse);
                }
                catch (Exception ex)
                {
                    userresponse.status = "Failed";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }
            }
            else
            {

                userresponse.status = "Failed";
                userresponse.message = "no data";
                return StatusCode(500, userresponse);
            }


        }

        public string getpackageStatus(String email)
        {
            var getPackage = context.SubscriptionPackage.FirstOrDefault(r => r.UserEmail == email || r.UserEmail.Equals(email) && r.status == "Active");
            string packageStatus = "InActive";
            if (getPackage != null)
            {
                packageStatus = "Active";
            }
            return packageStatus;
        }

        [HttpPost]
        [Route("addcontactus")]
        public IActionResult addcontactus([FromBody] contactusRequest getlist)
        {
            Response userresponse = new Response();
            try
            {
                var getcontactus = new contactus();
                {
                    getcontactus.name = getlist.name;
                    getcontactus.emailaddress = getlist.emailaddress;
                    getcontactus.contactnumber = getlist.contactnumber;
                    getcontactus.organisation = getlist.organisation;
                    getcontactus.yourmessage = getlist.yourmessage;
                }
                context.contactus.Add(getcontactus);
                context.SaveChanges();
                var reqmsg = new Requestmessage()
                {
                    name = getlist.name,
                    emailaddress = getlist.emailaddress,
                };

                this.mailService.requestmsg(reqmsg);
                userresponse.status = "success";
                userresponse.message = "your request sent successfully";
                userresponse.data = getcontactus;
                return Ok(userresponse);
            }
            catch(Exception ex)
            {
                userresponse.status = "Failed";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }

        }

        [HttpPost]
        [Route("sendresponse")]
        public IActionResult sendresponse([FromBody] demoRequest getlist)
        {
            Response userresponse = new Response();
            try
            {
                var reqmsg = new Requestmessage()
                {
                    name = getlist.name,
                    emailaddress = getlist.emailaddress,
                };

                this.mailService.requestmsg(reqmsg);
                userresponse.status = "success";
                userresponse.message = "Temporary Password has sent successfully";
                userresponse.data = null;
                return Ok(userresponse);
            }
            catch (Exception ex)
            {
                userresponse.status = "Failed";
                userresponse.message = ex.Message;
                return StatusCode(500, userresponse);
            }    
        }


        [HttpGet]
        [Route("getcontactlist/{adminemail}")]
        public IActionResult getcontactlist(string adminemail)
        {
            Response userresponse = new Response();
                var admilmail = context.Userr.Where(r => r.AdminEmail == adminemail).ToList();
                if (admilmail != null)

                {
                    try
                    {
                        var PDFList = new List<contactus>();
                        PDFList = context.contactus.Where(R => true).ToList();
                        userresponse.status = "Success";
                        userresponse.message = "data retrieved";
                        userresponse.data = PDFList;
                        return Ok(userresponse);
                    }
                    catch (Exception e)
                    {
                        userresponse.status = "fail";
                        userresponse.message = e.Message;
                        return StatusCode(500, userresponse);
                    }

                }
            return Ok(userresponse);
        }

    }
}

