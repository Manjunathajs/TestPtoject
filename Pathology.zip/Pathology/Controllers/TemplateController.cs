﻿using DocumentFormat.OpenXml.Office2013.Excel;
using Medical_Lab.Model.Data_Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Threading.Tasks;
using System;
using Medical_Lab.Model.Request_Model;
using Medical_Lab.Model.Responce_Model;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using System.Drawing.Printing;
using Word = Microsoft.Office.Interop.Word;
using DocumentFormat.OpenXml.Vml.Spreadsheet;
using System.Reflection;
using EllipticCurve.Utils;
using WordToPDF;
using System.Drawing;
using A = DocumentFormat.OpenXml.Drawing;
using DW = DocumentFormat.OpenXml.Drawing.Wordprocessing;
using PIC = DocumentFormat.OpenXml.Drawing.Pictures;
using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Xml;
using System.Drawing.Imaging;

namespace Medical_Lab.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TemplateController : ControllerBase
    {

        private DataBaseContext context;

        public TemplateController(DataBaseContext _context)
        {
            this.context = _context;
        }

        [HttpPost]
        [Route("AddTemplate")]
        public async Task<IActionResult> AddnewAdsAsync([FromForm] TemplateRequest TemplateData)
        {
            Response userresponse = new Response();
            /* MyUser userresponse = new MyUser();*/
            if (TemplateData.TestName == null || TemplateData.TestName == "")
            {
                userresponse.data = null;
                userresponse.status = "fail";
                userresponse.message = "TestName not found unable to add  ";
            }
            else if (TemplateData.Template == null)
            {
                userresponse.data = null;
                userresponse.status = "fail";
                userresponse.message = "Template not found unable to add  ";
            }
            else
            {
                try
                {
                    IFormFile myfile = TemplateData.Template;
                    var TemplateRow = new TemplateFiles();
                    using (MemoryStream ms = new MemoryStream())

                    {

                        // copy the file to memory stream 
                        await myfile.CopyToAsync(ms);

                        // set the byte array 
                        TemplateRow.Template = ms.ToArray();
                        TemplateRow.Access = TemplateData.Access;
                        TemplateRow.TestName = TemplateData.TestName;
                        TemplateRow.TestCode = TemplateData.TestCode;
                    }


                    context.TemplateFiles.Add(TemplateRow);
                    context.SaveChanges();
                    userresponse.data = "";
                    userresponse.status = "success";
                    userresponse.message = "Advertisement added successfully ";

                    return Ok(userresponse);
                }

                catch (Exception ex)
                {
                    userresponse.status = "Failed";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }
            }



            return Ok(userresponse);
        }

        [HttpPost]
        [Route("updateTemplate")]
        public async Task<IActionResult> updateTemplate([FromForm] updateTemplateRequest TemplateData)
        {
            Response userresponse = new Response();
            /* MyUser userresponse = new MyUser();*/
            if (TemplateData.id == null)
            {
                userresponse.data = null;
                userresponse.status = "fail";
                userresponse.message = "Test id not found unable to add  ";
            }
            else if (TemplateData.Template == null)
            {
                userresponse.data = null;
                userresponse.status = "fail";
                userresponse.message = "Template not found unable to add  ";
            }
            else
            {
                try
                {
                    IFormFile myfile = TemplateData.Template;
                    var TemplateRow = context.TemplateFiles.FirstOrDefault(r => r.Id == TemplateData.id);
                    using (MemoryStream ms = new MemoryStream())

                    {

                        // copy the file to memory stream 
                        await myfile.CopyToAsync(ms);

                        // set the byte array 
                        TemplateRow.Template = ms.ToArray();
                    }


                    context.TemplateFiles.Update(TemplateRow);
                    context.SaveChanges();
                    userresponse.data = "";
                    userresponse.status = "success";
                    userresponse.message = "emplate updated successfully ";

                    return Ok(userresponse);
                }

                catch (Exception ex)
                {
                    userresponse.status = "Failed";
                    userresponse.message = ex.Message;
                    return StatusCode(500, userresponse);
                }
            }



            return Ok(userresponse);
        }

        //TO SHOW THE ADS AVAILABILITY 
        [HttpGet]
        [Route("GetReport/{invoice}")]
        public FileResult GetReport(string invoice)
        {
            Response userresponse = new Response();
            var currentPath = Directory.GetCurrentDirectory();
            string path = currentPath + "\\Temp\\" + invoice;
            var directoryPath = currentPath + "\\Temp\\" + invoice;
            string invoicePath = "";
            if (Directory.Exists(path))
            {
                Random random = new Random();
                const string chars = "0123456789";
                var radomnum= new string(Enumerable.Repeat(chars, 3).Select(s => s[random.Next(s.Length)]).ToArray());
                directoryPath= currentPath + "\\Temp\\" + invoice+ radomnum;
                invoicePath = radomnum;
            }
                var data = context.testreport.Where(r => r.InvoiceNumber==invoice).ToList();
            System.IO.Directory.CreateDirectory(directoryPath);
            var i = 0;
            WordprocessingDocument mergeWordprocessingDocument = WordprocessingDocument.Create(directoryPath + "\\" + invoice + 1 + ".docx", WordprocessingDocumentType.Document);
            try
            {
                var firstTestReport = context.testreport.Where(r => r.InvoiceNumber == invoice && r.reportstatus=="Approved").FirstOrDefault();
                var totaltests = context.testreport.Where(r => r.InvoiceNumber == invoice && r.reportstatus == "Approved").ToList();
                List <TemplateFiles> TemplateData = new List<TemplateFiles>();
                foreach (var test in totaltests)
                {
                    TemplateData.Add(context.TemplateFiles.Where(r => r.TestName== test.testdiscription).FirstOrDefault());
                }                   
               
                var testReportData = context.testertestreport.Where(r => r.InvoiceNumber == invoice).ToList();
            
                var patientData = context.adddata.FirstOrDefault(r => r.Patientregisternumber == firstTestReport.Patientregisternumber);
                var userrdata = context.Userr.FirstOrDefault(r => r.Email == patientData.userEmail);
               
                
                var stream = new MemoryStream();         
                MainDocumentPart mainPart = mergeWordprocessingDocument.AddMainDocumentPart();
                mainPart.Document = new Document(new Body());
                var lastTemplateData = TemplateData.Last();
                    foreach (var template in TemplateData)
                    {
                        AlternativeFormatImportPart chunk = mainPart.AddAlternativeFormatImportPart(AlternativeFormatImportPartType.WordprocessingML);
                        string altChunkId = mainPart.GetIdOfPart(chunk);
                        byte[] wordData = getWordDocandcreate(invoice, template.Template, directoryPath,template.TestName);
                    if (wordData.Length > 1)
                    {
                        var tempstream = new MemoryStream(wordData);
                        chunk.FeedData(tempstream);
                        AltChunk altChunk = new AltChunk { Id = altChunkId };
                        mainPart.Document.Body.AppendChild(altChunk);
              
                        if (template.Equals(lastTemplateData))
                        {
                            // do nothing
                        }
                        else{
                            Paragraph pagebreak = new Paragraph();
                            Run pagebreakRun = new Run();
                            Break pageBreakBr = new Break() { Type = BreakValues.Page };
                            pagebreak.Append(pagebreakRun);
                            pagebreak.Append(pageBreakBr);
                            mainPart.Document.Body.AppendChild(pagebreak);
                        }

                        mainPart.Document.Save();
                    }
                    }


                //IFormFile myfile = new FormFile(stream, 0, TemplateData.Template.Length, "name", "fileName.docx");
                mergeWordprocessingDocument.ChangeDocumentType(DocumentFormat.OpenXml.WordprocessingDocumentType.Document);
                mergeWordprocessingDocument.SaveAs(directoryPath + "\\" + invoice + ".docx").Close();
                mergeWordprocessingDocument.Dispose();
                i = 1;



                Word2Pdf objWorPdf = new Word2Pdf();
                string strFileName = invoice+".docx";
               // InsertAPicture(currentPath + "\\Temp\\" + invoice + "\\" + strFileName, imagepath);
                string FileExtension = Path.GetExtension(strFileName);
                string ChangeExtension = strFileName.Replace(FileExtension, ".pdf");
                objWorPdf.InputLocation = directoryPath + "\\" + strFileName;
                objWorPdf.OutputLocation = directoryPath + "\\"+ ChangeExtension;
                objWorPdf.Word2PdfCOnversion();

                byte[] byteArray = System.IO.File.ReadAllBytes(directoryPath + "\\"+invoice+".pdf");
                var pdfStream = new MemoryStream(byteArray);
                


                userresponse.status = "Success";
                userresponse.message = "data retrieved";
                userresponse.data = byteArray;
                return File(pdfStream, "application/pdf", "servedFilename.pdf");
            }
            catch (Exception e)
            {
                userresponse.status = "fail";
                userresponse.message = e.Message;
                return File(e.Message, "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "servedFilename.docx");
            }
            finally
            {
                if (i == 0)
                {
                    mergeWordprocessingDocument.Close();
                    mergeWordprocessingDocument.Dispose();
                }

                System.IO.Directory.Delete(directoryPath, true);
            }
        }

        byte[] getWordDocandcreate(string invoice, byte[] byteData,string directoryPath,string testname)
        {
            var TemplateData = context.TemplateFiles.Where(r => true).ToList();
            var testReportData = context.testertestreport.Where(r => r.InvoiceNumber == invoice && r.testdiscription== testname).ToList();
            var firstTestReport = context.testreport.Where(r => r.InvoiceNumber == invoice && r.testdiscription== testname).FirstOrDefault();
            var patientData = context.adddata.FirstOrDefault(r => r.Patientregisternumber == firstTestReport.Patientregisternumber);
            var userrdata = context.Userr.FirstOrDefault(r => r.Email == patientData.userEmail);
            var technicianName = context.employeesdata.FirstOrDefault(r => r.userEmail == firstTestReport.userEmail);
            var currentPath = Directory.GetCurrentDirectory();
            string path = directoryPath;
            var WordpdfStream = new MemoryStream();
            WordpdfStream.Write(byteData, 0, byteData.Length);
            WordprocessingDocument wordprocessingDocument = WordprocessingDocument.Open(WordpdfStream, true);
            var document = wordprocessingDocument.MainDocumentPart.Document;
            var hideSpellingErrors = new HideSpellingErrors();
            hideSpellingErrors.Val = OnOffValue.FromBoolean(true);
            document.MainDocumentPart.Document.Append(hideSpellingErrors);
            string imagepath= "";
            //if (userrdata.DataFiles != null)
            //{
            //    MemoryStream ms = new MemoryStream(userrdata.DataFiles, 0, userrdata.DataFiles.Length);
            //    ms.Write(userrdata.DataFiles, 0, userrdata.DataFiles.Length);
            //    Image returnImage = Image.FromStream(ms, true);
            //    ImageFormat format = returnImage.RawFormat as ImageFormat;
            //    if (ImageFormat.Jpeg.Equals(format))
            //    {
            //        returnImage.Save("Temp\\" + invoice + "\\" + invoice + ".png");
            //        Bitmap bmp = new Bitmap(returnImage);
            //        imagepath = path + "\\" + invoice + ".png";
            //    }
            //    else if (ImageFormat.Png.Equals(format))
            //    {
            //        returnImage.Save("Temp\\" + invoice + "\\" + invoice + ".png");
            //        Bitmap bmp = new Bitmap(returnImage);
            //        imagepath = path + "\\" + invoice + ".png";
            //    }                
            //}
            byte[] resultArray = new byte[0];
            try
            {
                var textData = document.Descendants<Text>();
                ImagePart imagePart = wordprocessingDocument.MainDocumentPart.AddImagePart(ImagePartType.Png);
                var bodyData = wordprocessingDocument.MainDocumentPart.Document.Descendants<Text>();
                foreach (var text in wordprocessingDocument.MainDocumentPart.Document.Descendants<Text>()) // <<< Here mainPart.Document.Body.Descendants
                {
                    foreach (var test1 in testReportData)
                    {
                        if (text.Text.Contains(test1.TestParamName))
                        {
                            var result = "";
                            if(test1.unit!="" || test1.unit != null)
                            {
                                result = test1.result + "  " + test1.unit;
                            }
                            else
                            {
                                result = test1.result;
                            }
                            text.Text = text.Text.Replace(test1.TestParamName, result);
                        }
                        if (text.Text.Contains("patientName"))
                        {
                            text.Text = text.Text.Replace("patientName", patientData.Name);
                        }
                        else if (text.Text.Contains("age"))
                        {
                            string editage = (patientData.Age).ToString();
                            text.Text = text.Text.Replace("age", editage);
                        }
                        if (text.Text.Contains("gender"))
                        {
                            text.Text = text.Text.Replace("gender", patientData.gender);
                        }
                        if (text.Text.Contains("DoctorName"))
                        {
                            text.Text = text.Text.Replace("DoctorName", patientData.doctorName);
                        }
                        else if (text.Text.Contains("SampleDate"))
                        {
                            text.Text = text.Text.Replace("SampleDate", test1.editeddate);
                        }
                        if (text.Text.Contains("ReportDate"))
                        {
                            text.Text = text.Text.Replace("ReportDate", test1.TestReportDate);
                        }
                        else if (text.Text.Contains("ReportStatus"))
                        {
                            text.Text = text.Text.Replace("ReportStatus", "Final Report");
                        }
                        else if (text.Text.Contains("SampleType"))
                        {
                            text.Text = text.Text.Replace("SampleType", firstTestReport.sampletype);
                        }
                        else if (text.Text.Contains("InterPretation:"))
                        {
                            if (firstTestReport.result == null)
                            {
                                text.Text = text.Text.Replace("InterPretation:", "");
                            }                            
                        }
                        else if (text.Text.Contains("InterPretationResult"))
                        {
                            if (firstTestReport.result == null)
                            {
                                text.Text = text.Text.Replace("InterPretationResult", "");
                            }
                            else
                            {
                                text.Text = text.Text.Replace("InterPretationResult", firstTestReport.result);
                            }
                        }
                        else if (text.Text.Contains("TechnicianName"))
                        {
                            text.Text = text.Text.Replace("TechnicianName", technicianName.Name);
                        }
                    }
                }

                //Gets all the headers
                foreach (var headerPart in document.MainDocumentPart.HeaderParts)
                {
                    foreach (var currentText in headerPart.RootElement.Descendants<DocumentFormat.OpenXml.Wordprocessing.Text>())
                    {
                        if (currentText.Text.Contains("AppLogo"))
                        {
                            //using (FileStream streamed = new FileStream(imagepath, FileMode.Open))
                            //{
                            //    imagePart.FeedData(streamed);
                            //}
                            //var parent = currentText.Parent;
                            //string imagePartId = document.MainDocumentPart.GetIdOfPart(imagePart);
                            //Drawing drawImage = AddImageToBody(wordprocessingDocument, imagePartId,imagepath);
                            ////currentText.Parent.InsertAfter<Drawing>(drawImage, currentText);
                            //currentText.Remove();
                            //wordprocessingDocument.Save();
                        }
                    }
                }
                    //Gets all the Footer
                    foreach (var footerPart in document.MainDocumentPart.FooterParts)
                {
                    //Gets the text in Footer
                    foreach (var currentText in footerPart.RootElement.Descendants<DocumentFormat.OpenXml.Wordprocessing.Text>())
                    {
                        if (currentText.Text.Contains("LabName"))
                        {
                            currentText.Text = currentText.Text.Replace("LabName", userrdata.Lab_Name);
                        }
                        if (currentText.Text.Contains("Address"))
                        {
                            currentText.Text = currentText.Text.Replace("Address", userrdata.Lab_Address);
                        }
                        if (currentText.Text.Contains("labContactNumber"))
                        {
                            currentText.Text = currentText.Text.Replace("labContactNumber", userrdata.Phonenumber);
                        }
                        if (currentText.Text.Contains("Content"))
                        {
                            currentText.Text = currentText.Text.Replace("Content", "All Lab results are subject to clinical interpretation by qualified medical professional and this report is not to use for medico-legal purpose");
                        }
                    }
                }

                MemoryStream updateStream = new MemoryStream();
                wordprocessingDocument.Clone(updateStream);
                resultArray = updateStream.ToArray();
            }
            catch (Exception ex)
            {
                throw ex;
            }
             finally
            {
                wordprocessingDocument.Close();
                wordprocessingDocument.Dispose();
            }
            return resultArray;
           
        }


        static Drawing ConvertBitmapToDrawing(WordprocessingDocument wordDoc, System.Drawing.Bitmap image, ImagePart imagePart)
        {
            MainDocumentPart mainDocumentPart = wordDoc.MainDocumentPart;
            //ImagePart imagePart = mainDocumentPart.AddImagePart(ImagePartType.Bmp);
            //using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            //{
            //    image.Save(stream, System.Drawing.Imaging.ImageFormat.Bmp);
            //    stream.Position = 0;
            //    imagePart.FeedData(stream);
            //}

            string imagePartId = mainDocumentPart.GetIdOfPart(imagePart);

            var element =
                     new Drawing(
                         new DW.Inline(
                             new DW.Extent() { Cx = 9000L, Cy = 9200L },
                             new DW.EffectExtent()
                             {
                                 LeftEdge = 0L,
                                 TopEdge = 0L,
                                 RightEdge = 0L,
                                 BottomEdge = 0L
                             },
                             new DW.DocProperties()
                             {
                                 Id = (UInt32Value)1U,
                                 Name = "Picture 1"
                             },
                             new DW.NonVisualGraphicFrameDrawingProperties(
                                 new A.GraphicFrameLocks() { NoChangeAspect = true }),
                             new A.Graphic(
                                 new A.GraphicData(
                                     new PIC.Picture(
                                         new PIC.NonVisualPictureProperties(
                                             new PIC.NonVisualDrawingProperties()
                                             {
                                                 Id = (UInt32Value)0U,
                                                 Name = "New Bitmap Image.jpg"
                                             },
                                             new PIC.NonVisualPictureDrawingProperties()),
                                         new PIC.BlipFill(
                                             new A.Blip(
                                                 new A.BlipExtensionList(
                                                     new A.BlipExtension()
                                                     {
                                                         Uri =
                                                            "{28A0092B-C50C-407E-A947-70E740481C1C}"
                                                     })
                                             )
                                             {
                                                 Embed = imagePartId,
                                                 CompressionState =
                                                 A.BlipCompressionValues.Print
                                             },
                                             new A.Stretch(
                                                 new A.FillRectangle())),
                                         new PIC.ShapeProperties(
                                             new A.Transform2D(
                                                 new A.Offset() { X = 0L, Y = 0L },
                                                 new A.Extents() { Cx = 9000L, Cy = 9200L }),
                                             new A.PresetGeometry(
                                                 new A.AdjustValueList()
                                             )
                                             { Preset = A.ShapeTypeValues.Rectangle }))
                                 )
                                 { Uri = "http://schemas.openxmlformats.org/drawingml/2006/picture" })
                         )
                         {
                             DistanceFromTop = (UInt32Value)0U,
                             DistanceFromBottom = (UInt32Value)0U,
                             DistanceFromLeft = (UInt32Value)0U,
                             DistanceFromRight = (UInt32Value)0U,
                             EditId = "50D07946"
                         });

            return element;
        }


        public static void InsertAPicture(string document, string fileName)
        {
            using (WordprocessingDocument wordprocessingDocument =
                WordprocessingDocument.Open(document, true))
            {
                MainDocumentPart mainPart = wordprocessingDocument.MainDocumentPart;

                ImagePart imagePart = mainPart.AddImagePart(ImagePartType.Jpeg);

                using (FileStream stream = new FileStream(fileName, FileMode.Open))
                {
                    imagePart.FeedData(stream);
                }

               // AddImageToBody(wordprocessingDocument, mainPart.GetIdOfPart(imagePart));
               // wordprocessingDocument.SaveAs("testoing.docx");
            }
        }

        private Drawing AddImageToBody(WordprocessingDocument wordDoc, string relationshipId,string imagePath)
        {
            var element =
             new Drawing(
                 new DW.Inline(
                     new DW.Extent() { Cx = 9000L, Cy = 9200L },
                     new DW.EffectExtent()
                     {
                         LeftEdge = 0L,
                         TopEdge = 0L,
                         RightEdge = 0L,
                         BottomEdge = 0L
                     },
                     new DW.DocProperties()
                     {
                         Id = (UInt32Value)1U,
                         Name = "Picture 1"
                     },
                     new DW.NonVisualGraphicFrameDrawingProperties(
                         new A.GraphicFrameLocks() { NoChangeAspect = true }),
                     new A.Graphic(
                         new A.GraphicData(
                             new PIC.Picture(
                                 new PIC.NonVisualPictureProperties(
                                     new PIC.NonVisualDrawingProperties()
                                     {
                                         Id = (UInt32Value)0U,
                                         Name = "New Bitmap Image.jpg"
                                     },
                                     new PIC.NonVisualPictureDrawingProperties()),
                                 new PIC.BlipFill(
                                     new A.Blip(
                                         new A.BlipExtensionList(
                                             new A.BlipExtension()
                                             {
                                                 Uri =
                                                    "{28A0092B-C50C-407E-A947-70E740481C1C}"
                                             })
                                     )
                                     {
                                         Embed = imagePath,
                                         CompressionState =
                                         A.BlipCompressionValues.Print
                                     },
                                     new A.Stretch(
                                         new A.FillRectangle())),
                                 new PIC.ShapeProperties(
                                     new A.Transform2D(
                                         new A.Offset() { X = 0L, Y = 0L },
                                         new A.Extents() { Cx = 9000L, Cy = 9200L }),
                                     new A.PresetGeometry(
                                         new A.AdjustValueList()
                                     )
                                     { Preset = A.ShapeTypeValues.Rectangle }))
                         )
                         { Uri = "http://schemas.openxmlformats.org/drawingml/2006/picture" })
                 )
                 {
                     DistanceFromTop = (UInt32Value)0U,
                     DistanceFromBottom = (UInt32Value)0U,
                     DistanceFromLeft = (UInt32Value)0U,
                     DistanceFromRight = (UInt32Value)0U,
                     EditId = "50D07946"
                 });

            // Append the reference to body, the element should be in a Run.
            //wordDoc.MainDocumentPart.Document.Body.AppendChild(new Paragraph(new Run(element)));
            return element;


        }
    }
}
