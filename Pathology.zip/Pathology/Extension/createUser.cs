﻿using Medical_Lab.Model.Data_Model;
using Medical_Lab.Model.Request_Model;

namespace Medical_Lab.Extension
{
    public static class createUser
    {
        public static UserRegistration Createuser(this AddUserReq AddUserReq)
        {
            var newUser = new UserRegistration();
            newUser.Lab_Name=AddUserReq.Name;
            newUser.AdminEmail = AddUserReq.AdminEmail;
            newUser.Email = AddUserReq.Email;
            newUser.Password=AddUserReq.Password;
            newUser.Phonenumber = AddUserReq.PhoneNumber;
            return newUser;

        }
    }
}
