﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Medical_Lab.Model.Data_Model
{
    public class AddData
    {
        public int Id { get; set; }

        [Column("Name")]
        public string Name { get; set; }
        [Column("Age")]
        public int Age { get; set; }
        public string gender { get; set; }
        public string Address { get; set; }
        [Column("PhoneNumber")]
        public string Phonenumber { get; set; }
        public string AlternativeNumber { get; set; }
        [Column("PatientEmail")]
        public string PatientEmail { get; set; }
        public string adharNumber { get; set; }
       public string Patientregisternumber { get; set; }
        public string passPortNumber { get; set; }
        public string doctorName { get; set; }
        public string userEmail { get; set; }
        public string paymentstatus { get; set; }

  

        


    }
}
