﻿namespace Medical_Lab.Model.Data_Model
{
    public class AddtestreportXL
    {
        public int Id { get; set; }
        public string userEmail { get; set; }
        public string PatientName { get; set; }
        public string PhoneNumber { get; set; }
        public string BillDate { get; set; }
        public string Billtype { get; set; }
        public string InvoiceNumber { get; set; }
        public byte[] DataFiles { get; set; }
    }
}
