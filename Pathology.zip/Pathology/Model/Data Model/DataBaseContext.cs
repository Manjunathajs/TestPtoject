﻿
using Microsoft.EntityFrameworkCore;
using System;
namespace Medical_Lab.Model.Data_Model
{
    public class DataBaseContext : DbContext
    {
        
        public DataBaseContext(DbContextOptions<DataBaseContext> options)
           : base(options)

        { }
        public DbSet<UserRegistration> Userr { get; set; }
        public DbSet<AddData> adddata { get; set; }
        public DbSet<TestTable> testtable { get; set; }
        public DbSet<TestReport> testreport { get; set; }
        public DbSet<AddtestreportXL> addtestreportxl { get; set; }
        public DbSet<PatientReport> patientreport { get; set; }
        public DbSet<PackageTable> PackageTable { get; set; }
        public DbSet<DocterDetails> docterDetails { get; set; }
        public DbSet<EmployeesData> employeesdata { get; set; }
        public DbSet<Tester_test_Report> testertestreport { get; set; }

        public DbSet<TemplateFiles> TemplateFiles { get; set; }

        public DbSet<TestParameters> TestParameters { get; set; }

        public DbSet<SubscriptionPackage> SubscriptionPackage { get; set; }
        public DbSet<contactus> contactus { get; set; }
        public DbSet<InvoiceNumber> invoicenumber { get; set; }

    }
}
