﻿namespace Medical_Lab.Model.Data_Model
{
    public class DocterDetails
    {
        public int Id { get; set; }
        public string Email { get; set; }
        public string HospitalName { get; set; }
        public string DoctorName { get; set; }
        public string DocAddress { get; set; }
    }
}
