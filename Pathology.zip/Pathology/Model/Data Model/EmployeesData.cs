﻿namespace Medical_Lab.Model.Data_Model
{
    public class EmployeesData
    {
        public int Id { get; set; }
        public string userEmail { get; set; }
        public string Name { get; set; }
        public string MoblieNumber { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string jobdiscription { get; set; }
        public int role { get; set; }
    }
}
