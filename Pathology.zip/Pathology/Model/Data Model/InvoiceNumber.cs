﻿namespace Medical_Lab.Model.Data_Model
{
    public class InvoiceNumber
    {
        public int id { get; set; }
        public string userEmail { get; set; }
        public string Name { get; set; }
        public string Phonenumber { get; set; }
        public string Patientregisternumber { get; set; }
        public string Date { get; set; }
        public string Age { get; set; }
        public string gender { get; set; }
        public int invoiceNumber { get; set; }
        public string TotalAmount { get; set; }
    }
}
