﻿namespace Medical_Lab.Model.Data_Model
{
    public class PackageTable
    {
        public int Id { get; set; }
        public string PackageName { get; set; }
        public string testdiscription { get; set; }
        public string subtest { get; set; }
        public string Range { get; set; }
        public string units { get; set; }
        public int Amount { get; set; }
        public string testcode { get; set; }

       
    }
}
