﻿namespace Medical_Lab.Model.Data_Model
{
    public class PatientReport
    {
        public int Id { get; set; }
        public string PatientName { get; set; }
        public string userEmail { get; set; }
        public string PhoneNumber { get; set; }
        public int Age { get; set; }
        public string gender { get; set; }
        public string BillDate { get; set; }
        public string InvoiceNumber { get; set; }
        public string ReportStatus { get; set; }
        public byte[] DataFiles { get; set; }
    }
}
