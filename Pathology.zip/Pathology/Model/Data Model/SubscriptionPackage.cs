﻿namespace Medical_Lab.Model.Data_Model
{
    public class SubscriptionPackage
    {
        public int Id { get; set; }

        public string UserEmail { get; set; }

        public string purchaseDate{ get; set; }

        public string expiryDate { get; set; }

        public string status { get; set; }
    }
}
