﻿namespace Medical_Lab.Model.Data_Model
{
    public class TemplateFiles
    {
        public int Id { get; set; }

        public byte[] Template { get; set; }

        public string TestCode { get; set; }

        public string TestName { get; set; }

        public string Access { get; set; }
    }
}
