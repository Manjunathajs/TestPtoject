﻿namespace Medical_Lab.Model.Data_Model
{
    public class TestParameters
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Range { get; set; }

        public string TestName { get; set; }
        
        public string TestCode { get; set; }

        public int TestId { get; set; }

        public string TestParamName { get; set; }

        public string unit { get; set; }
    }
}
