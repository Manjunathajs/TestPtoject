﻿namespace Medical_Lab.Model.Data_Model
{
    public class TestReport
    {
        public int Id { get; set; }
        public string userEmail { get; set; }
        public string Name { get; set; }
        public string Phonenumber { get; set; }
        public string Patientregisternumber { get; set; }
        public string Date { get; set; }
        public string Age { get; set; }
        public string gender { get; set; }
        public string InvoiceNumber { get; set; }
        public string subtest { get; set; }
        public string reportstatus { get; set; }
        public string testdiscription { get; set; }
        public string result { get; set; }
        public string Range { get; set; }
        public int amount { get; set; }
        public int quantity { get; set; }
        public string doctorName { get; set; }
        public string sampletype { get; set; }
    }
}
