﻿namespace Medical_Lab.Model.Data_Model
{
    public class Tester_test_Report
    {
        public int Id { get; set; } 
        public string InvoiceNumber { get; set; }
        public string testdiscription { get; set; }
        public string Name { get; set; }
        public string unit { get; set; }
        public string result { get; set; }
        public string Range { get; set; }
        public string testcode { get; set; }
        public string reportstatus { get; set; }
        public string editeddate { get; set; }
        public string TestParamName { get; set; }
        public string TestReportDate { get; set; }
    }
}
