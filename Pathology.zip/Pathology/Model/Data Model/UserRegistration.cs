﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Medical_Lab.Model.Data_Model
{
    public class UserRegistration
    {
        public int Id { get; set; }

        [Column("Name")]
        public string? Lab_Name { get; set; }

        [Column("Email")]
        public string? Email { get; set; }
        public string Labcode { get; set; }
        public string? AdminEmail { get; set; }
        public string? Password { get; set; }

        [Column("PhoneNumber")]
        public string? Phonenumber { get; set; }
        public string GST_Number { get; set; }
        public string Lab_Address { get; set; }
        public byte[] DataFiles { get; set; }
        public int? Role { get; set; }
    }
}
