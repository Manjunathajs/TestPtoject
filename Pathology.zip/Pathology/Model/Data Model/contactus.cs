﻿namespace Medical_Lab.Model.Data_Model
{
    public class contactus
    {
        public int Id { get; set; }
        public string name { get; set; }
        public string emailaddress { get; set; }
        public string contactnumber { get; set; }
        public string organisation { get; set; }
        public string yourmessage { get; set; }
    }
}
