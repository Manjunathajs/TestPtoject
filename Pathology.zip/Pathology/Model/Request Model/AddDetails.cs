﻿namespace Medical_Lab.Model.Request_Model
{
    public class AddDetails
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string PatientEmail { get; set; }
        public string userEmail { get; set; }
        public int  Age { get; set; }
        public string gender { get; set; }
        public string PhoneNumber { get; set; }
        public string  AlternativeNumber { get; set; }
        public string Address { get; set; }
        public string adharNumber { get; set; }
        public string passPortNumber { get; set; }
        public string doctorName { get; set; }

    }
}
