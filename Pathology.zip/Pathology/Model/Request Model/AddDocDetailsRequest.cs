﻿using Microsoft.AspNetCore.Http;

namespace Medical_Lab.Model.Request_Model
{
    public class AddDocDetailsRequest
    {
        public string Email { get; set; }
        public string DoctorName { get; set; }
        public string HospitalName { get; set; }
        public string DocAddress { get; set; }
    }
}
