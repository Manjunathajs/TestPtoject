﻿namespace Medical_Lab.Model.Request_Model
{
    public class AddtestmanullyRequest
    {
        public string testdiscription { get; set; } 
        public string subtest { get; set; }
        public string units { get; set; }
        public string Amount { get; set; }
        public string testcode { get; set; }
        public string Range{get; set; }
    }
}
