﻿namespace Medical_Lab.Model.Request_Model
{
    public class ApprovedResultRequest
    {
        public string testdiscription { get; set; }
        public string result { get; set; }
        public string subtest { get; set; }
        public string InvoiceNumber { get; set; }
        public string reportstatus { get; set; }
    }
}
