﻿using Microsoft.AspNetCore.Http;

namespace Medical_Lab.Model.Request_Model
{
    public class BillPDF
    {
        public string PatientName { get; set; }
        public string userEmail { get; set; }
        public string PhoneNumber { get; set; }
        public int Age { get; set; }
        public string gender { get; set; }
        public string BillDate { get; set; }
        public string BillType { get; set; }
        public string InvoiceNumber {get; set; }
        public byte[] DataFiles { get; set; }
    }
}
