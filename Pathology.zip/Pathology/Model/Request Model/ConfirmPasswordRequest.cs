﻿namespace Medical_Lab.Model.Request_Model
{
    public class ConfirmPasswordRequest
    {
        public string userEmail { get; set; }
        public string newpassword { get; set; }
        public string confirmpassword { get; set; }
        public string role { get; set; }
    }
}
