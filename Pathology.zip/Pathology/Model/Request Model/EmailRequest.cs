﻿namespace Medical_Lab.Model.Request_Model
{
    public class EmailRequest
    {
        public string Email { get; set; }
    }
}
