﻿namespace Medical_Lab.Model.Request_Model
{
    public class LoginUserReq
    {
     
        public string EmailId { get; set; }
        public string Password { get; set; }
    }
}
