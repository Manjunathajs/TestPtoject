﻿namespace Medical_Lab.Model.Request_Model
{
    public class PatientEmailRequest
    {
        public string userEmail { get; set; }
    }
}
