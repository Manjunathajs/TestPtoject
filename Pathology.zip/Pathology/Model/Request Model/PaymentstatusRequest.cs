﻿namespace Medical_Lab.Model.Request_Model
{
    public class PaymentstatusRequest
    {
        public string PhoneNumber { get; set; }
        public string Billstatus { get; set; }
    }
}
