﻿namespace Medical_Lab.Model.Request_Model
{
    public class RejectReportRequest
    {
        public string InvoiceNumber { get; set; }
        public string testdiscription { get; set; }
        public string subtest { get; set; }
    }
}
