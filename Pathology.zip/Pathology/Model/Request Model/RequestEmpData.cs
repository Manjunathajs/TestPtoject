﻿namespace Medical_Lab.Model.Request_Model
{
    public class RequestEmpData
    {
        public string userEmail { get; set; }
        public string Name { get; set; }
        public string MobileNumber { get; set; }
        public string EmailId { get; set; }
        public string Password { get; set; }
        public string jobdiscription { get; set; }
    }
}
