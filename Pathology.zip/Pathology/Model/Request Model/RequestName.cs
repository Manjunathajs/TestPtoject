﻿namespace Medical_Lab.Model.Request_Model
{
    public class RequestName
    {
        public string Name { get; set; }
    }
}
