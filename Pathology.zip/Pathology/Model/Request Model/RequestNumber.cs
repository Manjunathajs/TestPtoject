﻿namespace Medical_Lab.Model.Request_Model
{
    public class RequestNumber { 
    
        public string PhoneNumber { get; set; }
        public string Name { get; set; }
        
    }
}
