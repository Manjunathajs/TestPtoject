﻿namespace Medical_Lab.Model.Request_Model
{
    public class RequestPhoneNumber
    {
        public string Phonenumber { get; set; }
    }
}
