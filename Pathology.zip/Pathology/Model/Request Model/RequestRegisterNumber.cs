﻿namespace Medical_Lab.Model.Request_Model
{
    public class RequestRegisterNumber
    {
        public string Patientregisternumber { get; set; }
    }
}
