﻿using Microsoft.AspNetCore.Http;

namespace Medical_Lab.Model.Request_Model
{
    public class TemplateRequest
    {
        public IFormFile Template { get; set; }

        public string TestCode { get; set; }

        public string TestName { get; set; }

        public string Access { get; set; }
    }

    public class updateTemplateRequest
    {
        public int id { get; set; }
        public IFormFile Template { get; set; }


    }

    class testing
    {
        public string testname { get; set; }

        public string result { get; set; }

    }
}
