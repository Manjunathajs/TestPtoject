﻿using Microsoft.AspNetCore.Http;

namespace Medical_Lab.Model.Request_Model
{
    public class TestData
    {
        public IFormFile DataFiles { get; set; }
    }
}
