﻿namespace Medical_Lab.Model.Request_Model
{
    public class TestDetailsRequest
    {
       public string userEmail { get; set; }
       public string Phonenumber { get; set; }
       public string InvoiceNumber { get; set; }
       public string testdiscription { get; set; }
       public string result { get; set; }
       public string range { get; set; }
    }
}
