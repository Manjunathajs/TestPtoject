﻿namespace Medical_Lab.Model.Request_Model
{
    public class TestReportRequest
    {
        public string InvoiceNumber { get; set; }
        public string testdiscription { get; set; }
        public string result { get; set; }
        public string range { get; set; }
        public string reportstatus { get; set; }
        
    }
}
