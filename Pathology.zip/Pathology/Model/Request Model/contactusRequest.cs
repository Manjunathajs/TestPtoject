﻿namespace Medical_Lab.Model.Request_Model
{
    public class contactusRequest
    {
        public string name { get; set; }
        public string emailaddress { get; set; }
        public string contactnumber { get; set; }
        public string organisation { get; set; }
        public string yourmessage { get; set; }
    }
}
