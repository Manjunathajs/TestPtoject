﻿namespace Medical_Lab.Model.Request_Model
{
    public class demoRequest
    {
        public string name { get; set; }
        public string emailaddress { get; set; }
    }
}
