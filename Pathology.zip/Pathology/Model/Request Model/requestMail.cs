﻿namespace Medical_Lab.Model.Request_Model
{
    public class requestMail
    {
        public string toEmail { get; set; }
        public string password { get; set; }
    }
}
