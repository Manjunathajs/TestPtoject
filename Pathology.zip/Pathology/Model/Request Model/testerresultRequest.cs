﻿namespace Medical_Lab.Model.Request_Model
{
    public class testerresultRequest
    {
        public string InvoiceNumber { get; set; }
        public string testdiscription { get; set; }
        public string subtest { get; set; }
        public string units { get; set; }
        public string result { get; set; }
        public string Range { get; set; }
        public string testcode { get; set; }
        public string reportstatus { get; set; }
        public string editeddate { get; set; }
        public string sampletype { get; set; }
    }
}
