﻿namespace Medical_Lab.Model.Request_Model
{
    public class testlistRequest
    {
        public string InvoiceNumber { get; set; }
    }
}
