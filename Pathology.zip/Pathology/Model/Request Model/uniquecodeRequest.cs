﻿namespace Medical_Lab.Model.Request_Model
{
    public class uniquecodeRequest
    {
        public string userEmail { get; set; }
        public string password { get; set; }
    }
}
