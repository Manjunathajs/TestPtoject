﻿namespace Medical_Lab.Model.Responce_Model
{
    public class PatientReportResponse
    {
        public string PatientEmail { get; set; }
        public string testdiscription { get; set; }
        public string result { get; set; }
        public string Range { get; set; }
    }
}
