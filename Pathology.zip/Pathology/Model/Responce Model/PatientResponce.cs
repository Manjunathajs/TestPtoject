﻿namespace Medical_Lab.Model.Responce_Model
{
    public class PatientResponce
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string phonenumber { get; set; }
        public string Patientregisternumber { get; set; }
        public int Age { get; set; }
        public string paymentstatus { get; set; }
        public string PatientEmail { get; set; }
        public string City { get; set; }
        public string gender { get; set; }
        public string adharNumber { get; set; }
        public string doctorName { get; set; }
        public int Role { get; set; }
    }
}
