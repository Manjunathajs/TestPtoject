﻿using System.IO;

namespace Medical_Lab.Model.Responce_Model
{
    public class Response
    {
        public string status { get; set; }
        public string message { get; set; }
        public object data { get; set; }
    }

    public class FileResponse
    {
        public string status { get; set; }
        public string message { get; set; }
        public object data { get; set; }
    }
}
