﻿using Medical_Lab.Model.Data_Model;
using System;
using System.Collections.Generic;

namespace Medical_Lab.Model.Responce_Model
{
    public class Testlist
    {
        public List<SubTestGroup> TestGroup { get; set; }
        
    }

   public class SubTestGroup
    {

        public string TestName { get; set; }
        public List<TestParameters> subTestGroup { get; set; }
        public List<Tester_test_Report> subTestGroup1 { get; set; }


    }

    public class SubTestGroup2
    {
        public string TestName { get; set; }
    }
}
