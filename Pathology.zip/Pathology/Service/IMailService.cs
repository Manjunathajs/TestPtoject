﻿using Medical_Lab.Model.Request_Model;
using System.Threading.Tasks;

namespace Medical_Lab.Service
{
    public interface IMailService
    {
        Task SendWelcomeEmailAsync(requestMail request);
        Task Sendmessagetoemail(Requestmessage getmessage);

        Task requestOtp(requestMail request);
        Task requestmsg(Requestmessage getmessage);
    }
}
