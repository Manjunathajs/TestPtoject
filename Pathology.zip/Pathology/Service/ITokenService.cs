﻿using Medical_Lab.Model.Data_Model;

namespace Medical_Lab.Service
{
    public interface ITokenService
    {
        string BuildToken(string key, string issuer, UserRegistration user);
        bool IsTokenValid(string key, string issuer, string token);
    }
}
