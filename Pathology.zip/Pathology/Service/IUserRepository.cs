﻿using Medical_Lab.Model.Data_Model;

namespace Medical_Lab.Service
{
    public interface IUserRepository
    {
        UserRegistration authenticate(string Email);

        void updateUser(UserRegistration user);
    }
}
