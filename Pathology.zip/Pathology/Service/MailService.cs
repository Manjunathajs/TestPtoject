﻿using MailKit.Net.Smtp;
using MailKit.Security;
using Medical_Lab.Model.Data_Model;
using Medical_Lab.Model.Request_Model;
using Microsoft.Extensions.Options;
using MimeKit;
using SendGrid;
using SendGrid.Helpers.Mail;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Medical_Lab.Service
{
    public class MailService: IMailService
    {
        private readonly Model.Request_Model.MailSettings _mailSettings;
        private DataBaseContext context;
        public MailService(IOptions<Model.Request_Model.MailSettings> mailSettings, DataBaseContext _context)
        {
            _mailSettings = mailSettings.Value;
            this.context = _context;
        }
        public async Task SendWelcomeEmailAsync(requestMail request)
        {
            var apikey = _mailSettings.Api;
            var client = new SendGridClient(apikey);
            var from = new EmailAddress(_mailSettings.Mail, "LIBLIFE Team");
            var to = new EmailAddress(request.toEmail, "Hello User");
            var subject = "Password for Reseting with LABLIFE";
            var plainTextContent = "As per your Request the Password for registering with LABLIFE is  " + request.password;
            var htmlContent = "As per your Request the Password for registering with LABLIFE is " + request.password + "<br><br>vali for 5mins";
            var msg = MailHelper.CreateSingleEmail(
                from,
                to,
                subject,
                plainTextContent,
                htmlContent
                );
            var data = context.Userr.FirstOrDefault(r => r.Email==request.toEmail);
            {
                data.Email = request.toEmail;
                data.Password = request.password;
            };
            context.Userr.Update(data);
            context.SaveChanges();
            var response = await client.SendEmailAsync(msg);
        }
        public async Task requestOtp(requestMail request)
        {
            var data = context.Userr.FirstOrDefault(a => a.Email == request.toEmail);
            {
                data.Email = request.toEmail;
                data.Password = request.password;
            };
            context.Userr.Update(data);
            context.SaveChanges();
            var email = new MimeMessage();
            email.Sender = MailboxAddress.Parse("pruthvirajrj.2112@gmail.com");
            email.Sender = MailboxAddress.Parse("pruthvirajrj.2112@gmail.com");
            email.To.Add(MailboxAddress.Parse(request.toEmail));
            //  email.To.Add(MailboxAddress.Parse(request.toEmail));
            email.Subject = "Password Reset from Super Nova ";
            string emailbody = @"<html>
                      <body><div> As per your Request the Temporary Password for Reseting your Account of LABLIFE is " + request.password +", Please login with this password and update a new password"+ "</div></body></html>";
            var builder = new BodyBuilder();
            builder.HtmlBody = emailbody;
            email.Body = builder.ToMessageBody();
            using var smtp = new SmtpClient();
            smtp.Connect("smtp.gmail.com", 587, SecureSocketOptions.StartTls);
            smtp.Authenticate("pruthvirajrj.2112@gmail.com", "dqeahtjdjkkkacjo");
            await smtp.SendAsync(email);

            smtp.Disconnect(true);
        }
        public async Task Sendmessagetoemail(Requestmessage getmessage)
        {
            var apikey = _mailSettings.Api;
            var client = new SendGridClient(apikey);
            var from = new EmailAddress(_mailSettings.Mail, "LIBLIFE Team");
            var to = new EmailAddress(getmessage.emailaddress, "Hello User");
            var subject = "Booking Demo with LABLIFE";
            var plainTextContent = " Thank you For Your Interest "+ getmessage.emailaddress;
            var htmlContent = "As per your Request the our LABLIFE team will contact you soon<br><br>";
            var msg = MailHelper.CreateSingleEmail(
                from,
                to,
                subject,
                plainTextContent,
                htmlContent
                );
            /*var data = context.Userr.FirstOrDefault(r => r.Email == request.toEmail);
            {
                data.Email = request.toEmail;
                data.Password = request.password;
            };
            context.Userr.Update(data);
            context.SaveChanges();*/
            var response = await client.SendEmailAsync(msg);
        }
        public async Task requestmsg(Requestmessage getmessage)
        {
            var email = new MimeMessage();
            email.Sender = MailboxAddress.Parse("pruthvirajrj.2112@gmail.com");
            email.Sender = MailboxAddress.Parse("pruthvirajrj.2112@gmail.com");
            email.To.Add(MailboxAddress.Parse(getmessage.emailaddress));
            //  email.To.Add(MailboxAddress.Parse(request.toEmail));
            email.Subject = "Regarding Request of Demo form LabLife.co";
            string emailbody = @"<html>
                      <body><div> Your request as been recieved, Our LabLife team will contact you shortly.. "+ "<br> Thank you Mr/Ms/Mrs: " + getmessage.name +" Showing the Interest" + "</div></body></html>";
            var builder = new BodyBuilder();
            builder.HtmlBody = emailbody;
            email.Body = builder.ToMessageBody();
            using var smtp = new SmtpClient();
            smtp.Connect("smtp.gmail.com", 587, SecureSocketOptions.StartTls);
            smtp.Authenticate("pruthvirajrj.2112@gmail.com", "dqeahtjdjkkkacjo");
            await smtp.SendAsync(email);

            smtp.Disconnect(true);
        }

    }
}
