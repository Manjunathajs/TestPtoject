﻿using Medical_Lab.Service;
using Medical_Lab.Model.Data_Model;
using System.Linq;

namespace Medical_Lab.Service
{
    public class UserRepository : IUserRepository
    {
        private DataBaseContext context;
        public UserRepository(DataBaseContext _context)
        {

        
            context = _context;

        }
        public UserRegistration authenticate(string Email)
        {
            var s = context.Userr.Where(x => x.Email.ToUpper() == Email.ToUpper()).FirstOrDefault();               
            return s;
        }
        public void updateUser(UserRegistration user)
        {
           var data= context.Userr.Where(x => x.Email.ToUpper() == user.Email.ToUpper()).FirstOrDefault();
            context.Update(data);
            context.SaveChanges();
        }
    }
}
